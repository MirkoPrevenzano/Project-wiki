package gui;

import controllerPackage.Controller;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Creazione proposta.
 */
public class CreazioneProposta {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JPanel panel1;
    private JList  <String> jlistPhrases;

    private JButton saveReturnButton;
    private  Timer messageTimer;
    private final List<Integer> selectedPhrases = new ArrayList<>();
    private final List<String> modifyPhrases = new ArrayList<>();


    /**
     * Instantiates a new Creazione proposta.
     *
     * @param controller    the controller
     * @param framePrevious the frame previous
     * @param listPhrases   the list phrases
     * @param title         the title
     * @param nameUtente    the name utente
     * @param surnameUtente the surname utente
     */
    public CreazioneProposta(final Controller controller, final JFrame framePrevious,  final List<String> listPhrases,  final String title, final String nameUtente, final String surnameUtente) {
        frame = new JFrame(title);
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);

        DefaultListModel<String > listModel=new DefaultListModel<>();
        this.jlistPhrases.setModel(listModel);

            for (String listPhrase : listPhrases) {
                listModel.addElement(listPhrase);
            }

        jlistPhrases.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    if (jlistPhrases.getSelectedIndex() != -1 && jlistPhrases.getModel().getElementAt(jlistPhrases.getSelectedIndex()).isEmpty()) {

                        jlistPhrases.clearSelection();
                    } else {

                        /*int index = jlistPhrases.locationToIndex(e.getPoint());
                        String phrase=listPhrases.get(jlistPhrases.getSelectedIndex());*/

                        //jlistPhrases.setSelectedIndex(index);
                        JPopupMenu popupMenu = createPopupMenu( listPhrases, listModel);
                        popupMenu.show(jlistPhrases, e.getX(), e.getY());

                    }

                }
            }
        });







            saveReturnButton.addActionListener(e -> {
                controller.savePropostaUtente(selectedPhrases, modifyPhrases, title, nameUtente, surnameUtente);
                JOptionPane.showMessageDialog(frame, "Proposta inviata correttamente");

                frame.setVisible(false);
                frame.dispose();
                framePrevious.setVisible(true);
            });

    }

    private void updateList(DefaultListModel<String> listModel, List<String> listPhrases) {
        listModel.clear();
        for (String listPhrase : listPhrases) {
            listModel.addElement(listPhrase);
        }
        jlistPhrases.revalidate();

    }

    private void updateModifyList(List<Integer> selectedPhrases, List<String> modifyPhrases, int selectedIndices, String newPhrase) {
        int ctr=0;
        for (Integer i : selectedPhrases
        ) {
            if (i.equals(selectedIndices)) {
                ctr = 1;
                int j = selectedPhrases.indexOf(selectedIndices);
                modifyPhrases.set(j, newPhrase);
                break;
            }
        }
        if(ctr!=1){
            selectedPhrases.add(selectedIndices);
            modifyPhrases.add(newPhrase);
        }

    }

    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }



    private JPopupMenu createPopupMenu(List<String> listPhrases, DefaultListModel<String> listModel) {
        JPopupMenu popupMenu = new JPopupMenu();

        JMenuItem showModify = new JMenuItem("Modifica frase");
        showModify.addActionListener(e -> {
            if (jlistPhrases.isSelectionEmpty()) {
                showMessage("Seleziona una frase");
            } else {
                int selectedIndices = jlistPhrases.getSelectedIndex();
                jlistPhrases.clearSelection();
                String newPhrase=JOptionPane.showInputDialog("Nuova frase:");
                if(newPhrase!=null) {
                    if (!newPhrase.isEmpty()) {

                        listPhrases.set(selectedIndices, newPhrase);
                        updateList(listModel, listPhrases);


                        updateModifyList(selectedPhrases, modifyPhrases, selectedIndices, newPhrase);
                    }
                }
            }

        });
        popupMenu.add(showModify);

        JMenuItem showDelete = new JMenuItem("Elimina frase");
        showDelete.addActionListener(e -> {
            if (jlistPhrases.isSelectionEmpty()) {
                showMessage("Selezione una frase");
            }
            else {
                int selectedIndices = jlistPhrases.getSelectedIndex();
                jlistPhrases.clearSelection();
                listPhrases.set(selectedIndices," ");

                updateList(listModel, listPhrases);
                updateModifyList(selectedPhrases,modifyPhrases,selectedIndices," ");
            }

        });
        popupMenu.add(showDelete);


        return popupMenu;
    }
}
