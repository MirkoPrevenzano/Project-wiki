package gui;

import controllerPackage.Controller;
import javax.swing.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * The type View versioni precedenti.
 */
public class ViewVersioniPrecedenti {
    private JPanel panel1;
    private JList<String> listVersions;
    private JButton returnButton;

    /**
     * The Frame.
     */
    public final JFrame frame;
    private Timer messageTimer;

    /**
     * Instantiates a new View versioni precedenti.
     *
     * @param controller     the controller
     * @param framePrevious  the frame previous
     * @param title          the title
     * @param usernameAutore the username autore
     */
    public ViewVersioniPrecedenti(final Controller controller, final JFrame framePrevious, final String title, final String usernameAutore) {
        frame = new JFrame("Storico: "+title);
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);
        insertList(controller, title, usernameAutore);


        returnButton.addActionListener(e -> {
            frame.setVisible(false);
            frame.dispose();
            framePrevious.setVisible(true);
        });


        listVersions.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !listVersions.isSelectionEmpty()) {
                String selectedValue =  listVersions.getSelectedValue();

                if (selectedValue != null) {
                    String[] parts = selectedValue.split(" {2}");

                    if (parts.length == 2) {
                        openFrameViewPage(controller, title,usernameAutore, parts);
                    }
                    else {
                        showMessage("Errore nel formato della data e dell'ora.");
                    }
                }
            }
        });

    }

    private void openFrameViewPage(Controller controller, String title, String usernameAutore, String[] timeDate) {
        String dateString = timeDate[0];
        String timeString = timeDate[1];
        LocalDate dateSelect = LocalDate.parse(dateString);
        LocalTime timeSelect = LocalTime.parse(timeString);
        List<String> phrasesList = controller.getTestoPageVersione(title, dateSelect, timeSelect, usernameAutore);
        if (!phrasesList.isEmpty()) {
            OnlyViewPage onlyViewPage = new OnlyViewPage( frame, phrasesList, title, usernameAutore);
            onlyViewPage.frame.setVisible(true);
            frame.setVisible(false);

        } else {
            showMessage("Errore nel caricamento!");
        }

        listVersions.clearSelection();
    }

    private void insertList(Controller controller, String title, String usernameAutore) {
        List<LocalDate> date = controller.getDataVersione(title, usernameAutore);
        List<LocalTime> time = controller.getOraVersione(title, usernameAutore);
        DefaultListModel<String> listModel=new DefaultListModel<>();
        listVersions.setModel(listModel);
        if (date != null && date.size() == time.size()) {
            for (int i = 0; i < date.size(); ++i) {
                listModel.addElement(date.get(i) + "  " +
                        String.format("%02d", time.get(i).getHour()) + ":" +
                        String.format("%02d", time.get(i).getMinute()) + ":" +
                        String.format("%02d", time.get(i).getSecond()));
            }
        }
    }

    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }
}
