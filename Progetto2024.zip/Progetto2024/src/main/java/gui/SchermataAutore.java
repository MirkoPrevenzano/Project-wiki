package gui;

import controllerPackage.Controller;
import javax.swing.*;
import java.util.List;


/**
 * The type Schermata autore.
 */
public class SchermataAutore {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JPanel panel1;
    private JButton buttonReturn;
    private JButton buttonCreatePage;
    private JButton upButton;
    private JList<String> listPage;
    private JButton homeButton;
    private JToolBar toolBar;
    private JButton proposedButton;
    private  Timer messageTimer;

    /**
     * Instantiates a new Schermata autore.
     *
     * @param controller     the controller
     * @param frameChiamante the frame chiamante
     * @param usernameAutore the username autore
     */
    public SchermataAutore(final Controller controller, final JFrame frameChiamante, final String usernameAutore) {
        frame = new JFrame("Profilo:" + usernameAutore);
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(frameChiamante);
        frame.setResizable(false);
        toolBar.setFloatable(false);


        List<String> listTitle = controller.uploadTitles(usernameAutore);
        DefaultListModel<String> listModel=new DefaultListModel<>();
        listPage.setModel(listModel);
        if (listTitle != null) {
            for (String s : listTitle) {
                listModel.addElement(s);
            }
        }

        if(controller.isNotifyProposta(usernameAutore))
        {
                showMessage("Ci sono delle nuove proposte!");
        }


            buttonReturn.addActionListener(e -> {
                frame.setVisible(false);
                frame.dispose();
                frameChiamante.setVisible(true);
            });


            buttonCreatePage.addActionListener(e -> {

                CreazionePagina creazionePagina = new CreazionePagina(controller, frame, usernameAutore, listTitle);
                frame.setVisible(false);
                creazionePagina.frame.setVisible(true);
                frame.dispose();
            });


            upButton.addActionListener(e -> {
                listModel.clear();
                listPage.setVisible(true);
                List<String> listTitoli = controller.uploadTitles(usernameAutore);

                for (String s : listTitoli) {
                    listModel.addElement(s);
                }
            });


            listPage.addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && !listPage.isSelectionEmpty()) {
                    List<String> listPhrase = controller.getTestoPage(listPage.getSelectedValue(), usernameAutore);
                    if (listPhrase != null) {
                        ViewPagina viewPagina = new ViewPagina(controller, frame, usernameAutore, listPhrase, listPage.getSelectedValue());
                        viewPagina.frame.setVisible(true);
                        frame.setVisible(false);
                        frame.dispose();
                        listPage.clearSelection();
                    }
                    else {
                       showMessage("Pagina selezionata non esistente, aggiorna la lista!");
                    }

                }
            });


        homeButton.addActionListener(e -> {
            String nameAutore = controller.getNomeAutore(usernameAutore);
            String surnameAutore = controller.getCognomeAutore(usernameAutore);

            SchermataUtente schermataUtente = new SchermataUtente(controller, frame, nameAutore, surnameAutore);
            frame.setVisible(false);
            schermataUtente.frame.setVisible(true);
            frame.dispose();
        });

        proposedButton.addActionListener(e -> {
            if(controller.isProposedAutore(usernameAutore)) {
                ViewProposteAutore viewProposteAutore = new ViewProposteAutore(frame, controller, usernameAutore);
                viewProposteAutore.frame.setVisible(true);
                frame.setVisible(false);
                frame.dispose();
            }
            else
                showMessage("Non hai effettuato nessuna proposta");

        });
    }
    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(3000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }

}



