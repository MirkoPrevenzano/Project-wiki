package gui;

import controllerPackage.Controller;
import javax.swing.*;
import java.util.List;

/**
 * The type Creazione pagina.
 */
public class CreazionePagina {

    /**
     * The Frame.
     */
    public  final JFrame frame;
    private JPanel panel1;
    private JTextField textTitle;
    private JButton createButton;
    private JButton returnButton;
    private JButton buttonSave;
    private JTextArea textArea;
    private JLabel labelTitle;
    private Timer messageTimer;


    /**
     * Instantiates a new Creazione pagina.
     *
     * @param controller     the controller
     * @param framePrevious  the frame previous
     * @param usernameAutore the username autore
     * @param listTitles     the list titles
     */
    public CreazionePagina(final Controller controller, final JFrame framePrevious, final String usernameAutore, final List<String> listTitles) {
        this.frame = new JFrame("Creazione nuova pagina");
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);

        buttonSave.setVisible(false);
        textArea.setVisible(false);

        createButton.addActionListener(e -> {
            if (!textTitle.getText().isBlank()) {
                if (Boolean.FALSE.equals(controller.addPage(textTitle.getText(), usernameAutore))) {
                    showMessage( "Hai già una pagina con questo titolo");
                } else {

                    textTitle.setEnabled(false);
                    buttonSave.setVisible(true);
                    textArea.setVisible(true);
                    createButton.setVisible(false);
                    returnButton.setVisible(false);
                    labelTitle.setVisible(false);

                }

            } else {
                showMessage( "Inserisci un titolo");
            }
        });


        returnButton.addActionListener(e -> {
            frame.setVisible(false);
            frame.dispose();
            framePrevious.setVisible(true);
        });


        buttonSave.addActionListener(e -> {
            String text = textArea.getText();
            text+="\n";



                    if (!text.isBlank()) {
                        createPage(text, controller, usernameAutore);
                    }


            listTitles.add(textTitle.getText());
            showMessage("Pagina creata con successo");
            List<String> listPhrases=controller.getTestoPage(textTitle.getText(),usernameAutore);

            ViewPagina viewPagina=new ViewPagina(controller, framePrevious,usernameAutore,listPhrases, textTitle.getText());
            viewPagina.frame.setVisible(true);
            frame.setVisible(false);

        });

    }

    private void createPage(String text, Controller controller, String usernameAutore) {
        int supp = 0;
        int positions;
        while ((positions = text.indexOf("\n", supp + 1)) != -1) {
            String phrase = text.substring(supp, positions).trim();

            if (!phrase.isEmpty()) {
                controller.gestioneTestoPage(phrase, usernameAutore, textTitle.getText());
            }

            supp = positions + 1;
        }
    }

    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }


}



