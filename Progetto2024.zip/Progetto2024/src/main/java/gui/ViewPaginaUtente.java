package gui;

import controllerPackage.Controller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.util.List;

/**
 * The type View pagina utente.
 */
public class ViewPaginaUtente {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JPanel panel1;
    private JList<String> listPhrase;
    private JButton modifyButton;
    private JButton returnButton;
    private Timer messageTimer;

    /**
     * Instantiates a new View pagina utente.
     *
     * @param controller    the controller
     * @param framePrevious the frame previous
     * @param phrases       the phrases
     * @param title         the title
     * @param nameUtente    the name utente
     * @param surnameUtente the surname utente
     */
    public ViewPaginaUtente(final Controller controller, final JFrame framePrevious, final List<String> phrases, String title, final String nameUtente, final String surnameUtente) {

        this.frame = new JFrame(title);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);


        DefaultListModel<String> listModel=new DefaultListModel<>();
        this.listPhrase.setModel(listModel);

            for (String phrase : phrases) {
                listModel.addElement(phrase);
            }

            returnButton.addActionListener(e -> {
                frame.setVisible(false);
                frame.dispose();
                framePrevious.setVisible(true);
            });




        modifyButton.addActionListener(e -> {
            CreazioneProposta creazioneProposta=new CreazioneProposta(controller,frame,phrases,title,nameUtente,surnameUtente);
            creazioneProposta.frame.setVisible(true);
            frame.setVisible(false);
        });




        listPhrase.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (modifyButton.isVisible()) {
                    listPhrase.removeListSelectionListener(this);
                    int index = listPhrase.getSelectedIndex();
                    listPhrase.clearSelection();


                    if (controller.isCollegamento(title, index)) {
                        String titleLink=controller.pageLink(title, index);
                        List<String> text=controller.getTestoPage(titleLink);
                        String usernameAutore=controller.getAutore(titleLink);
                        if(text != null && (usernameAutore != null))
                        {
                            OnlyViewPage onlyViewPage=new OnlyViewPage(frame,text, titleLink,usernameAutore);
                            onlyViewPage.frame.setVisible(true);
                            frame.setVisible(false);
                            frame.dispose();
                        }
                        else
                        {
                            showMessage("Errore generico");
                        }

                    } else {

                        showMessage("Not found");
                    }
                }
                listPhrase.addListSelectionListener(this);

            }

        });
    }
    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }

}
