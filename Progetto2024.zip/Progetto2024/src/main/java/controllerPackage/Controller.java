package controllerPackage;


import DAO.*;
import ImplementazionePostgresDao.*;
import Model.*;

import Model.Pagina;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Iterator;
import java.util.List;

public class Controller {
    private Autore autore;
    private Utente utente;
    private final ListinoIscritti listinoIscritti = new ListinoIscritti();

    public Controller() {


    }
    /*public void prova()
    {
        Autore a=listinoIscritti.searchAutore("mario.rossi");
        if(a==null)
            System.out.println("autore null");
        Utente u=listinoIscritti.searchUtente("Mirko","Prevenzano");
        if(u==null)
            System.out.println("utente null");
        Pagina p=getPage("Carcere", "mario.rossi");
        if(p==null)
            System.out.println("pagina null");
        VersioneProposta proposta=new VersioneProposta()(u,a,,p.getTesto().getFrasi().get(0),"ciao");
        if(proposta==null)
            System.out.println("proposta null");


    }*/

    //iscrizione, ritora true se l'iscrizione è andata a buon fine (voglio vedere come si può verificare se un utente è iscritto o no
    public int addNewAuthor(String nome, String cognome, String username, String password) {
        for (Autore a : listinoIscritti.getListAutore()
        ) {
            if (a.getLogin().equals(username))
                return 2;//autore già esistente

        }
        this.autore = new Autore(nome, cognome, username, password);
        inserisciAutore(nome,cognome,username,password);

        listinoIscritti.addListAutore(this.autore);
        listinoIscritti.addListUtente(this.autore);
        if (autore != null)
            return 1;
        return 0;
    }

    public void inserisciAutore(String nomeAutore, String cognomeAutore, String username, String password)
    {
        AutoreDAO ad = new ImplementazionePostgresAutoreDao();
        ad.inserisciAutore(nomeAutore,cognomeAutore, username, password);

    }

    public int addNewUtente(String nome, String cognome) {
        for (Utente u : listinoIscritti.getListUtente()
        ) {
            if (u.getNome().equals(nome) && u.getCognome().equals(cognome))
                return 2;//utente già esistente

        }
        this.utente = new Utente(nome, cognome);
        inserisciUtente(nome,cognome);
        listinoIscritti.addListUtente(this.utente);

        if (utente != null)
            return 1;
        return 0;
    }

    public void inserisciUtente(String nome, String cognome)
    {
        UtenteDAO ud = new ImplementazionePostgresUtenteDao();
        ud.inserisciUtente(nome,cognome);
    }

    public int accessAutore(String username, String password) {
        for (Autore a : listinoIscritti.getListAutore()) {
            if (a.getLogin().equals(username)) {
                if (a.signIn(username, password)) {
                    return 1; //passwordCorretta
                } else {
                    return 2; //passwordErrata
                }
            }
        }
        return 0;//Autore non esistente
    }


    public Boolean accessUtente(String nome, String cognome) {

        for (Utente utente : listinoIscritti.getListUtente()) {
            if (utente.getNome().equals(nome) && utente.getCognome().equals(cognome)) {
                return true;
            }

        }
        return false;

    }

    public Boolean addPage(String titolo, String usernameAutore) {//creo nuova pagina
        Autore autore = listinoIscritti.searchAutore(usernameAutore);
        for(Autore a:listinoIscritti.getListAutore() )
        {
            for (Pagina p : a.getListPagine()) {
                if (p.getTitolo().equals(titolo)) {
                    return false;
                }

            }

        }

        Pagina p = new Pagina(titolo, autore);
        Date data = Date.valueOf(p.getData());
        Time ora = Time.valueOf(p.getOra());
        inserisciPagine(titolo,data,ora,autore.getLogin());
        autore.addListPagine(p);
        return true;
    }

    public void inserisciPagine(String TitoloPagina, Date dataPagina, Time oraPagina, String usernameAutore)
    {
        PaginaDAO pd = new ImplementazionePostgresPaginaDao();
        pd.inserisciPagine(TitoloPagina,dataPagina,oraPagina,usernameAutore);
    }

    public Pagina getPage(String titolo, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> page = a.getListPagine();
        //uso di stream e filter
        return page.stream().filter(paginaT -> paginaT.getTitolo().equals(titolo)).findFirst().orElse(null);
    }
    public VersioneCorrente getVersioneCorrente(String titolo, String usernameAutore)
    {
       Pagina p=getPage(titolo,usernameAutore);
       return p.getVersioneCorrente();
    }

    public void gestioneTestoPage(String nuovaFrase, String usernameAutore, String titolo) {
       // Pagina pagina = getPage(titolo, usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,usernameAutore);
        Frase f = new Frase(nuovaFrase, versioneCorrente.getTesto());
        inserisciFrase_DB(nuovaFrase,versioneCorrente.getTesto().getFrasi().size(),titolo);
        versioneCorrente.getTesto().addFrase(f);
    }

    public void inserisciFrase_DB(String TestoFrase, int ordine, String titolo)
    {
        FraseDAO fd = new ImplementazionePostgresFrasiDao();
        fd.inserisciFrase_DB(TestoFrase,ordine, titolo);

    }



    public List<String> caricaTitoli(String usernameAutore) {
        autore = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> p = autore.getListPagine();
        List<String> tit = new ArrayList<>();
        for (Pagina pp : p
        ) {
            tit.add(pp.getTitolo());
        }
        return tit;
    }

    public List<String> caricaTitoli() {
        List<String> tit = new ArrayList<>();
        for (Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                tit.add((p.getTitolo()));
            }
        }

        return tit;
    }

    public List<String> getTestoPage(String titoloPagina, String usernameAutore) {

        VersioneCorrente versioneCorrente=getVersioneCorrente(titoloPagina,usernameAutore);
        List<Frase> listFrasTesto=null;
        if(versioneCorrente!=null)
        {
            listFrasTesto = versioneCorrente.getTesto().getFrasi();
        }

        //controllare meglio
        List<String> testoPage = new ArrayList<>();
        for (Frase f : listFrasTesto) {
            testoPage.add(f.getTesto());
        }
        return testoPage;
    }




    public void modificaTesto(List<Integer> frasiSelezionate, List<String> frasi, String titolo, String usernameAutore) {

        Pagina pagina = getPage(titolo, usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,usernameAutore);
        VersionePrecedente versionePrecedente=new VersionePrecedente();

        Testo t=versioneCorrente.getTesto();
        versionePrecedente.setTesto(t);
        pagina.addListVersione(versionePrecedente);



        for (int i = 0; i < frasiSelezionate.size(); i++) {
            Frase f = new Frase(frasi.get(i), t);
            versioneCorrente.getTesto().addFrase(f,frasiSelezionate.get(i));
        }

    }

    public void saveProposta(List<Integer> listFrasi, List<String> modifiche, String usernameAutore, String titolo) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        Pagina p=getPage(titolo, usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,usernameAutore);
        List<Frase> frasiSelezionate = new ArrayList<>();
        for (int i = 0; i < listFrasi.size(); i++) {

            frasiSelezionate.add(versioneCorrente.getTesto().getFrasi().get(listFrasi.get(i)));
        }
        VersioneProposta proposta = new VersioneProposta(a, a, p, frasiSelezionate, modifiche);
        proposta.setTesto(creaTesto(modifiche,p, listFrasi));
        for (VersioneProposta v:a.getListPropostaGestite()
             ) {
            if(v.getPagina().equals(p)&&!v.isElaborato()&&v!=proposta)
                v.setStato(false);
                v.setElaborato(true);


        }
        a.addProposta(proposta);
    }
    public void savePropostaUtente(List<Integer> listFrasi, List<String> modifiche, String titolo, String nomeUtente, String cognomeUtente)
    {
        Utente u = listinoIscritti.searchUtente(nomeUtente, cognomeUtente);
        for(Autore a : listinoIscritti.getListAutore())
        {
            for(Pagina p : a.getListPagine())
            {
                if(p.getTitolo().equals(titolo))
                {
                    VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,a.getLogin());
                    List<Frase> frasiSelezionate = new ArrayList<>();
                    for (int i = 0; i < listFrasi.size(); i++) {

                        frasiSelezionate.add(versioneCorrente.getTesto().getFrasi().get(listFrasi.get(i)));
                    }

                    VersioneProposta proposta = new VersioneProposta(u, a, p, frasiSelezionate,modifiche);
                    proposta.setTesto(creaTesto(modifiche,p, listFrasi));
                    if(proposta.isElaborato())
                    {
                       //List<String> testo= getTextProposta(titolo,a.getLogin());
                        modificaTesto(listFrasi,modifiche,titolo,a.getLogin());
                    }

                }
            }
        }

    }
    public Testo creaTesto( List<String> modifiche, Pagina p, List<Integer> listFrasiIndex )
    {
        VersioneCorrente versioneCorrente=getVersioneCorrente(p.getTitolo(), p.getAutore().getLogin());
        Testo t=new Testo();
        /**obbliga un testo di avere una pagina come att**/
        for(int i=0;i<versioneCorrente.getTesto().getFrasi().size();i++)
        {
            int ctr=-1;
            int sent=-1;
            for(int j=0;j<listFrasiIndex.size();j++)
            {
                if(listFrasiIndex.get(j)==i)
                {
                    ctr=listFrasiIndex.get(j);
                    sent=j;
                }
            }
            if(ctr!=-1&&modifiche.get(sent)!="")
            {
                Frase frase=new Frase(modifiche.get(sent), t);
                t.addFrase(frase);
            }
            else if(ctr==-1)
            {
                Frase frase=new Frase(versioneCorrente.getTesto().getFrasi().get(i).getTesto(), t);
                t.addFrase(frase);
            }

        }

        return t;
    }




    public void modificaTesto(List<String> frasiSelezionate, List<String> modifiche, String usernameAutore, String titolo, String usernameUtente) {
        if (usernameUtente.equals(usernameAutore)) {
           // Pagina p = getPage(titolo, usernameAutore);
            VersioneCorrente versioneCorrente=getVersioneCorrente(titolo, usernameAutore);
            VersionePrecedente versionePrecedente=new VersionePrecedente();
            versionePrecedente.setTesto(versioneCorrente.getTesto());
            versioneCorrente.getPagina().addListVersione(versionePrecedente);
            Pagina p=getPage(titolo,usernameAutore);
            p.setVersioneCorrente(new VersioneCorrente(p));
            p.getVersioneCorrente().setTesto(versionePrecedente.getTesto());
            List<Frase> listaFrasPagina = p.getVersioneCorrente().getTesto().getFrasi();

            Iterator<Frase> iterator = listaFrasPagina.iterator();
            while (iterator.hasNext()) {
                Frase f = iterator.next();
                if (frasiSelezionate.contains(f.getTesto())) {
                    int index = frasiSelezionate.indexOf(f.getTesto());

                    if (modifiche.get(index).equals("")) {
                        iterator.remove(); // Rimuovi usando l'iteratore
                    } else {
                        f.setTesto(modifiche.get(index));
                    }
                }
            }
        }
        /**verificare se è stato insrrito ad ogni modifica /n**/
    }

    public List<String> getTestoPage(String titoloPagina) {
        List<String> testoPage = new ArrayList<>();
        Autore a = null;
        for(int i=0;i<listinoIscritti.getListAutore().size();i++)
        {
            if(getPage(titoloPagina,listinoIscritti.getListAutore().get(i).getLogin())!=null)
            {
                a=listinoIscritti.getListAutore().get(i);
            }
        }

            VersioneCorrente versioneCorrente=getVersioneCorrente(titoloPagina, a.getLogin());
            if (versioneCorrente != null) {
                List<Frase> listFraseTesto = versioneCorrente.getTesto().getFrasi();
                for (Frase f : listFraseTesto) {
                    testoPage.add(f.getTesto());
                }
            }
        
        return testoPage;
    }

    public Boolean isProposta(String usernameAutore, String titolo) {
        Pagina p = getPage(titolo, usernameAutore);
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        System.out.println(a.getListPropostaGestite().size());
        for (VersioneProposta pr : a.getListPropostaGestite()
        ) {
            if (pr.getPagina()==p&&!pr.isElaborato())
                return true;

        }
        return false;
    }

    /*public List<String> getTextProposta(String titolo, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        Pagina p = getPage(titolo, usernameAutore);
        VersioneProposta proposta = null;
        for (VersioneProposta prop : a.getListPropostaGestite()
        ) {
            if (prop.getPagina() == p && !prop.isStato()) {
                if (proposta == null)
                    proposta = prop;
                else if (proposta.getData().isAfter(prop.getData())) {
                    proposta = prop;

                } else if (proposta.getData().equals(prop.getData())) {
                    if (proposta.getOra().isAfter(prop.getOra()))
                        proposta = prop;

                }
            }

        }
        if(proposta!=null) {
            List<String> textProposto = new ArrayList<>();
            int dim;
            dim = textProposto.size();
            for (int i = 0; i < p.getVersioneCorrente().getTesto().getFrasi().size(); i++) {


                for (int j = 0; j < proposta.getListFrase().size(); j++) {
                    if (proposta.getListFrase().get(j).getTesto().equals(p.getVersioneCorrente().getTesto().getFrasi().get(i).getTesto())) {
                        textProposto.add(proposta.getListProposte().get(j));
                    }
                }

                if (dim == textProposto.size()) {
                    textProposto.add(p.getVersioneCorrente().getTesto().getFrasi().get(i).getTesto());
                }
                dim=dim+1;
            }
            return textProposto;
        }
        return null;



    }*/
    public VersioneProposta getVersionePropostaFirst(Pagina pagina, Autore autore) {
        VersioneProposta proposta=null;
        for (VersioneProposta prop : autore.getListPropostaGestite()
        ) {
            if (prop.getPagina() == pagina && !prop.isElaborato()) {
                if (proposta == null)
                    proposta = prop;
                else if (proposta.getData().isAfter(prop.getData())) {
                    proposta = prop;

                } else if (proposta.getData().equals(prop.getData())) {
                    if (proposta.getOra().isAfter(prop.getOra()))
                        proposta = prop;

                }
            }

        }
        return proposta;
    }

    public List<String> getTextProposta(String titolo, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        Pagina p = getPage(titolo, usernameAutore);
        VersioneProposta proposta=getVersionePropostaFirst(p,a);

        /*for (VersioneProposta prop : a.getListPropostaGestite()) {
            if (prop.getPagina() == p && !prop.isElaborato()) {
                if (proposta == null || proposta.getData().isAfter(prop.getData()) ||
                        (proposta.getData().equals(prop.getData()) && proposta.getOra().isAfter(prop.getOra()))) {
                    proposta = prop;
                }
            }
        }*/


        if (proposta != null) {
            List<String> textProposto = new ArrayList<>();

            for (Frase fraseProposta : proposta.getTesto().getFrasi()) {
                textProposto.add(fraseProposta.getTesto());
            }

            return textProposto;
        }

        return null;
    }

    public void leggiListinoAutore()
    {
        AutoreDAO ad =  new ImplementazionePostgresAutoreDao();
        List<String> nomeAutore = new ArrayList<String>();
        List<String> cognomeAutore = new ArrayList<>();
        List<String> login = new ArrayList<>();
        List<String> Password = new ArrayList<>();
        ad.leggiListinoAutore(nomeAutore, cognomeAutore, login, Password);
        for (int i = 0; i < nomeAutore.size(); i++) {
            Autore a = new Autore(nomeAutore.get(i), cognomeAutore.get(i), login.get(i), Password.get(i));
            listinoIscritti.addListAutore(a);
            listinoIscritti.addListUtente(a);
        } // costruisce gli oggetti Model a partire dai risultati del db

    }
    public void leggiListinoUtenti()
    {
        UtenteDAO ud = new ImplementazionePostgresUtenteDao();
        List<String> nomeUtente = new ArrayList<>();
        List<String> cognomeUtente = new ArrayList<>();
        ud.leggiListinoUtenti(nomeUtente, cognomeUtente);
        for (int i = 0; i < nomeUtente.size(); i++) {
            Utente u = new Utente(nomeUtente.get(i), cognomeUtente.get(i));
            listinoIscritti.addListUtente(u);
        }

    }
    public void leggiPagineAutori()
    {
        PaginaDAO pd = new ImplementazionePostgresPaginaDao();
        List<String> TitoloPagina = new ArrayList<>();
        List<String> loginAutorePagina = new ArrayList<>();
        List<Date> dataPagina = new ArrayList<>();
        List<Time> oraPagina = new ArrayList<>();

        pd.leggiPagineAutori(TitoloPagina,dataPagina ,oraPagina, loginAutorePagina);
        for(Autore a : listinoIscritti.getListAutore())
        {
            for(int i = 0; i<TitoloPagina.size(); i++) {
                if (a.getLogin().equals(loginAutorePagina.get(i))) {
                    Pagina p = new Pagina(TitoloPagina.get(i), dataPagina.get(i).toLocalDate(),oraPagina.get(i).toLocalTime(),a);
                    a.addListPagine(p);
                }
            }
        }

    }
    public void leggiFrasiPagina()
    {
        FraseDAO fd = new ImplementazionePostgresFrasiDao();
        List<String> TitoloPaginaFrase = new ArrayList<>();
        List<String> TestoFrase = new ArrayList<>();
        List<Integer> ordineFrase = new ArrayList<>();
        fd.leggiFrasiPagina(TestoFrase,TitoloPaginaFrase,ordineFrase);
        for(Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                for (int i = 0; i < TitoloPaginaFrase.size(); i++) {
                    if (p.getTitolo().equals(TitoloPaginaFrase.get(i)))
                    {
                        Frase frase = new Frase(TestoFrase.get(i),p.getVersioneCorrente().getTesto());
                        p.getVersioneCorrente().getTesto().addFrase(frase);
                    }
                }
            }
        }

    }

    public void InserisciVersionePrecedenteDBA(String titolo, Date dataVersione, Time oraVersione)
    {
        VersionePrecedenteDAO vp = new ImplementazionePostgresVersionePrecedenteDAO();
        vp.InserisciVersionePrecedenteDBA(titolo,dataVersione,oraVersione);
    }

    public void AggiornaVersioneCorrenteDB(String titolo, Date dataVersione, Time oraVersione)
    {
        VersioneCorrenteDAO vc = new ImplementazionePostgresVersioneCorrenteDAO();
        vc.AggiornaVersioneCorrenteDB(titolo,dataVersione,oraVersione);
    }
    public int controlVersionPrecedenti(String usernameUtente, String titolo)
    {
        Pagina p=getPage(titolo,usernameUtente);
        return p.getVersionePrecedenteList().size();
    }

    public void accettaProposta(String usernameAutore, String titolo) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        Pagina p=getPage(titolo,usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,usernameAutore);
        VersioneProposta versioneProposta=getVersionePropostaFirst(p, a);
        versioneProposta.setElaborato(true);
        versioneProposta.setStato(true);
        Testo testoNuovo=versioneProposta.getTesto();
        VersionePrecedente versionePrecedente=new VersionePrecedente();
        versionePrecedente.setTesto(versioneCorrente.getTesto());

        Date data = Date.valueOf(p.getData()); //utilizzo per il db
        Time ora = Time.valueOf(p.getOra());
        InserisciVersionePrecedenteDBA(p.getTitolo(),data,ora); //utilizzo per il db

        p.addListVersione(versionePrecedente);
        versioneCorrente.setTesto(testoNuovo);
        versioneCorrente.setData(LocalDate.now());
        versioneCorrente.setOra(LocalTime.now());

        AggiornaVersioneCorrenteDB(p.getTitolo(),data,ora); //aggiorno la versione corrente
    }


    public void rifiutaProposta(String usernameAutore, String titolo) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        Pagina p=getPage(titolo,usernameAutore);
        VersioneProposta versioneProposta=getVersionePropostaFirst(p, a);
        versioneProposta.setElaborato(true);
        versioneProposta.setStato(false);
    }

    public String getNomeAutore(String usernameAutore) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        return a.getNome();
    }
    public String getCognomeAutore(String usernameAutore) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        return a.getCognome();
    }

    public List<LocalDate> getDataVersione(String titolo, String usernameAutore) {
        Pagina pagina=getPage(titolo,usernameAutore);
        List<LocalDate> data=new ArrayList<>();
        for(int i=0;i<pagina.getVersionePrecedenteList().size();i++)
        {
            data.add(pagina.getVersionePrecedenteList().get(i).getData());
        }
        return data;

    }
    public List<LocalTime> getOraVersione(String titolo, String usernameAutore) {
        Pagina pagina=getPage(titolo,usernameAutore);
        List<LocalTime> orario=new ArrayList<>();
        for(int i=0;i<pagina.getVersionePrecedenteList().size();i++)
        {
            orario.add(pagina.getVersionePrecedenteList().get(i).getOra());
        }
        return orario;

    }

    public List<String> getTestoPageVersione(String titolo, LocalDate dataSelezionata, LocalTime oraSelezionata, String usernameAutore) {
        Pagina pagina=getPage(titolo,usernameAutore);
        Testo testo = null;
        LocalTime oraNotNano = oraSelezionata.withNano(0);
        for(VersionePrecedente versionePrecedente: pagina.getVersionePrecedenteList())
        {

            LocalTime time = versionePrecedente.getOra();

            LocalTime timeNotNano = time.withNano(0);
            if(dataSelezionata.isEqual(versionePrecedente.getData())&&oraNotNano.equals(timeNotNano))
            {
                testo=versionePrecedente.getTesto();
            }
        }
        if(testo!=null)
        {
            List<String> frasiTesto=new ArrayList<>();
            for (Frase frase:testo.getFrasi()) {
                frasiTesto.add(frase.getTesto());
            }
            return frasiTesto;
        }
        return null;
    }

    public boolean isVersioniPrecedenti(String titolo, String usernameAutore) {
        Pagina pagina=getPage(titolo,usernameAutore);
        if(pagina.getVersionePrecedenteList()!=null)
            return true;
        return false;
    }

    public boolean addLink(String titolo, int position, String selectTitle, String usernameAutore) {
        Pagina page=getPage(titolo,usernameAutore);

        Pagina selectPage=getPagina(selectTitle);
        if(selectPage!=null &&page!=null) {
            Frase frase = page.getVersioneCorrente().getTesto().getFrasi().get(position);
            if(frase!=null) {
                Collegamento collegamento = new Collegamento(selectPage, frase);
                frase.setCollegamento(collegamento);
                return true;
            }
        }
        return false;
    }
    public Pagina getPagina(String titolo)
    {
        for (Autore a: listinoIscritti.getListAutore()) {
            for (Pagina p: a.getListPagine()) {
                if(titolo.equals(p.getTitolo()))
                    return p;

            }

        }
        return null;
    }
}

