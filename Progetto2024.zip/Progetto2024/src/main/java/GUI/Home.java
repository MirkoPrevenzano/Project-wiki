package GUI;

import controllerPackage.Controller;

import javax.swing.*;

public class Home {
    private final Controller controller; //nel caso di futuri errori levare final
    private static JFrame frame;
    private JButton Accesso_Autore;
    private JButton Accesso_Utente;
    private JButton Iscriviti;
    private JPanel panel1;
    private JPanel panelAutore;
    private JPanel panelUtente;
    private JPanel panelIscriviti;

    public Home() {
        controller = new Controller(); //creo oggetto controller altrimenti non posso usare metodi implementati da lì
        controller.leggiListinoAutore();
        controller.leggiListinoUtenti();
        controller.leggiPagineAutori();
        controller.leggiFrasiPagina();
        //controller.prova();
        Accesso_Autore.addActionListener(e -> {
            AccessoAutore accessoAutore = new AccessoAutore(Home.this.controller, Home.frame);
            accessoAutore.frame.setVisible(true);
            Home.frame.setVisible(false);
        });
        /*passo al frame per l'iscrizione (l'ho fatta per autore, per iniziare. La mia idea era quella di mettere un opzione che se selezionata sblocca la possibilità
        di inserire anche login e password, il tipo di opzione è l'oggetto jRadioButton e mettere un actionListener che quando l'utente ci clicca sblocca quelle due caselle
        ovviamente poi il metodo Iscizione controlla se sono stati inseriti anche login e password e decide poi se creare oggetto utente o autore.)
         */
        Iscriviti.addActionListener(e -> {
            Iscrizione iscrizione = new Iscrizione(Home.this.controller, Home.frame);
            iscrizione.frame.setVisible(true);
            Home.frame.setVisible(false);

        });
        Accesso_Utente.addActionListener(e -> {
            AccessoUtente accessoUtente = new AccessoUtente(Home.this.controller, Home.frame);
            accessoUtente.frame.setVisible(true);
            Home.frame.setVisible(false);
        });
    }

    public static void main(String[] args) {
        frame = new JFrame("Home");
        Home home = new Home();
        frame.setContentPane(home.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile
        frame.setVisible(true);
        //frame.pack();

    }

}
