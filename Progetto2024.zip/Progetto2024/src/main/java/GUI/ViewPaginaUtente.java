package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ViewPaginaUtente {
    public JFrame frame;
    private JPanel panel1;

    private JList listFrasi;
    private JButton proponiModificaButton;
    private JButton returnButton;



    public ViewPaginaUtente(final Controller controller, final JFrame frameChiamante, List<String> frasi, String titolo, final String nomeUtente, final String cognomeUtente) {

        this.frame = new JFrame(titolo);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(3);
        this.frame.pack();
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile



        this.listFrasi.setModel(new DefaultListModel());
        DefaultListModel model = (DefaultListModel) this.listFrasi.getModel();
        if (frasi != null) {
            for (int i = 0; i < frasi.size(); ++i) {
                model.addElement(frasi.get(i));
            }

            returnButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frame.setVisible(false);
                    frame.dispose();

                    frameChiamante.setVisible(true);
                }
            });

        }

        proponiModificaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CreazioneProposta creazioneProposta=new CreazioneProposta(controller,frame,frasi,titolo,nomeUtente,cognomeUtente);
                creazioneProposta.frame.setVisible(true);
                frame.setVisible(false);
            }
        });




        listFrasi.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (proponiModificaButton.isVisible()) {
                    int index = listFrasi.getSelectedIndex();
                    listFrasi.clearSelection();
                    if (/*controller.isCollegamento(titolo, index)*/index==-1) {
                        // Codice da eseguire se la condizione è vera
                    } else {


                        // Finestra di notifica a scomparsa con timer
                        JOptionPane optionPane = new JOptionPane("Not found", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                        JDialog dialog = optionPane.createDialog("Messaggio di avviso");

                        Timer timer = new Timer(1000, new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                dialog.dispose();
                            }
                        });
                        timer.setRepeats(false); // Esegui il timer solo una volta
                        timer.start();
                        dialog.setVisible(true);
                    }
                }
            }
        });
    }

}
