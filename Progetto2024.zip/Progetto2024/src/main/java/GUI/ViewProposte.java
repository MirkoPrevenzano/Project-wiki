package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViewProposte {
    private JPanel panel1;
    private JList listProposte;
    private JButton returnButton;
    private JPanel panelList;
    private JTextArea textOriginal;
    private JTextArea textProposta;
    private JButton accettaButton;
    private JButton rifiutaButton;
    public JFrame frame;

    public ViewProposte(final Controller controller, final JFrame frameChiamante, final String usernameAutore, String titolo, List<String> frasi, final JFrame frameHomeAutore) {
        this.frame = new JFrame("Proposta");
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(3);
       // this.frame.pack();
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        //frame.setResizable(false); // Imposta la finestra come ridimensionabile
        textProposta.setEditable(false);
        textOriginal.setEditable(false);
        if (frasi != null) {
            for (int i = 0; i < frasi.size(); i++) {
                if(!frasi.get(i).endsWith("\n"))
                    textOriginal.append(frasi.get(i) + "\n");
                else
                    textOriginal.append(frasi.get(i) );
            }
        }
        List<String> textProposto = controller.getTextProposta(titolo, usernameAutore);
        if (textProposto != null) {
            for (int i = 0; i < textProposto.size(); i++) {
                if(!frasi.get(i).endsWith("\n"))
                    textProposta.append(textProposto.get(i) + "\n");
                else
                    textProposta.append(textProposto.get(i) );
            }
        }
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false); //nascondo frame iscrizione
                frameHomeAutore.setVisible(true);//riattivo frame home
                frame.dispose();//rilascio le risorse
                frameChiamante.dispose();
            }
        });
        accettaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    controller.accettaProposta(usernameAutore,titolo);
                    /*accettaButton.setVisible(false);
                    rifiutaButton.setVisible(false);*/
                    returnButton.setVisible(false);
                    if(controller.isProposta(usernameAutore,titolo))
                    {
                        textProposta.setText("");
                        List<String> frasiOriginal=controller.getTestoPage(titolo);
                        JOptionPane.showMessageDialog(frame,"Proposta accettata, aggiornamento effettuato!");
                        List<String> textProposto = controller.getTextProposta(titolo, usernameAutore);
                        if (textProposto != null) {
                            for (int i = 0; i < textProposto.size(); i++) {
                                if(!textProposto.get(i).endsWith("\n"))
                                    textProposta.append(textProposto.get(i) + "\n");
                                else
                                    textProposta.append(textProposto.get(i) );
                            }
                        }
                        textOriginal.setText("");
                        for (int i = 0; i < frasiOriginal.size(); i++) {
                            if(!frasiOriginal.get(i).endsWith("\n"))
                                textOriginal.append(frasiOriginal.get(i) + "\n");
                            else
                                textOriginal.append(frasiOriginal.get(i) );
                        }

                    }
                    else
                    {
                        JOptionPane.showMessageDialog(frame,"Proposta accettata, aggiornamento effettuato! Hai elaborato tutte le proposte");

                        accettaButton.setVisible(false);
                        rifiutaButton.setVisible(false);
                        returnButton.setVisible(true);
                    }
            }
        });
        rifiutaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.rifiutaProposta(usernameAutore,titolo);
               /* accettaButton.setVisible(false);
                rifiutaButton.setVisible(false);*/
                returnButton.setVisible(false);

                if(controller.isProposta(usernameAutore,titolo))
                {
                    List<String> frasiOriginal=controller.getTestoPage(titolo);
                    textProposta.setText("");
                    JOptionPane.showMessageDialog(frame,"Proposta rifiutata");
                    List<String> textProposto = controller.getTextProposta(titolo, usernameAutore);
                    if (textProposto != null) {
                        for (int i = 0; i < textProposto.size(); i++) {
                            if(!textProposto.get(i).endsWith("\n"))
                                textProposta.append(textProposto.get(i) + "\n");
                            else
                                textProposta.append(textProposto.get(i) );
                        }
                    }
                    textOriginal.setText("");
                    for (int i = 0; i < frasiOriginal.size(); i++) {
                        if(!frasiOriginal.get(i).endsWith("\n"))
                            textOriginal.append(frasiOriginal.get(i) + "\n");
                        else
                            textOriginal.append(frasiOriginal.get(i) );
                    }

                }
                else
                {
                    JOptionPane.showMessageDialog(frame,"Proposta rifiutata! Hai elaborato tutte le proposte");
                    /*frame.setVisible(false); //nascondo frame iscrizione
                    frameHomeAutore.setVisible(true);//riattivo frame home
                    frame.dispose();//rilascio le risorse
                    frameChiamante.dispose();*/
                    accettaButton.setVisible(false);
                    rifiutaButton.setVisible(false);
                    returnButton.setVisible(true);
                }
            }
        });
    }



}
