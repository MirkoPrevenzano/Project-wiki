package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class CreazioneProposta {
    private JPanel panel1;
    private JList listFrasi;
    public JFrame frame;
    private JButton modificaFraseButton;
    private JButton eliminaFraseButton;
    private JButton saveReturnButton;

    private List<Integer> frasiSelezionate = new ArrayList<>();

    private List<String> modifiche = new ArrayList<>();


    public CreazioneProposta(final Controller controller, final JFrame frameChiamante, List<String> frasi, String titolo, final String nomeUtente, final String cognomeUtente) {
        this.frame = new JFrame(titolo);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(3);
        this.frame.pack();
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile


        this.listFrasi.setModel(new DefaultListModel());
        DefaultListModel model = (DefaultListModel) this.listFrasi.getModel();
        if (frasi != null) {
            for (int i = 0; i < frasi.size(); ++i) {
                model.addElement(frasi.get(i));
            }

            modificaFraseButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (listFrasi.isSelectionEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Selezione una frase");
                    } else {
                        int selectedIndices = listFrasi.getSelectedIndex();
                        listFrasi.clearSelection();
                        String nuovaFrase = "";
                        nuovaFrase = JOptionPane.showInputDialog("Nuova frase:");
                        if (nuovaFrase != null) {
                            if (!nuovaFrase.isEmpty()) {

                                frasi.set(selectedIndices, nuovaFrase);
                                // controller.modificaTesto(frasi, titolo, usernameAutore);
                                model.clear();
                                for (int i = 0; i < frasi.size(); i++) {
                                    model.addElement(frasi.get(i));
                                }
                                int ctr = 0;
                                for (Integer i : frasiSelezionate
                                ) {
                                    if (i.equals(selectedIndices))
                                        ctr = 1;
                                }
                                if (ctr == 1) {
                                    int i = frasiSelezionate.indexOf(selectedIndices);

                                    // int i = modifiche.indexOf(frasiSelezionate.indexOf(selectedIndices));
                                    modifiche.set(i, nuovaFrase);
                                } else {
                                    frasiSelezionate.add(selectedIndices);
                                    modifiche.add(nuovaFrase);
                                }
                                listFrasi.revalidate();

                            }

                        }

                    }
                }
            });
            eliminaFraseButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (listFrasi.isSelectionEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Selezione una frase");
                    } else {
                        int selectedIndices = listFrasi.getSelectedIndex();
                        listFrasi.clearSelection();
                        frasi.set(selectedIndices," ");

                        model.clear();
                        for (int i = 0; i < frasi.size(); i++) {
                            model.addElement(frasi.get(i));
                        }
                        int ctr = 0;
                        for (Integer i : frasiSelezionate
                        ) {
                            if (i.equals(selectedIndices) )
                                ctr = 1;
                        }
                        if (ctr == 1) {
                            int i = frasiSelezionate.indexOf(selectedIndices);

                            //int i = modifiche.indexOf(frasiSelezionate.indexOf(selectedIndices));
                            modifiche.set(i, "");
                        } else {
                            frasiSelezionate.add(selectedIndices);
                            modifiche.add("");
                        }
                        // controller.modificaTesto(frasi, titolo, usernameAutore);
                        listFrasi.revalidate();
                    }

                }
            });
            saveReturnButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    controller.savePropostaUtente(frasiSelezionate, modifiche, titolo, nomeUtente, cognomeUtente);
                    JOptionPane.showMessageDialog(frame, "Proposta inviata correttamente");
                    frame.setVisible(false);
                    frame.dispose();
                    frameChiamante.setVisible(true);
                }
            });
        }
    }
}
