package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class ViewVersioniPrecedenti {
    private JPanel panel1;
    private JList listVersioni;
    private JButton returnButton;

    public JFrame frame;

    public ViewVersioniPrecedenti(Controller controller, JFrame frameChiamante, String titolo, String usernameAutore) {
        this.frame = new JFrame("Storico: "+titolo);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(3);
        this.frame.pack();
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile
        List<LocalDate> data = controller.getDataVersione(titolo, usernameAutore);
        List<LocalTime> ora = controller.getOraVersione(titolo, usernameAutore);
        this.listVersioni.setModel(new DefaultListModel());
        DefaultListModel model = (DefaultListModel) this.listVersioni.getModel();
        if (data != null && data.size() == ora.size()) {
            for (int i = 0; i < data.size(); ++i) {
                model.addElement(data.get(i) + "  " +
                        String.format("%02d", ora.get(i).getHour()) + ":" +
                        String.format("%02d", ora.get(i).getMinute()) + ":" +
                        String.format("%02d", ora.get(i).getSecond()));
            }
        }
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                frame.dispose();
                frameChiamante.setVisible(true);
            }
        });
        listVersioni.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && !listVersioni.isSelectionEmpty()) {
                    String selectedValue = (String) listVersioni.getSelectedValue();

                    if (selectedValue != null) {
                        String[] parts = selectedValue.split("  ");

                        // Assicurati che ci siano abbastanza parti
                        if (parts.length == 2) {
                            String dataString = parts[0];
                            String oraString = parts[1];

                            // Ora hai dataString e oraString che puoi utilizzare come preferisci
                            LocalDate dataSelezionata = LocalDate.parse(dataString);
                            LocalTime oraSelezionata = LocalTime.parse(oraString);

                            List<String> listaFrasi = controller.getTestoPageVersione(titolo, dataSelezionata, oraSelezionata, usernameAutore);
                            if (listaFrasi != null) {
                                OnlyViewPage onlyViewPage = new OnlyViewPage(controller, frame, listaFrasi, titolo, usernameAutore);
                                onlyViewPage.frame.setVisible(true);
                                ViewVersioniPrecedenti.this.frame.setVisible(false);

                            } else {
                                JOptionPane.showMessageDialog(frame, "Errore nel caricamento!");
                            }

                            listVersioni.clearSelection();
                        } else {
                            // Messaggio di errore se il formato della stringa non è quello previsto
                            JOptionPane.showMessageDialog(frame, "Errore nel formato della data e dell'ora.");
                        }
                    }
                }
            }
        });
    }
}
