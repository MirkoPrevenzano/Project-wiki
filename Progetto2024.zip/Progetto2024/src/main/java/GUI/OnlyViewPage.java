package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class OnlyViewPage {

    public JFrame frame;
    private JPanel panel1;
    private JTextArea textVersione;
    private JButton returnButton;

    public OnlyViewPage(Controller controller, JFrame frameChiamante, List<String> listaFrasi, String titolo, String usernameAutore) {
        this.frame = new JFrame("Proposta");
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(3);
        this.frame.pack();
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile
        textVersione.setEditable(false);



        if (listaFrasi != null) {
            for (int i = 0; i < listaFrasi.size(); i++) {
                if(!listaFrasi.get(i).endsWith("\n"))
                    textVersione.append(listaFrasi.get(i) + "\n");
                else
                    textVersione.append(listaFrasi.get(i) );
            }
        }
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                frame.dispose();
                frameChiamante.setVisible(true);
            }
        });
    }
}
