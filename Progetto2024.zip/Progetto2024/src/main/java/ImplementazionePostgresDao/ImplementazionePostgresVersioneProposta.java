package ImplementazionePostgresDao;

import DAO.VersionePropostaDAO;
import Database.ConnessioneDB;

import java.sql.*;
import java.util.List;

public class ImplementazionePostgresVersioneProposta implements VersionePropostaDAO {
    private Connection connection;

    public ImplementazionePostgresVersioneProposta() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void leggilistinoproposta(List<String> username, List<String> nomeUtente, List<String> cognomeUtente, List<String> titolo, List<Date> data, List<Time> ora, List<Integer> id_testo, List<Integer> id_proposta) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM versioneproposta ");
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                username.add(rs.getString("username"));
                nomeUtente.add(rs.getString("Nome_U"));
                cognomeUtente.add(rs.getString("Cognome_U"));
                titolo.add(rs.getString("titolo"));
                data.add(rs.getDate("data"));
                ora.add(rs.getTime("ora"));
                id_testo.add(rs.getInt("id_testo"));
                id_proposta.add(rs.getInt("id_proposta"));

            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }

    }

    public void leggifrasiselezionate(Integer id_proposta, List<Integer> ordine)
    {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("Select ordine from seleziona\n" +
                    "WHERE id_proposta = ? ");

            leggiListinoPS.setInt(1,id_proposta);
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                ordine.add(rs.getInt("ordine"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        } catch (Exception e) {
            System.out.println("Errore : " + e.getMessage());
        }
    }

    public String leggimodificheproposte(Integer ordine, Integer id_proposta)
    {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("Select testo_modifca from modifica\n" +
                    "WHERE id_proposta = ? AND ordine = ? ");

            leggiListinoPS.setInt(1,id_proposta);
            leggiListinoPS.setInt(2,ordine);
            ResultSet rs = leggiListinoPS.executeQuery();

            String modifiche = null;
            while (rs.next()) {
                modifiche = rs.getString("testo_modifca");
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

            return modifiche;
        } catch (Exception e) {
            System.out.println("Errore : " + e.getMessage());
        }

        return null;
    }

    public void inserisciProposte(String username, String nomeUtente, String cognomeUtente, String titolo, Date data, Time ora, Boolean stato, Boolean elaborato)
    {
        try {
            int test = -1;  // Definisci la variabile test

            try (PreparedStatement get_testo = connection.prepareStatement("SELECT id_testo \n" +
                    "FROM testo JOIN versioneproposta ON versioneproposta.titolo = testo.titolo WHERE versioneproposta.titolo = ?")) {
                get_testo.setString(1, titolo);
                ResultSet rs = get_testo.executeQuery();
                if (rs.next()) {
                    test = rs.getInt("id_testo");
                }
            }

            if (test != -1) {
                // Esegui l'inserimento nella tabella "frase"
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO versioneproposta (titolo, data, ora, id_testo,username,nome_U,cognome_U,stato,elaborato) VALUES (?, ?, ?,?,?,?,?,?,?)")) {
                    inserisciListinoPS.setString(1, titolo);
                    inserisciListinoPS.setDate(2, data);
                    inserisciListinoPS.setTime(3, ora);
                    inserisciListinoPS.setInt(4,test);// Sostituisci con l'ordine desiderato
                    inserisciListinoPS.setString(5,username);
                    inserisciListinoPS.setString(6,nomeUtente);
                    inserisciListinoPS.setString(7,cognomeUtente);
                    inserisciListinoPS.setBoolean(8,stato);
                    inserisciListinoPS.setBoolean(8,elaborato);
                    inserisciListinoPS.executeUpdate();
                }  // Chiusura automatica di PreparedStatement
            } else {
                System.out.println("ID_testo non trovato per il titolo della pagina: " + titolo);
            }

            connection.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }
}
