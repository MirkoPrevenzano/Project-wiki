package ImplementazionePostgresDao;

import DAO.UtenteDAO;
import Database.ConnessioneDB;
import org.w3c.dom.events.UIEvent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ImplementazionePostgresUtenteDao implements UtenteDAO {
    private Connection connection;
    public ImplementazionePostgresUtenteDao()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void leggiListinoUtenti(List<String> nomeUtente, List<String> cognomeUtente)
    {
        try {

            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM utente");
            ResultSet rs = leggiListinoPS.executeQuery();

            while(rs.next())
            {
                nomeUtente.add(rs.getString("nome_u"));
                cognomeUtente.add(rs.getString("cognome"));

            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

        }catch(Exception e)
        {
            System.out.println("Errore: "+e.getMessage());
        }
    }

    public void inserisciUtente(String nome, String cognome) {
        try
        {
            PreparedStatement inserisciListinoPS = connection.prepareStatement(
                    "INSERT INTO utente (nome_u,cognome) VALUES (?,?) ");
            inserisciListinoPS.setString(1,nome);
            inserisciListinoPS.setString(2,cognome);

            inserisciListinoPS.executeUpdate();


            connection.close();
            inserisciListinoPS.close();


        }catch(Exception e)
        {
            System.out.println("Errore: " + e.getMessage());
        }
    }
}
