package ImplementazionePostgresDao;

import DAO.CollegamentoDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ImplementazionePostgresCollegamentoDao implements CollegamentoDAO {
    private Connection connection;

    public ImplementazionePostgresCollegamentoDao() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void leggilistinocollegamento( List<Integer> id_testo, List<Integer> id_collegamento)
    {
        try {
            try (PreparedStatement getTesto = connection.prepareStatement("SELECT DISTINCT id_testo FROM collegamento")) {
                ResultSet rs = getTesto.executeQuery();
                if (rs.next()) {
                    id_testo.add(rs.getInt("id_testo"));
                }
            }
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "SELECT * FROM collegamento")) {
                    ResultSet rs2 = inserisciListinoPS.executeQuery();
                    while(rs2.next())
                    {
                        id_collegamento.add(rs2.getInt("id_collegamento"));
                    }

                }  // Chiusura automatica di PreparedStatement

            connection.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }

    public String leggipaginasorgentecollegamento(Integer id_collegamento)
    {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("select versionecorrente.titolo from versionecorrente JOIN collegamento ON collegamento.id_testo = versionecorrente.id_testo\n" +
                    "WHERE collegamento.id_collegamento = ?");
            leggiListinoPS.setInt(1,id_collegamento);
            ResultSet rs = leggiListinoPS.executeQuery();
            String titolosorgente = null;
            while (rs.next()) {
                titolosorgente = rs.getString("titolo");
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

            return titolosorgente;

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
        return null;
    }

    public  void leggiordinifrasisorgente(String titolosorgente, List<Integer> ordini) // da implementare
    {

    }

    public void inseriscicollegamentiDB(String titolodestinazione, String titolosorgente ,int ordine)
    {
        try {
            int test = -1;

            try (PreparedStatement getTesto = connection.prepareStatement("select collegamento.id_testo " +
                    "from collegamento JOIN versionecorrente ON collegamento.id_testo = versionecorrente.id_testo\n" +
                    "WHERE collegamento.ordine = ? AND versionecorrente.titolo = ?")) {
                getTesto.setInt(1, ordine);
                getTesto.setString(2,titolosorgente);
                ResultSet rs = getTesto.executeQuery();
                if (rs.next()) {
                    test = rs.getInt("id_testo");
                }
            }
            if (test != -1) {
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO collegamento (titolo, id_testo, ordine) VALUES (?, ?, ?)")) {
                    inserisciListinoPS.setString(1, titolodestinazione);
                    inserisciListinoPS.setInt(2, test);
                    inserisciListinoPS.setInt(3, ordine);
                    inserisciListinoPS.executeUpdate();
                }  // Chiusura automatica di PreparedStatement
            }

            connection.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }



}
