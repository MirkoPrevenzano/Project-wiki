package ImplementazionePostgresDao;

import DAO.VersionePrecedenteDAO;
import Database.ConnessioneDB;

import java.sql.*;
import java.util.List;

/**
 * The type Implementazione postgres versione precedente dao.
 */
public class ImplementazionePostgresVersionePrecedenteDAO implements VersionePrecedenteDAO {
    private Connection connection;

    public ImplementazionePostgresVersionePrecedenteDAO() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void leggilistinoversioniprecedenti(List<String> titoloPagina, List<Date> dataVersione, List<Time> oraVersione) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM versioneprecedente");
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                titoloPagina.add(rs.getString("titolo"));
                dataVersione.add(rs.getDate("data"));
                oraVersione.add(rs.getTime("ora"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }

    public void leggifrasiversioneprecedente(String titoloPagina, Date dataVersione, Time oraVersione, List<String> TestoFrase) {
        try {
            // Utilizzo try-with-resources per garantire la chiusura automatica delle risorse
            try (PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM frase " +
                    "JOIN versioneprecedente ON versioneprecedente.id_testo = frase.id_testo " +
                    "WHERE versioneprecedente.titolo = ? AND versioneprecedente.data = ? AND versioneprecedente.ora = ?")) {

                // Impostazione dei parametri
                leggiListinoPS.setString(1, titoloPagina);
                leggiListinoPS.setDate(2, dataVersione);
                leggiListinoPS.setTime(3, oraVersione);

                // Esecuzione della query
                try (ResultSet rs = leggiListinoPS.executeQuery()) {
                    while (rs.next()) {
                        TestoFrase.add(rs.getString("testo_effettivo"));
                    }
                }
            } // La connessione verrà chiusa automaticamente alla fine del blocco try-with-resources

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }

    }

    public void InserisciVersionePrecedenteDBA(String titolo, Date dataVersione, Time oraVersione)
    {
        try {
            int test = -1;  // Definisci la variabile test

            try (PreparedStatement get_testo = connection.prepareStatement("SELECT id_testo \n" +
                    "FROM pagina JOIN versionecorrente ON versionecorrente.titolo = pagina.titolo WHERE versionecorrente.titolo = ?")) {
                get_testo.setString(1, titolo);
                ResultSet rs = get_testo.executeQuery();
                if (rs.next()) {
                    test = rs.getInt("id_testo");
                }
            }

            if (test != -1) {
                // Esegui l'inserimento nella tabella "frase"
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO versioneprecedente (titolo, data, ora, id_testo) VALUES (?, ?, ?,?)")) {
                    inserisciListinoPS.setString(1, titolo);
                    inserisciListinoPS.setDate(2, dataVersione);
                    inserisciListinoPS.setTime(3, oraVersione);
                    inserisciListinoPS.setInt(4,test);// Sostituisci con l'ordine desiderato
                    inserisciListinoPS.executeUpdate();
                }  // Chiusura automatica di PreparedStatement
            } else {
                System.out.println("ID_testo non trovato per il titolo della pagina: " + titolo);
            }

            connection.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }
}
