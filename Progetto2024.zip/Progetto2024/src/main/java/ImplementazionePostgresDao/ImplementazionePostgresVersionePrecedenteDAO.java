package ImplementazionePostgresDao;

import DAO.VersionePrecedenteDAO;
import Database.ConnessioneDB;

import java.sql.*;

public class ImplementazionePostgresVersionePrecedenteDAO implements VersionePrecedenteDAO {
    private Connection connection;
    public ImplementazionePostgresVersionePrecedenteDAO()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void InserisciVersionePrecedenteDBA(String titolo, Date dataVersione, Time oraVersione)
    {
        try {
            int test = -1;  // Definisci la variabile test

            try (PreparedStatement get_testo = connection.prepareStatement("SELECT id_testo \n" +
                    "FROM pagina JOIN versionecorrente ON versionecorrente.titolo = pagina.titolo WHERE versionecorrente.titolo = ?")) {
                get_testo.setString(1, titolo);
                ResultSet rs = get_testo.executeQuery();
                if (rs.next()) {
                    test = rs.getInt("id_testo");
                }
            }

            if (test != -1) {
                // Esegui l'inserimento nella tabella "frase"
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO versioneprecedente (titolo, data, ora, id_testo) VALUES (?, ?, ?,?)")) {
                    inserisciListinoPS.setString(1, titolo);
                    inserisciListinoPS.setDate(2, dataVersione);
                    inserisciListinoPS.setTime(3, oraVersione);
                    inserisciListinoPS.setInt(4,test);// Sostituisci con l'ordine desiderato
                    inserisciListinoPS.executeUpdate();
                }  // Chiusura automatica di PreparedStatement
            } else {
                System.out.println("ID_testo non trovato per il titolo della pagina: " + titolo);
            }

            connection.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }

}
