package ImplementazionePostgresDao;

import DAO.FraseDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * The type Implementazione postgres frasi dao.
 */
public class ImplementazionePostgresFrasiDao implements FraseDAO {

    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres frasi dao.
     */
    public ImplementazionePostgresFrasiDao()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void leggiFrasiPagina(List<String> testoFrase, List<String> titoloPagina, List<Integer> ordine)
    {
        try
        {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM (frase NATURAL INNER JOIN testo) NATURAL INNER JOIN pagina ORDER BY username, titolo, ordine ");
            ResultSet rs = leggiListinoPS.executeQuery();
            while(rs.next())
            {
                testoFrase.add(rs.getString("testo_effettivo"));
                titoloPagina.add(rs.getString("titolo"));
                ordine.add(rs.getInt("ordine"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        }catch(Exception e)
        {
            System.out.println("Errore: "+e.getMessage());
        }
    }

    public void inserisciFrase_DB(String testoFrase, int ordine, String titoloPagina) {
        try {
            int test = -1;

            try (PreparedStatement getTesto = connection.prepareStatement("SELECT id_testo \n" +
                    "FROM pagina JOIN versionecorrente ON versionecorrente.titolo = pagina.titolo WHERE versionecorrente.titolo = ?")) {
                getTesto.setString(1, titoloPagina);
                ResultSet rs = getTesto.executeQuery();
                if (rs.next()) {
                    test = rs.getInt("id_testo");
                }
            }

            if (test != -1) {
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO frase (testo_effettivo, id_testo, ordine) VALUES (?, ?, ?)")) {
                    inserisciListinoPS.setString(1, testoFrase);
                    inserisciListinoPS.setInt(2, test);
                    inserisciListinoPS.setInt(3, ordine);
                    inserisciListinoPS.executeUpdate();
                }  // Chiusura automatica di PreparedStatement
            } else {
                System.out.println("ID_testo non trovato per il titolo della pagina: " + titoloPagina);
            }

            connection.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }



    }
}
