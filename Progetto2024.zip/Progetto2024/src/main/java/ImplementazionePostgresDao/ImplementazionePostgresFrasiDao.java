package ImplementazionePostgresDao;

import DAO.FraseDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ImplementazionePostgresFrasiDao implements FraseDAO {
    private Connection connection;
    public ImplementazionePostgresFrasiDao()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void leggiFrasiPagina(List<String> TestoFrase, List<String> TitoloPagina, List<Integer> ordine)
    {
        try
        {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM (frase NATURAL INNER JOIN testo) NATURAL INNER JOIN pagina ORDER BY username, titolo, ordine ");
            ResultSet rs = leggiListinoPS.executeQuery();

            while(rs.next())
            {
                TestoFrase.add(rs.getString("testo"));
                TitoloPagina.add(rs.getString("titolo"));
                ordine.add(rs.getInt("ordine"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

        }catch(Exception e)
        {
            System.out.println("Errore: "+e.getMessage());
        }
    }
}
