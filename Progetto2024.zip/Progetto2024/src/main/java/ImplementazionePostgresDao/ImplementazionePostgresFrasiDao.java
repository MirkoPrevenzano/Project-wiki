package ImplementazionePostgresDao;

import DAO.FraseDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ImplementazionePostgresFrasiDao implements FraseDAO {

    private Connection connection;
    public ImplementazionePostgresFrasiDao()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void leggiFrasiPagina(List<String> TestoFrase, List<String> TitoloPagina, List<Integer> ordine)
    {
        try
        {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM (frase NATURAL INNER JOIN testo) NATURAL INNER JOIN pagina ORDER BY username, titolo, ordine ");
            ResultSet rs = leggiListinoPS.executeQuery();
            while(rs.next())
            {
                TestoFrase.add(rs.getString("testo_effettivo"));
                TitoloPagina.add(rs.getString("titolo"));
                ordine.add(rs.getInt("ordine"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        }catch(Exception e)
        {
            System.out.println("Errore: "+e.getMessage());
        }
    }

    public void inserisciFrase_DB(String TestoFrase, int ordine, String titolo_pagina) {
        try {
            int test = -1;  // Definisci la variabile test

            try (PreparedStatement get_testo = connection.prepareStatement("SELECT id_testo \n" +
                    "FROM pagina JOIN versionecorrente ON versionecorrente.titolo = pagina.titolo WHERE versionecorrente.titolo = ?")) {
                get_testo.setString(1, titolo_pagina);
                ResultSet rs = get_testo.executeQuery();
                if (rs.next()) {
                    test = rs.getInt("id_testo");
                }
            }

            if (test != -1) {
                // Esegui l'inserimento nella tabella "frase"
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO frase (testo_effettivo, id_testo, ordine) VALUES (?, ?, ?)")) {
                    inserisciListinoPS.setString(1, TestoFrase);
                    inserisciListinoPS.setInt(2, test);
                    inserisciListinoPS.setInt(3, ordine);  // Sostituisci con l'ordine desiderato
                    inserisciListinoPS.executeUpdate();
                }  // Chiusura automatica di PreparedStatement
            } else {
                System.out.println("ID_testo non trovato per il titolo della pagina: " + titolo_pagina);
            }

            connection.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }



    }
}
