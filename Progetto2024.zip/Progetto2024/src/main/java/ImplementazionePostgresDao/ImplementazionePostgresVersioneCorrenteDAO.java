package ImplementazionePostgresDao;

import DAO.VersioneCorrenteDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;

public class ImplementazionePostgresVersioneCorrenteDAO implements VersioneCorrenteDAO {
    private Connection connection;
    public ImplementazionePostgresVersioneCorrenteDAO()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void AggiornaVersioneCorrenteDB(String titolo, Date dataVersione, Time oraVersione) //da completare dopo proposte
    {

    }
}
