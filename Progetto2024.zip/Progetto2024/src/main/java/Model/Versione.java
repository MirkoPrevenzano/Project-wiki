package Model;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * The type Versione.
 */
public class Versione {
    private Testo testo;
    private LocalDate data;
    private LocalTime ora;

    /**
     * Instantiates a new Versione.
     */
    public Versione()
    {
        this.data = LocalDate.now();
        this.ora = LocalTime.now();
        testo=new Testo(this);
    }
    public Versione(LocalDate date, LocalTime time)
    {
        this.data = date;
        this.ora = time;
        testo=new Testo(this);
    }

    /**
     * Gets testo.
     *
     * @return the testo
     */
    public Testo getTesto() {
        return testo;
    }

    /**
     * Sets testo.
     *
     * @param testo the testo
     */
    public void setTesto(Testo testo) {
        this.testo = testo;
    }

    /**
     * Gets data.
     *
     * @return the data
     */
    public LocalDate getData() {return data;}

    /**
     * Sets data.
     *
     * @param data the data
     */
    public void setData(LocalDate data) {this.data = data;}

    /**
     * Gets ora.
     *
     * @return the ora
     */
    public LocalTime getOra() {return ora;}

    /**
     * Sets ora.
     *
     * @param ora the ora
     */
    public void setOra(LocalTime ora) {this.ora = ora;}
}
