package Model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Versione {
    private Testo testo;
    private LocalDate data;
    private LocalTime ora;
    public Versione()
    {
        this.data = LocalDate.now();
        this.ora = LocalTime.now();
        testo=new Testo();
    }

    public Testo getTesto() {
        return testo;
    }

    public void setTesto(Testo testo) {
        this.testo = testo;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getOra() {
        return ora;
    }

    public void setOra(LocalTime ora) {
        this.ora = ora;
    }
}
