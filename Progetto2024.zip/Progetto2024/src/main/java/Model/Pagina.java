package Model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Pagina {
    private String titolo;
    private VersioneCorrente versioneCorrente;

    private LocalDate data;

    private LocalTime ora;
    private List<VersionePrecedente> versionePrecedenteList;
    private Autore autore;

    public Pagina(String titolo, Autore autore)
    {
        this.titolo = titolo;
        versionePrecedenteList=new ArrayList<>();
        versioneCorrente=new VersioneCorrente(this);
        this.autore = autore;
        this.data = LocalDate.now();
        this.ora = LocalTime.now();

    }
    public Pagina(String titolo, LocalDate data, LocalTime ora, Autore autore)
    {
        this.titolo = titolo;
        versionePrecedenteList=new ArrayList<>();
        this.autore = autore;
        versioneCorrente=new VersioneCorrente(this);
        this.data = LocalDate.now();
        this.ora = LocalTime.now();
    }

    public Autore getAutore() {
        return autore;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setAutore(Autore autore) {
        this.autore = autore;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public VersioneCorrente getVersioneCorrente() {
        return versioneCorrente;
    }

    public List<VersionePrecedente> getVersionePrecedenteList() {
        return versionePrecedenteList;
    }

    public void setVersionePrecedenteList(List<VersionePrecedente> versionePrecedenteList) {
        this.versionePrecedenteList = versionePrecedenteList;
    }
    public void addListVersione(VersionePrecedente versionePrecedente)
    {
        versionePrecedenteList.add(versionePrecedente);
    }
    public void setVersioneCorrente(VersioneCorrente versioneCorrente) {
        this.versioneCorrente = versioneCorrente;
    }

    public LocalDate getData() {return data;}

    public void setOra(LocalTime ora) {this.ora = ora;}

    public LocalTime getOra() {return ora;}

    public void setData(LocalDate data) {this.data = data;}
}
