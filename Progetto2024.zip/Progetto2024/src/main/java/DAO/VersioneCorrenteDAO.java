package DAO;

import java.sql.Date;
import java.sql.Time;

public interface VersioneCorrenteDAO {
    void AggiornaVersioneCorrenteDB(String titolo, Date dataVersione, Time oraVersione);
}
