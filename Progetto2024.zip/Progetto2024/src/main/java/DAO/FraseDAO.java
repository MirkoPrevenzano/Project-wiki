package DAO;

import java.util.List;

/**
 * The interface Frase dao.
 */
public interface FraseDAO {
    /**
     * Leggi frasi pagina.
     *
     * @param TestoFrase   the testo frase
     * @param TitoloPagina the titolo pagina
     * @param ordine       the ordine
     */
    void leggiFrasiPagina(List<String> TestoFrase, List<String> TitoloPagina, List<Integer> ordine);

    /**
     * Inserisci frase db.
     *
     * @param TestoFrase the testo frase
     * @param ordine     the ordine
     * @param titolo     the titolo
     */
    void inserisciFrase_DB(String TestoFrase, int ordine, String titolo);

}
