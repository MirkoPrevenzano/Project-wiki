package DAO;

import java.sql.Time;
import java.sql.Date;
import java.util.List;

public interface PaginaDAO {
    void leggiPagineAutori(List<String> TitoloPagina, List<Date> DataPagina, List<Time> oraPagina, List<String> loginAutore);
    void inserisciPagine(String TitoloPagina, Date dataPagina, Time oraPagina, String usernameAutore);
}
