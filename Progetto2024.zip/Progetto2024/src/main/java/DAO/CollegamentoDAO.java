package DAO;

import java.util.List;

public interface CollegamentoDAO {

    void leggilistinocollegamento(List<Integer> id_testo, List<Integer> id_collegamento);
    String leggipaginasorgentecollegamento(Integer id_collegamento);

    void leggiordinifrasisorgente(String titolosorgente, List<Integer> ordini);

    void inseriscicollegamentiDB(String titolodestinazione, String titolosorgente ,int ordine);
}
