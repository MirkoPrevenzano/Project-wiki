package DAO;

import java.util.List;

public interface AutoreDAO {
    void leggiListinoAutore(List<String> nomeAutore, List<String> cognomeAutore, List<String> login, List<String> password);

    void inserisciAutore(String nomeAutore, String cognomeAutore, String username, String password);
}
