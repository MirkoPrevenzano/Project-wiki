package DAO;

import java.util.List;

/**
 * The interface Utente dao.
 */
public interface UtenteDAO {
    /**
     * Leggi listino utenti.
     *
     * @param nomeUtente    the nome utente
     * @param cognomeUtente the cognome utente
     */
    void leggiListinoUtenti(List<String> nomeUtente, List<String> cognomeUtente);

    /**
     * Inserisci utente.
     *
     * @param nome    the nome
     * @param cognome the cognome
     */
    void inserisciUtente(String nome, String cognome);
}
