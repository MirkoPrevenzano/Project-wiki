package DAO;

import java.util.List;

public interface UtenteDAO {
    void leggiListinoUtenti(List<String> nomeUtente, List<String> cognomeUtente);
    void inserisciUtente(String nome, String cognome);
}
