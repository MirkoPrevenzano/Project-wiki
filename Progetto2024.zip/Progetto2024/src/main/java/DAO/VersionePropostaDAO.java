package DAO;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

public interface VersionePropostaDAO {
    void leggilistinoproposta(List<String> username, List<String> nomeUtente, List<String> cognomeUtente, List<String> titolo, List<Date> data, List<Time> ora, List<Integer> id_testo, List<Integer> id_proposta);

    void leggifrasiselezionate(Integer id_proposta, List<Integer> ordine);

    String leggimodificheproposte(Integer ordine, Integer id_proposta);

    void inserisciProposte(String username, String nomeUtente, String cognomeUtente, String titolo, Date data, Time ora, Boolean stato, Boolean elaborato);
}
