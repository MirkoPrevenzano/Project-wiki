package DAO;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

/**
 * The interface Versione precedente dao.
 */
public interface VersionePrecedenteDAO {

    void leggilistinoversioniprecedenti(List<String> titoloPagina, List<Date> dataVersione, List<Time> oraVersione);

    void leggifrasiversioneprecedente(String titoloPagina, Date dataVersione, Time oraVersione,List<String> TestoFrase);

    void InserisciVersionePrecedenteDBA(String titolo, Date dataVersione, Time oraVersione);
}
