package gui;

import controllerPackage.Controller;

import javax.swing.*;

/**
 * The type Accesso utente.
 */
public class AccessoUtente {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JPanel panel1;
    private JTextField textName;
    private JTextField textSurname;
    private JButton buttonReturn;
    private JButton buttonAccess;
    private Timer messageTimer;

    /**
     * Instantiates a new Accesso utente.
     *
     * @param controller    the controller
     * @param framePrevious the frame previous
     */
    public AccessoUtente(final Controller controller, final JFrame framePrevious) {
        frame = new JFrame("Accesso utente");
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(420, 120);
        frame.setResizable(false);
        frame.setLocationRelativeTo(framePrevious);
        frame.setVisible(true);

        buttonReturn.addActionListener(e -> {
            frame.setVisible(false);
            framePrevious.setVisible(true);
            frame.dispose();
        });


        buttonAccess.addActionListener(e -> {
            if (textName.getText().isBlank() || textSurname.getText().isBlank()) {
               showMessage("Compila tutti i campi");
            } else {
                Boolean ctr = controller.accessUtente(AccessoUtente.this.textName.getText(), AccessoUtente.this.textSurname.getText());
                if (Boolean.TRUE.equals(ctr)) {
                    SchermataUtente schermataUtente = new SchermataUtente(controller, frame, AccessoUtente.this.textName.getText(), AccessoUtente.this.textSurname.getText());
                    frame.setVisible(false);
                    schermataUtente.frame.setVisible(true);
                    textName.setText("");
                    textSurname.setText("");

                } else {
                    showMessage( "Utente non presente");
                }

            }
        });

    }

    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }
}


