package gui;

import controllerPackage.Controller;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.util.List;

/**
 * The type Schermata utente.
 */
public class SchermataUtente {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JPanel panel1;
    private JButton returnButton;
    private JTextField textTitle;
    private JButton upButton;
    private JList<String> listPage;

    /**
     * Instantiates a new Schermata utente.
     *
     * @param controller    the controller
     * @param framePrevious the frame previous
     * @param nameUtente    the name utente
     * @param surnameUtente the surname utente
     */
    public SchermataUtente(final Controller controller, final JFrame framePrevious, final String nameUtente, final String surnameUtente) {


        frame = new JFrame("Utente:"+nameUtente+" "+surnameUtente);
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);

        List<String> listTitles=controller.uploadTitles();
        DefaultListModel<String > listModel=new DefaultListModel<>();
        listPage.setModel(listModel);

            for (String s : listTitles) {
                listModel.addElement(s);
            }


            returnButton.addActionListener(e -> {
                frame.setVisible(false);
                framePrevious.setVisible(true);
                frame.dispose();
            });


            upButton.addActionListener(e -> {
                listModel.clear();
                listPage.setVisible(true);
                for (String s : listTitles) {
                    listModel.addElement(s);
                }
            });
            listPage.addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && !listPage.isSelectionEmpty()) {
                    String title = listPage.getSelectedValue();
                    List<String> listPhrase = controller.getTestoPage(title);
                    ViewPaginaUtente viewPaginaUtente = new ViewPaginaUtente(controller, frame, listPhrase, title, nameUtente, surnameUtente);
                    viewPaginaUtente.frame.setVisible(true);
                    frame.setVisible(false);
                    listPage.clearSelection();
                }
            });

            textTitle.getDocument().addDocumentListener(new DocumentListener() {
                @Override
                public void insertUpdate(DocumentEvent e) {

                    handleUpdate();
                }

                @Override
                public void removeUpdate(DocumentEvent e) {

                    handleUpdate();
                }

                @Override
                public void changedUpdate(DocumentEvent e) {
                    // TODO document why this method is empty
                }


                private void handleUpdate() {
                    listModel.clear();
                    for (String listTitle : listTitles) {

                        if (listTitle.contains(textTitle.getText()))
                            listModel.addElement(listTitle);
                    }
                }
            });

    }
}



