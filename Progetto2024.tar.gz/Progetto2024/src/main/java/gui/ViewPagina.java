package gui;

import controllerPackage.Controller;
import javax.swing.*;
import java.util.List;

/**
 * The type View pagina.
 */
public class ViewPagina {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JPanel panel1;
    private JList <String>listPhrases;
    private JButton modifyButton;
    private JButton addLinkButton;
    private JButton returnButton;
    private JButton proposalButton;
    private JButton previousVersionButton;
    private JButton removePageButton;
    private JToolBar toolBar;
    private Timer messageTimer;

    /**
     * Instantiates a new View pagina.
     *
     * @param controller     the controller
     * @param framePrevious  the frame previous
     * @param usernameAutore the username autore
     * @param phrases        the phrases
     * @param title          the title
     */
    public ViewPagina(final Controller controller, final JFrame framePrevious, final String usernameAutore, List<String> phrases, String title) {
        this.frame = new JFrame(title);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);

        toolBar.setFloatable(false);
        returnButton.setVisible(true);

        DefaultListModel<String> listModel=new DefaultListModel<>();
        this.listPhrases.setModel(listModel);

            for (String phrase : phrases) {
                listModel.addElement(phrase);
            }

            proposalButton.addActionListener(e -> {
                Boolean ctr = controller.isProposta(usernameAutore, title);
                if (Boolean.TRUE.equals(ctr)) {
                    ViewProposte viewProposte = new ViewProposte(controller, frame, usernameAutore, title, phrases, framePrevious);
                    viewProposte.frame.setVisible(true);
                    frame.setVisible(false);
                }
                else {
                        showMessage("Non ci sono proposte!");
                    }
                });


            modifyButton.addActionListener(e -> {
                String nameAutore=controller.getNomeAutore(usernameAutore);
                String surnameAutore=controller.getCognomeAutore(usernameAutore);
                CreazioneProposta creazioneProposta=new CreazioneProposta(controller,frame,phrases,title,nameAutore,surnameAutore);
                creazioneProposta.frame.setVisible(true);
                frame.setVisible(false);

            });


            returnButton.addActionListener(e -> {

                frame.setVisible(false);
                frame.dispose();
                framePrevious.setVisible(true);
            });


        previousVersionButton.addActionListener(e -> {
            if(controller.isVersioniPrecedenti(title,usernameAutore)) {
                ViewVersioniPrecedenti viewVersioniPrecedenti = new ViewVersioniPrecedenti(controller, frame, title, usernameAutore);
                frame.setVisible(false);
                viewVersioniPrecedenti.frame.setVisible(true);
            }
            else
            {
                showMessage("Non ci sono versioni precedenti!");
            }
        });


        addLinkButton.addActionListener(e -> {
            if(!listPhrases.isSelectionEmpty())
            {
                int position= listPhrases.getSelectedIndex();
                CreateLink createLink=new CreateLink(controller,frame,position,title,usernameAutore);
                createLink.frame.setVisible(true);
            }
            else
            {
                showMessage("Seleziona una frase!");
            }
        });


        removePageButton.addActionListener(e -> {
            boolean ctr=controller.deletePage(title,usernameAutore);
            if(ctr)
            {
                JOptionPane.showMessageDialog(frame, "Pagina cancellata correttamente");
                frame.setVisible(false);
                frame.dispose();
                framePrevious.setVisible(true);

            }
            else
            {
                showMessage("Errore generico, operazione non riuscita");
            }
        });


    }
    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }

}
