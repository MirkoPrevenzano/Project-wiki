package gui;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ViewProposteAutore {
    public final JFrame frame;
    private JList<String> listProposed;
    private JPanel panel1;
    private JButton returnButton;

    List<String> listTitle=new ArrayList<>();
    List<LocalDate> date = new ArrayList<>();
    List<LocalTime> time =new ArrayList<>();

    public ViewProposteAutore(final JFrame framePrevious, final Controller controller,final String usernameAutore) {
        frame = new JFrame(usernameAutore+" [Proposte effettuate]");
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);
        insertList(controller, usernameAutore);


        listProposed.addListSelectionListener(e -> {

        });
        returnButton.addActionListener(e -> {
            frame.setVisible(false);
            frame.dispose();
            framePrevious.setVisible(true);
        });
        listProposed.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    if (listProposed.getSelectedIndex() != -1 && listProposed.getModel().getElementAt(listProposed.getSelectedIndex()).isEmpty()) {

                        listProposed.clearSelection();
                    } else {

                        int index = listProposed.locationToIndex(e.getPoint());
                        String title=listTitle.get(listProposed.getSelectedIndex());

                        listProposed.setSelectedIndex(index);
                        JPopupMenu popupMenu = createPopupMenu(controller, framePrevious,title, usernameAutore );
                        popupMenu.show(listProposed, e.getX(), e.getY());

                    }

                }
            }
        });

    }


    private JPopupMenu createPopupMenu(Controller controller,JFrame framePrevious, String titolo, String usernameAutore) {
        JPopupMenu popupMenu = new JPopupMenu();

        JMenuItem showPreviousVersionsItem = new JMenuItem("Mostra versioni precedenti");
        showPreviousVersionsItem.addActionListener(e -> {
            String usernameAutorePage=controller.getUsernameByTitle(titolo);
            ViewVersioniPrecedenti viewVersioniPrecedenti=new ViewVersioniPrecedenti(controller,framePrevious,titolo, usernameAutorePage);
            viewVersioniPrecedenti.frame.setVisible(true);
            frame.setVisible(false);
        });
        popupMenu.add(showPreviousVersionsItem);

        JMenuItem showProposedVersionItem = new JMenuItem("Mostra versione proposta");
        showProposedVersionItem.addActionListener(e -> {
            String usernameAutorePage=controller.getUsernameByTitle(titolo);
            LocalTime timePage=time.get(listProposed.getSelectedIndex());
            LocalDate datePage=date.get(listProposed.getSelectedIndex());

            List<String> textVersion =controller.getTestoPageVersioneProposta(titolo,datePage,timePage,usernameAutorePage,usernameAutore);
            System.out.println("ss");
            for(String t:textVersion)
            {
                System.out.println(t);
            }
            OnlyViewPage onlyViewPage=new OnlyViewPage(framePrevious,textVersion,titolo, "Proposta" );
            onlyViewPage.frame.setVisible(true);
            frame.setVisible(false);
        });
        popupMenu.add(showProposedVersionItem);

        JMenuItem showCurrentVersionItem = new JMenuItem("Mostra versione corrente");
        showCurrentVersionItem.addActionListener(e -> {
            String usernameAutorePage=controller.getUsernameByTitle(titolo);
            List<String> textVersion =controller.getTestoPage(titolo);
            OnlyViewPage onlyViewPage=new OnlyViewPage(framePrevious,textVersion,titolo, usernameAutorePage );
            onlyViewPage.frame.setVisible(true);
            frame.setVisible(false);

        });
        popupMenu.add(showCurrentVersionItem);

        return popupMenu;
    }
    private void insertList(Controller controller, String usernameAutore) {
        listTitle=controller.getTitlesProposed(usernameAutore);
        date=controller.getDateProposed( usernameAutore);
        time=controller.getTimeProposed( usernameAutore);
        DefaultListModel<String> listModel=new DefaultListModel<>();
        listProposed.setModel(listModel);
        if (date != null && date.size() == time.size()&&time.size()==listTitle.size()) {
            for (int i = 0; i < date.size(); ++i) {
                listModel.addElement("Titolo: "+listTitle.get(i)+"   invio: "+date.get(i) + "  " +
                        String.format("%02d", time.get(i).getHour()) + ":" +
                        String.format("%02d", time.get(i).getMinute()) + ":" +
                        String.format("%02d", time.get(i).getSecond()));
            }
        }
    }

}
