package gui;

import controllerPackage.Controller;
import javax.swing.*;
import java.util.List;

/**
 * The type Create link.
 */
public class CreateLink {
    private JComboBox <String> titleComboBox;
    private JButton addButton;
    private JPanel panel1;

    /**
     * The Frame.
     */
    public  final JFrame frame;
    private Timer messageTimer;

    /**
     * Instantiates a new Create link.
     *
     * @param controller     the controller
     * @param framePrevious  the frame previous
     * @param position       the position
     * @param title          the title
     * @param usernameAutore the username autore
     */
    public CreateLink(final Controller controller, final JFrame framePrevious, final int position,  final String title, final String usernameAutore )
    {
        this.frame = new JFrame("");
        this.frame.setContentPane(this.panel1);
        frame.setSize(300, 100);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);

        List<String> titles=controller.uploadTitles();
        titles.remove(title);


        titleComboBox.addItem("");
        for (String title1 : titles) {
            titleComboBox.addItem(title1);
        }


        addButton.addActionListener(e -> {
            String selectTitle= (String) titleComboBox.getSelectedItem();
            if(selectTitle!=null) {

                if (controller.addLink(title, position, selectTitle, usernameAutore)) {
                    JOptionPane.showMessageDialog(frame, "Collegamento aggiunto");
                    frame.setVisible(false);
                }
                else {
                    showMessage("Errore nell'inserimento!");
                }
            }
            else
            {
                showMessage("Seleziona una frase");
            }

        });
    }

    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }
}
