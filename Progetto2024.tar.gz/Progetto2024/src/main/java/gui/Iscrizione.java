package gui;

import controllerPackage.Controller;

import javax.swing.*;

/**
 * The type Iscrizione.
 */
public class Iscrizione {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JLabel username;
    private JLabel password;
    private JTextField textSurname;
    private JTextField textUsername;
    private JTextField textPassword;
    private JTextField textName;
    private JPanel panel1;
    private JButton returnButton;
    private JButton registrationButton;
    private JRadioButton buttonAutore;
    private Timer messageTimer;

    /**
     * Instantiates a new Iscrizione.
     *
     * @param controller    the controller
     * @param framePrevious the frame previous
     */
    public Iscrizione(final Controller controller, final JFrame framePrevious) {
        frame = new JFrame("Registrazione");
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setResizable(false);
        frame.setLocationRelativeTo(framePrevious);

        setComponent(false);

        returnButton.addActionListener(e -> {
            frame.setVisible(false);
            framePrevious.setVisible(true);
            frame.dispose();

        });


        registrationButton.addActionListener(e -> {
            if (buttonAutore.isSelected()) {

                if (textName.getText().isBlank() || textSurname.getText().isBlank() || textUsername.getText().isBlank() || textPassword.getText().isBlank()) {
                    showMessage("Compila tutti i campi");
                }
                else {

                    boolean ctr = controller.addNewAutore(textName.getText(), textSurname.getText(), textUsername.getText(), textPassword.getText());
                    registrationMethod( framePrevious, ctr,"Autore");

                }

            }
            else {

                if (textName.getText().isBlank() || textSurname.getText().isBlank()) {
                    showMessage( "Compila tutti i campi");
                }
                else {
                    boolean ctr = controller.addNewUtente(Iscrizione.this.textName.getText(), Iscrizione.this.textSurname.getText());
                    registrationMethod( framePrevious, ctr,"Utente");

                }

            }


        });
        buttonAutore.addActionListener(e -> setComponent(buttonAutore.isSelected()));
    }

    private void registrationMethod(JFrame framePrevious, boolean ctr, String type) {

        if (ctr) {
            completeRegistration(framePrevious);


        } else
            showMessage(type+ "già iscritto");

    }

    private void completeRegistration(JFrame framePrevious) {
        JOptionPane.showMessageDialog(frame, "Iscrizione completata con successo");
        frame.setVisible(false);
        framePrevious.setVisible(true);
        frame.dispose();
    }


    private void setComponent(Boolean value)
    {
        textUsername.setVisible(value);
        textPassword.setVisible(value);
        username.setVisible(value);
        password.setVisible(value);
    }


    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }
}
