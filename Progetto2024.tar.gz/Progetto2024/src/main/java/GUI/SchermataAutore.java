package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


public class SchermataAutore {
    public JFrame frame;

    private JPanel panel1;
    private JButton buttonReturn;
    private JButton buttonCreatePage;
    private JButton aggiornaButton;
    private JList<String> listPage;
    private JPanel panelList;
    private JButton schermataPrincipaleButton;
    private JToolBar toolBar;

    public SchermataAutore(final Controller controller, final JFrame frameChiamante, final String usernameAutore) {
        this.frame = new JFrame("Profilo:" + usernameAutore);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(3);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(frameChiamante);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile
        toolBar.setFloatable(false);
        frame.setVisible(true);


        List<String> listTitoli = controller.caricaTitoli(usernameAutore);
        this.listPage.setModel(new DefaultListModel());
        DefaultListModel model = (DefaultListModel) this.listPage.getModel();
        if (listTitoli != null) {
            for (int i = 0; i < listTitoli.size(); ++i) {
                model.addElement(listTitoli.get(i));
            }
        }

        if(controller.isNotifyProposta(usernameAutore))
        {
                JOptionPane optionPane = new JOptionPane("Ci sono delle nuove proposte", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                JDialog dialog = optionPane.createDialog("Notifica");

                Timer timer = new Timer(1000, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dialog.dispose();
                    }
                });
                timer.setRepeats(false); // Esegui il timer solo una volta
                timer.start();
                dialog.setVisible(true);
        }


            buttonReturn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frame.setVisible(false);
                    frame.dispose();
                    frameChiamante.setVisible(true);
                }
            });

            buttonCreatePage.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {


                    CreazionePagina creazionePagina = new CreazionePagina(controller, SchermataAutore.this.frame, usernameAutore, listTitoli);
                    SchermataAutore.this.frame.setVisible(false);
                    creazionePagina.frame.setVisible(true);
                }
            });

            aggiornaButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    model.clear();
                    listPage.setVisible(true);
                    List<String> listTitoli = controller.caricaTitoli(usernameAutore);

                    for (int i = 0; i < listTitoli.size(); i++) {
                        model.addElement(listTitoli.get(i));
                    }
                }
            });

            listPage.addListSelectionListener(new ListSelectionListener() {
                @Override
                public void valueChanged(ListSelectionEvent e) {
                    if (!e.getValueIsAdjusting() && !listPage.isSelectionEmpty()) {
                        List<String> listaFrasi = controller.getTestoPage(listPage.getSelectedValue(), usernameAutore);
                        if (listaFrasi != null) {
                            ViewPagina viewPagina = new ViewPagina(controller, frame, usernameAutore, listaFrasi, listPage.getSelectedValue());
                            viewPagina.frame.setVisible(true);
                            SchermataAutore.this.frame.setVisible(false);
                            listPage.clearSelection();
                        } else {
                            JOptionPane optionPane = new JOptionPane("Pagina selezionata non esistente, aggiorna la lista!", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                            JDialog dialog = optionPane.createDialog("Messaggio di avviso");

                            Timer timer = new Timer(1000, new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    dialog.dispose();
                                }
                            });
                            timer.setRepeats(false); // Esegui il timer solo una volta
                            timer.start();
                            dialog.setVisible(true);

                        }

                    }
                }
            });
        schermataPrincipaleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nomeAutore = controller.getNomeAutore(usernameAutore);
                String cognomeAutore = controller.getCognomeAutore(usernameAutore);

                SchermataUtente schermataUtente = new SchermataUtente(controller, frame, nomeAutore, cognomeAutore);
                SchermataAutore.this.frame.setVisible(false);
                schermataUtente.frame.setVisible(true);
            }
        });

        }

}



