package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class CreateLink {
    private JComboBox titleComboBox;
    private JButton addButton;
    private JPanel panel1;

    public  JFrame frame;
    public CreateLink(final Controller controller, final JFrame frameChiamante,final int position, final String frase, final String titolo, final String usernameAutore )
    {
        this.frame = new JFrame("Utente");
        this.frame.setContentPane(this.panel1);
        frame.setSize(300, 100);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile
        List<String> titoli=controller.caricaTitoli();
        titoli.remove(titolo);
        DefaultComboBoxModel<String> titleComboBoxModel = new DefaultComboBoxModel<>();
        titleComboBoxModel.addElement(null);
        for (String title:titoli) {
            titleComboBoxModel.addElement(title);
        }
        titleComboBox.setModel(titleComboBoxModel);


        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectTitle= (String) titleComboBox.getSelectedItem();
                if(selectTitle!=null) {
                    if (controller.addLink(titolo, position, selectTitle, usernameAutore)) {
                        JOptionPane.showMessageDialog(frame, "Collegamento aggiunto");
                        frame.setVisible(false);
                    } else {
                        JOptionPane optionPane = new JOptionPane("Errore nell'inserimento!", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                        JDialog dialog = optionPane.createDialog("Messaggio di avviso");

                        Timer timer = new Timer(1000, new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                dialog.dispose();
                            }
                        });
                        timer.setRepeats(false); // Esegui il timer solo una volta
                        timer.start();
                        dialog.setVisible(true);
                    }
                }
                else
                {
                    JOptionPane optionPane = new JOptionPane("Seleziona una frase!", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                    JDialog dialog = optionPane.createDialog("Messaggio di avviso");

                    Timer timer = new Timer(1000, new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            dialog.dispose();
                        }
                    });
                    timer.setRepeats(false); // Esegui il timer solo una volta
                    timer.start();
                    dialog.setVisible(true);
                }

            }
        });
    }
}
