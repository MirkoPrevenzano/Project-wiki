package GUI;

import controllerPackage.Controller;

import javax.swing.*;

public class Home {
    private final Controller controller;
    private static JFrame frame;
    private JButton Accesso_Autore;
    private JButton Accesso_Utente;
    private JButton Iscriviti;
    private JPanel panel1;

    public Home() {
        controller = new Controller();
        controller.leggiListinoAutore();
        controller.leggiListinoUtenti();
        controller.leggiPagineAutori();
        controller.leggiFrasiPagina();

        Accesso_Autore.addActionListener(e -> {
            AccessoAutore accessoAutore = new AccessoAutore(Home.this.controller, Home.frame);
            accessoAutore.frame.setVisible(true);
            Home.frame.setVisible(false);
        });


        Iscriviti.addActionListener(e -> {
            Iscrizione iscrizione = new Iscrizione(Home.this.controller, Home.frame);
            iscrizione.frame.setVisible(true);
            Home.frame.setVisible(false);

        });


        Accesso_Utente.addActionListener(e -> {
            AccessoUtente accessoUtente = new AccessoUtente(Home.this.controller, Home.frame);
            accessoUtente.frame.setVisible(true);
            Home.frame.setVisible(false);
        });
    }

    public static void main(String[] args) {
        frame = new JFrame("Home");
        Home home = new Home();
        frame.setContentPane(home.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(420, 80);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);


    }

}
