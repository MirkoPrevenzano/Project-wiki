package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ViewPagina {
    public JFrame frame;
    private JPanel panel1;
    private JList listFrasi;
    private JButton proponiModificaButton;
    private JButton addLinkButton;
    private JButton returnButton;
    private JButton buttonProposta;
    private JPanel panelList;
    private JButton versioniPrecedentiButton;
    private JButton rimuoviPaginaButton;
    private JToolBar toolBar;

    private List<Integer>  frasiSelezionate =new ArrayList<>();

    private List<String> modifiche = new ArrayList<>();

    public ViewPagina(final Controller controller, final JFrame frameChiamante, final String usernameAutore, List<String> frasi, String titolo) {
        this.frame = new JFrame(titolo);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(3);
        this.frame.pack();
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile
        toolBar.setFloatable(false);
        returnButton.setVisible(true);


        this.listFrasi.setModel(new DefaultListModel());
        DefaultListModel model = (DefaultListModel) this.listFrasi.getModel();
        if (frasi != null) {
            for (int i = 0; i < frasi.size(); ++i) {
                model.addElement(frasi.get(i));
            }

            buttonProposta.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Boolean ctr = controller.isProposta(usernameAutore, titolo);
                    if (ctr==true) {
                        ViewProposte viewProposte = new ViewProposte(controller, frame, usernameAutore, titolo, frasi, frameChiamante);
                        viewProposte.frame.setVisible(true);
                        ViewPagina.this.frame.setVisible(false);
                    }
                    else {
                            JOptionPane optionPane = new JOptionPane("Non ci sono proposte!", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                            JDialog dialog = optionPane.createDialog("Messaggio di avviso");

                            Timer timer = new Timer(1000, new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    dialog.dispose();
                                }
                            });
                            timer.setRepeats(false); // Esegui il timer solo una volta
                            timer.start();
                            dialog.setVisible(true);
                        }
                    }

            });

            proponiModificaButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String nomeAutore=controller.getNomeAutore(usernameAutore);
                    String cognomeAutore=controller.getCognomeAutore(usernameAutore);
                    CreazioneProposta creazioneProposta=new CreazioneProposta(controller,frame,frasi,titolo,nomeAutore,cognomeAutore);
                    creazioneProposta.frame.setVisible(true);
                    frame.setVisible(false);

                }
            });

            returnButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    frame.setVisible(false);
                    frame.dispose();
                    frameChiamante.setVisible(true);
                }
            });
        }
        versioniPrecedentiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(controller.isVersioniPrecedenti(titolo,usernameAutore)) {
                    ViewVersioniPrecedenti viewVersioniPrecedenti = new ViewVersioniPrecedenti(controller, frame, titolo, usernameAutore);
                    frame.setVisible(false);
                    viewVersioniPrecedenti.frame.setVisible(true);
                }
                else
                {
                    JOptionPane optionPane = new JOptionPane("Non ci sono versioni precedenti!", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                    JDialog dialog = optionPane.createDialog("Messaggio di avviso");

                    Timer timer = new Timer(1000, new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            dialog.dispose();
                        }
                    });
                    timer.setRepeats(false); // Esegui il timer solo una volta
                    timer.start();
                    dialog.setVisible(true);
                }
            }
        });
        addLinkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!listFrasi.isSelectionEmpty())
                {
                    int position=listFrasi.getSelectedIndex();

                    String frase= (String) listFrasi.getSelectedValue();
                    CreateLink createLink=new CreateLink(controller,frame,position,frase,titolo,usernameAutore);
                    createLink.frame.setVisible(true);
                }
                else
                {
                    JOptionPane optionPane = new JOptionPane("Selezionare una frase!", JOptionPane.WARNING_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                    JDialog dialog = optionPane.createDialog("Messaggio di avviso");

                    Timer timer = new Timer(1000, new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            dialog.dispose();
                        }
                    });
                    timer.setRepeats(false); // Esegui il timer solo una volta
                    timer.start();
                    dialog.setVisible(true);
                }
            }
        });
        rimuoviPaginaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean ctr=controller.deletePage(titolo,usernameAutore);
                if(ctr)
                {
                    JOptionPane.showMessageDialog(frame, "Pagina cancellata correttamente");
                    frame.setVisible(false);
                    frame.dispose();
                    frameChiamante.setVisible(true);

                }
                else
                {
                    JOptionPane.showMessageDialog(frame, "Errore generico, operazione non riuscita");

                }
            }
        });
    }

}
