package GUI;

import controllerPackage.Controller;
import javax.swing.*;


public class AccessoAutore {
    public JFrame frame;
    private JTextField textUsername;
    private JPasswordField textPassword;
    private JButton buttonAccess;
    private JButton buttonReturn;
    private JPanel panel1;
    private Timer messageTimer;

    public AccessoAutore(final Controller controller, final JFrame frameChiamante) {

        frame = new JFrame("Accesso autore");
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(420, 120);
        frame.setResizable(false);
        frame.setLocationRelativeTo(frameChiamante);
        frame.setVisible(true);

        buttonReturn.addActionListener(e -> {
            frame.setVisible(false);
            frameChiamante.setVisible(true);
            frame.dispose();
        });


        buttonAccess.addActionListener(e -> {
            if (AccessoAutore.this.textUsername.getText().isBlank() || AccessoAutore.this.textPassword.getPassword().length == 0) {

                showMessage("Compila tutti i campi");

            }
            else {
                char[] passwordChars = textPassword.getPassword();

                String password = new String(passwordChars);

                int ctr = controller.accessAutore(textUsername.getText(), password);

                if (ctr == 1) {

                    frame.setVisible(false);
                    SchermataAutore schermataAutore = new SchermataAutore(controller, AccessoAutore.this.frame, AccessoAutore.this.textUsername.getText());
                    schermataAutore.frame.setVisible(true);
                    AccessoAutore.this.frame.setVisible(false);
                    textPassword.setText("");
                    textUsername.setText("");

                } else if (ctr == 2) {

                    showMessage("Password errata");
                }
                else {
                    showMessage("Autore non trovato");
                }
            }

        });
    }

    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }

}