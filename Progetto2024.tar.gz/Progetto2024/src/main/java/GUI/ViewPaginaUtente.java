package GUI;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ViewPaginaUtente {
    public JFrame frame;
    private JPanel panel1;
    private JButton buttonReturn;
    private JPanel panelList;
    private JList listFrasi;
    private JScrollPane scroll;
    private JPanel panelButton;
    private JPanel panelProposta;
    private JButton buttonProposta;
    private JPanel panelSave;
    private JButton buttonSave;
    private JPanel panelReturn;
    private JPanel panelModifica;
    private JButton buttonModifica;
    private JPanel panelElimina;
    private JButton buttonElimina;

    private List<String> frasiSelezionate = new ArrayList<>();

    private List<String> modifiche = new ArrayList<>();

    public ViewPaginaUtente(final Controller controller, final JFrame frameChiamante, List<String> frasi, String titolo, final String nomeUtente, final String cognomeUtente) {

        this.frame = new JFrame(titolo);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(3);
        this.frame.pack();
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);// Imposta la posizione di default (centrato sullo schermo)
        frame.setResizable(false); // Imposta la finestra come ridimensionabile

        buttonModifica.setVisible(false);
        buttonSave.setVisible(false);
        buttonElimina.setVisible(false);

        this.listFrasi.setModel(new DefaultListModel());
        DefaultListModel model = (DefaultListModel) this.listFrasi.getModel();
        if (frasi != null) {
            for (int i = 0; i < frasi.size(); ++i) {
                model.addElement(frasi.get(i));
            }

            buttonReturn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frame.setVisible(false);
                    frame.dispose();

                    frameChiamante.setVisible(true);
                }
            });

        }

        buttonProposta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonProposta.setVisible(false);
                buttonModifica.setVisible(true);
                buttonElimina.setVisible(true);
                buttonSave.setVisible(true);
            }
        });

        buttonModifica.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (listFrasi.isSelectionEmpty()) {
                    JOptionPane.showMessageDialog(ViewPaginaUtente.this.frame, "Selezione una frase");
                } else {
                    String f = (String) listFrasi.getSelectedValue();
                    listFrasi.clearSelection();
                    String nuovaFrase = "";
                    nuovaFrase = JOptionPane.showInputDialog("Nuova frase:");
                    if (nuovaFrase != null) {
                        if (!nuovaFrase.isEmpty()) {
                            int index = frasi.indexOf(f);
                            frasi.set(index, nuovaFrase);
                            // controller.modificaTesto(frasi, titolo, usernameAutore);
                            model.clear();
                            for (int i = 0; i < frasi.size(); i++) {
                                model.addElement(frasi.get(i));
                            }
                            int ctr = 0;
                            for (String search : modifiche
                            ) {
                                if (search.equals(f))
                                    ctr = 1;
                            }
                            if (ctr == 1) {
                                int i = modifiche.indexOf(f);
                                modifiche.set(i, nuovaFrase);
                            } else {
                                frasiSelezionate.add(f);
                                modifiche.add(nuovaFrase);
                            }
                            listFrasi.revalidate();

                        }

                    }

                }
            }

        });

        buttonElimina.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (listFrasi.isSelectionEmpty()) {
                    JOptionPane.showMessageDialog(ViewPaginaUtente.this.frame, "Selezione una frase");
                } else {
                    String f = (String) listFrasi.getSelectedValue();
                    listFrasi.clearSelection();
                    frasi.remove(f);

                    model.clear();
                    for (int i = 0; i < frasi.size(); i++) {
                        model.addElement(frasi.get(i));
                    }
                    int ctr = 0;
                    for (String search : modifiche
                    ) {
                        if (search.equals(f) && f != "")
                            ctr = 1;
                    }
                    if (ctr == 1) {
                        int i = modifiche.indexOf(f);
                        modifiche.set(i, "");
                    } else {
                        frasiSelezionate.add(f);
                        modifiche.add("");
                    }
                    // controller.modificaTesto(frasi, titolo, usernameAutore);
                    listFrasi.revalidate();
                }

            }
        });

        buttonSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.saveProposta(frasiSelezionate, modifiche, titolo, nomeUtente, cognomeUtente);
            }
        });
    }

}
