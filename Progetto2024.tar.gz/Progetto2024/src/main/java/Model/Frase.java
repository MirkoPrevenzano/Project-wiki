package Model;

/**
 * The type Frase.
 */
public class Frase {
    private final String testo;
    private Testo testoVersione;
    private Collegamento collegamento;

    /**
     * Instantiates a new Frase.
     *
     * @param testo          contenuto della frase
     * @param testoVersione esto in cui si trova la frase
     */
    public Frase(String testo, Testo testoVersione)
    {
        this.testo = testo;
        this.testoVersione = testoVersione;
    }


    /**
     * Gets testo.
     *
     * @return the testo:contenuto della frase
     */
    public String getTesto() {
        return testo;
    }

    /**
     * Gets collegamento.
     *
     * @return the collegamento
     */
    public Collegamento getCollegamento() {
        return collegamento;
    }

    /**
     * Sets collegamento.
     *
     * @param collegamento the collegamento
     */
    public void setCollegamento(Collegamento collegamento) {
        this.collegamento = collegamento;
    }
}
