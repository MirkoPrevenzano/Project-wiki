package Model;

public class VersioneCorrente extends Versione{
    private Pagina pagina;
    public VersioneCorrente(Pagina p)
    {
        super();
        pagina=p;
    }

    public Pagina getPagina() {
        return pagina;
    }

    public void setPagina(Pagina pagina) {
        this.pagina = pagina;
    }
}
