package Model;

/**
 * The type Versione corrente.
 */
public class VersioneCorrente extends Versione{
    private Pagina pagina;

    /**
     * Instantiates a new Versione corrente.
     *
     * @param p the p
     */
    public VersioneCorrente(Pagina p)
    {
        super();
        pagina=p;

    }

    /**
     * Gets pagina.
     *
     * @return the pagina
     */
    public Pagina getPagina() {
        return pagina;
    }

    /**
     * Sets pagina.
     *
     * @param pagina the pagina
     */
    public void setPagina(Pagina pagina) {
        this.pagina = pagina;
    }
}
