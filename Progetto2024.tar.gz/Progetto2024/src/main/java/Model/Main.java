package Model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Main {
    public static void main(String[] args) {
        LocalDate data=LocalDate.now();
        LocalTime time=LocalTime.now();
        System.out.println(time+"     "+data);


    }
}