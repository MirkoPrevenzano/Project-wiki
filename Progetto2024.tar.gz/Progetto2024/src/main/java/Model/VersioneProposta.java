package Model;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Versione proposta.
 */
public class VersioneProposta extends Versione{

    private boolean stato;
    private boolean elaborato;
    private Pagina pagina;
    private final Utente utente;
    private final Autore autore;
    private Testo testo;
    private final List<Frase> frasiSelezionate;
    private final List<String> listProposte;

    /**
     * Instantiates a new Versione proposta.
     *
     * @param utente           the utente
     * @param autore           the autore
     * @param pagina           the pagina
     * @param fraseSelezionata the frase selezionata
     * @param modifica         the modifica
     */
    public VersioneProposta( Utente utente, Autore autore, Pagina pagina, Frase fraseSelezionata, String modifica)
    {
        //data, ora e stato da inserire in automatico

        this.autore = autore;
        this.utente = utente;
        this.pagina=pagina;
        frasiSelezionate = new ArrayList<>();
        frasiSelezionate.add(fraseSelezionata);
        this.listProposte = new ArrayList<>();
        this.listProposte.add(modifica);
        if(utente==autore)
        {
            stato=true;
            elaborato=true;

        }
        else
            elaborato=false;
        autore.addListProposta(this);
        utente.addProposta(this);
    }

    /**
     * Instantiates a new Versione proposta.
     *
     * @param utente               the utente
     * @param autore               the autore
     * @param pagina               the pagina
     * @param listFrasiSelezionate the list frasi selezionate
     * @param listModificaProposte the list modifica proposte
     */
    public VersioneProposta( Utente utente, Autore autore, Pagina pagina, List<Frase> listFrasiSelezionate, List<String> listModificaProposte)
    {
        super();
        //data, ora e stato da inserire in automatico
        this.autore = autore;
        this.utente = utente;
        this.pagina=pagina;
        if(listFrasiSelezionate.size()!= listModificaProposte.size())
        {
            throw new IllegalArgumentException("Numero frasi selezionate diverso dalle modifiche proposte");
        }
        frasiSelezionate= listFrasiSelezionate;
        this.listProposte = listModificaProposte;

        if(utente==autore)
        {
            stato=true;
            elaborato=true;

        }
        else
            elaborato=false;
        autore.addListProposta(this);
        utente.addProposta(this);
    }

    /**
     * Sets pagina.
     *
     * @param pagina the pagina
     */
    public void setPagina(Pagina pagina) {
        this.pagina = pagina;
    }

    /**
     * Gets pagina.
     *
     * @return the pagina
     */
    public Pagina getPagina() {
        return pagina;
    }

    /**
     * Sets stato.
     *
     * @param stato the stato
     */
    public void setStato(boolean stato) {
        this.stato = stato;
    }

    /**
     * Is elaborato boolean.
     *
     * @return the boolean
     */
    public boolean isElaborato() {
        return elaborato;
    }

    /**
     * Sets elaborato.
     *
     * @param elaborato the elaborato
     */
    public void setElaborato(boolean elaborato) {
        this.elaborato = elaborato;
    }
    @Override
    public Testo getTesto() {
        return testo;
    }
    @Override
    public void setTesto(Testo testo) {
        this.testo = testo;
    }

}
