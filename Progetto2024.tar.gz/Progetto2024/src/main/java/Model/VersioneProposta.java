package Model;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class VersioneProposta extends Versione{

    private boolean stato;
    private boolean elaborato;
    private Pagina pagina;

    private Utente utente;
    private Autore autore;
    private Testo testo;
    private List<Frase> frasiSelezionate;
    private List<String> listProposte;

    public VersioneProposta( Utente utente, Autore autore, Pagina pagina, Frase fraseSelezionata, String modifica)
    {
        //data, ora e stato da inserire in automatico

        this.autore = autore;
        this.utente = utente;
        this.pagina=pagina;
        frasiSelezionate = new ArrayList<>();
        frasiSelezionate.add(fraseSelezionata);
        this.listProposte = new ArrayList<>();
        this.listProposte.add(modifica);
        if(utente==autore)
        {
            stato=true;
            elaborato=true;

        }
        else
            elaborato=false;
        autore.addListProposta(this);
        utente.addProposta(this);
    }
    public VersioneProposta( Utente utente, Autore autore, Pagina pagina, List<Frase> listFrasiSelezionate, List<String> listModificaProposte)
    {
        //data, ora e stato da inserire in automatico
        this.autore = autore;
        this.utente = utente;
        this.pagina=pagina;
        if(listFrasiSelezionate.size()!= listModificaProposte.size())
        {
            throw new IllegalArgumentException("Numero frasi selezionate diverso dalle modifiche proposte");
        }
        frasiSelezionate= listFrasiSelezionate;
        this.listProposte = listModificaProposte;

        if(utente==autore)
        {
            stato=true;
            elaborato=true;

        }
        else
            elaborato=false;
        autore.addListProposta(this);
        utente.addProposta(this);
    }

    public void setPagina(Pagina pagina) {
        this.pagina = pagina;
    }

    public Pagina getPagina() {
        return pagina;
    }

    public boolean isStato() {
        return stato;
    }

    public void setStato(boolean stato) {
        this.stato = stato;
    }

    public void addListString(String propModify)
    {
        listProposte.add(propModify);
    }

    public void removeListString(String propModify)
    {
        listProposte.remove(propModify);
    }

    public void addListFrase(Frase f)
    {
        frasiSelezionate.add(f);
    }

    public void removeListString(Frase f)
    {
        frasiSelezionate.remove(f);
    }

    public boolean isElaborato() {
        return elaborato;
    }

    public void setElaborato(boolean elaborato) {
        this.elaborato = elaborato;
    }

    public List<Frase> getListFrase()
    {
        return frasiSelezionate;
    }

    public Autore getAutore() {
        return autore;
    }

    public Testo getTesto() {
        return testo;
    }

    public Utente getUtente() {
        return utente;
    }
    public void setTesto(Testo testo) {
        this.testo = testo;
    }

    public void setAutore(Autore autore) {
        this.autore = autore;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }
    public List<String> getListProposte() {
        return listProposte;
    }


}
