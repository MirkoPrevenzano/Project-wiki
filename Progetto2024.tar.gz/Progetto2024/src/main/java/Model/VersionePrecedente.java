package Model;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * The type Versione precedente: oggetto che indentifica versione precedente di una pagina
 */
public class VersionePrecedente extends Versione{
    public VersionePrecedente(){super();}
    public VersionePrecedente(LocalDate date, LocalTime time){super(date,time);}

}
