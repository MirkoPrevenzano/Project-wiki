package Model;

public class VersionePrecedente extends Versione{

}
