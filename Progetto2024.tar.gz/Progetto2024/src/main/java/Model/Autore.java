package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Autore.
 */
public class Autore extends Utente
{
    private final String login;
    private final String password;
    private final List<Pagina> listPagine;
    private final List<VersioneProposta> listProposte;

    /**
     * Instantiates a new Autore.
     *
     * @param nome     the nome
     * @param cognome  the cognome
     * @param login    the login: per accesso di un autore (username)
     * @param password the password: chiave segreta per l'accesso
     */
    public Autore(String nome, String cognome, String login, String password)
    {
        super(nome,cognome);
        this.login = login;
        this.password = password;
        listPagine = new ArrayList<>();
        listProposte = new ArrayList<>();
    }

    /**
     * Add list proposta: aggiunge proposta da gestire, da parte dell'autore
     *
     * @param p the p: proposta
     */
    public void addListProposta(VersioneProposta p)
    {
        listProposte.add(p);
    }

    /**
     * Gets list proposta gestite.
     *
     * @return the list proposta gestite
     */
    public List<VersioneProposta> getListPropostaGestite()
    {
        return listProposte;
    }

    /**
     * Add list pagine: lista di pagine dell'autore
     *
     * @param p the p: oggetto pagina
     */
    public void addListPagine(Pagina p)
    {
        listPagine.add(p);
    }

    /**
     * Gets login.
     *
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * Gets list pagine.
     *
     * @return the list pagine
     */
    public List<Pagina> getListPagine() {return listPagine;}

    /**
     * Sign in boolean.
     *
     * @param username the username
     * @param password the password
     * @return the boolean: true se le credenziali sono corrette
     */
    public Boolean signIn(String username, String password){
        return this.login.equals(username) && this.password.equals(password);
    }
}
