package Model;

/**
 * The type Collegamento.
 */
public class Collegamento {
    private Pagina pagina;
    private Frase frase;

    /**
     * Instantiates a new Collegamento.
     *
     * @param pagina the pagina: pagina associata
     * @param frase  the frase:  frase proprietaria del collegamento
     */
    public Collegamento(Pagina pagina, Frase frase)
    {
        this.pagina = pagina;
        this.frase = frase;
        frase.setCollegamento(this);
    }

    /**
     * Gets frase.
     *
     * @return the frase
     */
    public Frase getFrase() {
        return frase;
    }

    /**
     * Sets frase.
     *
     * @param frase the frase
     */
    public void setFrase(Frase frase) {
        this.frase = frase;
    }

    /**
     * Gets pagina.
     *
     * @return the pagina
     */
    public Pagina getPagina() {
        return pagina;
    }

    /**
     * Sets pagina.
     *
     * @param pagina the pagina
     */
    public void setPagina(Pagina pagina) {
        this.pagina = pagina;
    }
}
