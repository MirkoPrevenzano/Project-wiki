package Model;


import java.util.ArrayList;
import java.util.List;

public class Utente {
    protected String nome;
    protected String cognome;

    protected List<VersioneProposta> listProposteRichieste;


    public Utente(String nome, String cognome) {
        this.nome = nome;
        this.cognome = cognome;
        listProposteRichieste = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }
    public void addProposta(VersioneProposta p)
    {
        listProposteRichieste.add(p);
    }
    public void removeProposta(VersioneProposta p)
    {
        listProposteRichieste.remove(p);
    }

    public List<VersioneProposta> getListProposte() {
        return listProposteRichieste;
    }
}
