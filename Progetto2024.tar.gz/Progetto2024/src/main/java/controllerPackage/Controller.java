package controllerPackage;


import DAO.AutoreDAO;
import DAO.FraseDAO;
import DAO.PaginaDAO;
import DAO.UtenteDAO;
import ImplementazionePostgresDao.ImplementazionePostgresAutoreDao;
import ImplementazionePostgresDao.ImplementazionePostgresFrasiDao;
import ImplementazionePostgresDao.ImplementazionePostgresPaginaDao;
import ImplementazionePostgresDao.ImplementazionePostgresUtenteDao;
import Model.*;

import Model.Pagina;

import java.sql.*;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Iterator;
import java.util.List;

public class Controller {
    private Autore autore;
    private Utente utente;
    private final ListinoIscritti listinoIscritti = new ListinoIscritti();

    public Controller() {


    }
    /*public void prova()
    {
        Autore a=listinoIscritti.searchAutore("mario.rossi");
        if(a==null)
            System.out.println("autore null");
        Utente u=listinoIscritti.searchUtente("Mirko","Prevenzano");
        if(u==null)
            System.out.println("utente null");
        Pagina p=getPage("Carcere", "mario.rossi");
        if(p==null)
            System.out.println("pagina null");
        VersioneProposta proposta=new VersioneProposta()(u,a,,p.getTesto().getFrasi().get(0),"ciao");
        if(proposta==null)
            System.out.println("proposta null");


    }*/

    //iscrizione, ritora true se l'iscrizione è andata a buon fine (voglio vedere come si può verificare se un utente è iscritto o no
    public int addNewAuthor(String nome, String cognome, String username, String password) {
        for (Autore a : listinoIscritti.getListAutore()
        ) {
            if (a.getLogin().equals(username))
                return 2;//autore già esistente

        }
        this.autore = new Autore(nome, cognome, username, password);

        listinoIscritti.addListAutore(this.autore);
        if (autore != null)
            return 1;
        return 0;
    }

    public int addNewUtente(String nome, String cognome) {
        for (Utente u : listinoIscritti.getListUtente()
        ) {
            if (u.getNome().equals(nome) && u.getCognome().equals(cognome))
                return 2;//utente già esistente

        }
        this.utente = new Utente(nome, cognome);
        listinoIscritti.addListUtente(this.utente);

        if (utente != null)
            return 1;
        return 0;
    }

    public int accessAutore(String username, String password) {
        for (Autore a : listinoIscritti.getListAutore()) {
            if (a.getLogin().equals(username)) {
                if (a.signIn(username, password)) {
                    return 1; //passwordCorretta
                } else {
                    return 2; //passwordErrata
                }
            }
        }
        return 0;//Autore non esistente
    }


    public Boolean accessUtente(String nome, String cognome) {

        for (Utente utente : listinoIscritti.getListUtente()) {
            if (utente.getNome().equals(nome) && utente.getCognome().equals(cognome)) {
                return true;
            }

        }
        return false;

    }

    public Boolean addPage(String titolo, String usernameAutore) {//creo nuova pagina
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> page = a.getListPagine();
        for (Pagina p : page
        ) {
            if (p.getTitolo().equals(titolo)) {
                return false;
            }

        }

        Pagina p = new Pagina(titolo, a);
        a.addListPagine(p);
        return true;
    }

    public Pagina getPage(String titolo, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> page = a.getListPagine();
        //uso di stream e filter
        return page.stream().filter(paginaT -> paginaT.getTitolo().equals(titolo)).findFirst().orElse(null);
    }
    public VersioneCorrente getVersioneCorrente(String titolo, String usernameAutore)
    {
       Pagina p=getPage(titolo,usernameAutore);
       return p.getVersioneCorrente();
    }

    public void gestioneTestoPage(String nuovaFrase, String usernameAutore, String titolo) {
       // Pagina pagina = getPage(titolo, usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,usernameAutore);
        Frase f = new Frase(nuovaFrase, versioneCorrente.getTesto());
        versioneCorrente.getTesto().addFrase(f);
    }

    public List<String> caricaTitoli(String usernameAutore) {
        autore = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> p = autore.getListPagine();
        List<String> tit = new ArrayList<>();
        for (Pagina pp : p
        ) {
            tit.add(pp.getTitolo());
        }
        return tit;
    }

    public List<String> caricaTitoli() {
        List<String> tit = new ArrayList<>();
        for (Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                tit.add((p.getTitolo()));
            }
        }

        return tit;
    }

    public List<String> getTestoPage(String titoloPagina, String usernameAutore) {
        /*autore = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> page = autore.getListPagine();
        Pagina pagina = page.stream().filter(paginaT -> paginaT.getTitolo().equals(titoloPagina)).findFirst().orElse(null);
        List<Frase> listFrasTesto = pagina.getTesto().getFrasi();*/
        VersioneCorrente versioneCorrente=getVersioneCorrente(titoloPagina,usernameAutore);
        List<Frase> listFrasTesto = versioneCorrente.getTesto().getFrasi();
        //controllare meglio
        List<String> testoPage = new ArrayList<>();
        for (Frase f : listFrasTesto) {
            testoPage.add(f.getTesto());
        }
        return testoPage;
    }




    public void modificaTesto(List<String> frasi, String titolo, String usernameAutore) {

        Pagina pagina = getPage(titolo, usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,usernameAutore);
        VersionePrecedente versionePrecedente=new VersionePrecedente();
        versionePrecedente.setTesto(versioneCorrente.getTesto());
        pagina.addListVersione(versionePrecedente);
        Testo t = new Testo();
        versioneCorrente.setTesto(t);
        for (int i = 0; i < frasi.size(); i++) {
            Frase f = new Frase(frasi.get(i), t);
            t.addFrase(f);
        }

        // List<Frase> listFrasi= pagina.getTesto().getFrasi();
    }

    public void saveProposta(List<String> listFrasi, List<String> modifiche, String usernameAutore, String titolo) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        Pagina p=getPage(titolo, usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,usernameAutore);
        Testo t = versioneCorrente.getTesto();
        List<Frase> list = t.getFrasi();
        List<Frase> frasiSelezionate = new ArrayList<>();
        for (int i = 0; i < listFrasi.size(); i++) {
            //
            // String tff = listItem.replaceAll("\\n$", "");

            for (Frase f : list) {
                if (listFrasi.get(i).equals(f.getTesto())) {
                    frasiSelezionate.add(f);
                }
            }
        }
        VersioneProposta proposta = new VersioneProposta(a, a, p, frasiSelezionate, modifiche);
        a.addProposta(proposta);
    }

    public void saveProposta(List<String> listFrasi, List<String> modifiche, String titolo, String nomeUtente, String cognomeUtente)
    {
        Utente u = listinoIscritti.searchUtente(nomeUtente, cognomeUtente);
        for(Autore a : listinoIscritti.getListAutore())
        {
            for(Pagina p : a.getListPagine())
            {
                if(p.getTitolo().equals(titolo))
                {
                    VersioneCorrente versioneCorrente=getVersioneCorrente(titolo, a.getLogin());
                    Testo t = versioneCorrente.getTesto();
                    List<Frase> list = t.getFrasi();
                    List<Frase> frasiSelezionte = new ArrayList<>();
                    for(int i=0; i<listFrasi.size(); i++)
                    {
                        for(Frase f: list)
                        {
                            if (listFrasi.get(i).equals(f.getTesto())) {
                                frasiSelezionte.add(f);
                            }
                        }
                    }

                    VersioneProposta proposta = new VersioneProposta(u, a, p, frasiSelezionte,modifiche);
                    a.addProposta(proposta);
                    u.addProposta(proposta);
                }
            }
        }

    }

    /*public void modificaTesto(List<String> frasiSelezionate, List<String> modifiche, String usernameAutore, String titolo, String usernameUtente) {
        if(usernameUtente.equals(usernameUtente))
        {
            Pagina p= getPage(titolo, usernameAutore);
            List<Frase> listaFrasPagina=p.getTesto().getFrasi();
            for(int i=0;i<frasiSelezionate.size();i++)
            {
                for (Frase f:listaFrasPagina) {
                    if(f.getTesto().equals(frasiSelezionate.get(i)))
                    {
                        if(modifiche.get(i).equals(""))
                        {
                           p.getTesto().getFrasi().remove(f);
                        }
                        else
                        {
                            f.setTesto(modifiche.get(i));
                        }
                    }


                }
            }

        }

    }*/
    public void modificaTesto(List<String> frasiSelezionate, List<String> modifiche, String usernameAutore, String titolo, String usernameUtente) {
        if (usernameUtente.equals(usernameUtente)) {
            Pagina p = getPage(titolo, usernameAutore);
            VersioneCorrente versioneCorrente=getVersioneCorrente(titolo, usernameAutore);
            List<Frase> listaFrasPagina = versioneCorrente.getTesto().getFrasi();

            Iterator<Frase> iterator = listaFrasPagina.iterator();
            while (iterator.hasNext()) {
                Frase f = iterator.next();
                if (frasiSelezionate.contains(f.getTesto())) {
                    int index = frasiSelezionate.indexOf(f.getTesto());

                    if (modifiche.get(index).equals("")) {
                        iterator.remove(); // Rimuovi usando l'iteratore
                    } else {
                        f.setTesto(modifiche.get(index));
                    }
                }
            }
        }
    }

    public List<String> getTestoPage(String titoloPagina) {
        List<String> testoPage = new ArrayList<>();
        for (Autore a : listinoIscritti.getListAutore()) {
            /*List<Pagina> page = a.getListPagine();
            Pagina pagina = page.stream().filter(paginaT -> paginaT.getTitolo().equals(titoloPagina)).findFirst().orElse(null);*/
            VersioneCorrente versioneCorrente=getVersioneCorrente(titoloPagina, a.getLogin());
            if (versioneCorrente != null) {
                List<Frase> listFraseTesto = versioneCorrente.getTesto().getFrasi();
                for (Frase f : listFraseTesto) {
                    testoPage.add(f.getTesto());
                }
            }
        }
        return testoPage;
    }

    public Boolean isProposta(String usernameAutore, String titolo) {
        Pagina p = getPage(titolo, usernameAutore);
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        //System.out.println(a.getListPropostaGestite().size());
        for (VersioneProposta pr : a.getListPropostaGestite()
        ) {
            if (pr.getPagina()==p)
                return true;

        }
        return false;
    }

    public List<String> getTextProposta(String titolo, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        Pagina p = getPage(titolo, usernameAutore);
        VersioneProposta proposta = null;
        for (VersioneProposta prop : a.getListPropostaGestite()
        ) {
            if (prop.getPagina() == p && !prop.isStato()) {
                if (proposta == null)
                    proposta = prop;
                else if (proposta.getData().isAfter(prop.getData())) {
                    proposta = prop;

                } else if (proposta.getData().equals(prop.getData())) {
                    if (proposta.getOra().isAfter(prop.getOra()))
                        proposta = prop;

                }
            }

        }
        if(proposta!=null) {
            List<String> textProposto = new ArrayList<>();
            for (int i = 0; i < p.getVersioneCorrente().getTesto().getFrasi().size(); i++) {
                int dim = textProposto.size();

                for (int j = 0; j < proposta.getListFrase().size(); j++) {
                    if (proposta.getListFrase().get(j).getTesto().equals(p.getVersioneCorrente().getTesto().getFrasi().get(i).getTesto())) {
                        textProposto.add(proposta.getListProposte().get(j));
                    }
                }

                if (dim == textProposto.size())
                    textProposto.add(p.getVersioneCorrente().getTesto().getFrasi().get(i).getTesto());

            }
            return textProposto;
        }
        return null;



    }
    public void leggiListinoAutore()
    {
        AutoreDAO ad =  new ImplementazionePostgresAutoreDao();
        List<String> nomeAutore = new ArrayList<String>();
        List<String> CognomeAutore = new ArrayList<>();
        List<String> login = new ArrayList<>();
        List<String> Password = new ArrayList<>();
        ad.leggiListinoAutore(nomeAutore, CognomeAutore, login, Password);
        for (int i = 0; i < nomeAutore.size(); i++) {
            Autore a = new Autore(nomeAutore.get(i), CognomeAutore.get(i), login.get(i), Password.get(i));
            listinoIscritti.addListAutore(a);
        } // costruisce gli oggetti Model a partire dai risultati del db

    }
    public void leggiListinoUtenti()
    {
        UtenteDAO ud = new ImplementazionePostgresUtenteDao();
        List<String> nomeUtente = new ArrayList<>();
        List<String> cognomeUtente = new ArrayList<>();
        ud.leggiListinoUtenti(nomeUtente, cognomeUtente);
        for (int i = 0; i < nomeUtente.size(); i++) {
            Utente u = new Utente(nomeUtente.get(i), cognomeUtente.get(i));
            listinoIscritti.addListUtente(u);
        }

    }
    public void leggiPagineAutori()
    {
        PaginaDAO pd = new ImplementazionePostgresPaginaDao();
        List<String> TitoloPagina = new ArrayList<>();
        List<String> loginAutorePagina = new ArrayList<>();
        List<Date> dataPagina = new ArrayList<>();
        List<Time> oraPagina = new ArrayList<>();

        pd.leggiPagineAutori(TitoloPagina,dataPagina ,oraPagina, loginAutorePagina);
        for(Autore a : listinoIscritti.getListAutore())
        {
            for(int i = 0; i<TitoloPagina.size(); i++) {
                if (a.getLogin().equals(loginAutorePagina.get(i))) {
                    Pagina p = new Pagina(TitoloPagina.get(i), dataPagina.get(i).toLocalDate(),oraPagina.get(i).toLocalTime(),a);
                    a.addListPagine(p);
                }
            }
        }

    }
    public void leggiFrasiPagina()
    {
        FraseDAO fd = new ImplementazionePostgresFrasiDao();
        List<String> TitoloPaginaFrase = new ArrayList<>();
        List<String> TestoFrase = new ArrayList<>();
        List<Integer> ordineFrase = new ArrayList<>();
        fd.leggiFrasiPagina(TestoFrase,TitoloPaginaFrase,ordineFrase);
        for(Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                for (int i = 0; i < TitoloPaginaFrase.size(); i++) {
                    if (p.getTitolo().equals(TitoloPaginaFrase.get(i)))
                    {
                        Frase frase = new Frase(TestoFrase.get(i),p.getVersioneCorrente().getTesto());
                        p.getVersioneCorrente().getTesto().addFrase(frase);
                    }
                }
            }
        }

    }

}

