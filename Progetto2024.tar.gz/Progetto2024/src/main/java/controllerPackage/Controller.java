package controllerPackage;


import DAO.*;
import ImplementazionePostgresDao.*;
import Model.*;
import Model.Pagina;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

/**
 * The type Controller.
 */
public class Controller {
    private final ListinoIscritti listinoIscritti = new ListinoIscritti();


    /**
     * Add new autore : metodo che aggiunge un nuovo autore.
     *
     * @param name     the name: nome autore
     * @param surname  the surname: cognome autore
     * @param username the username
     * @param password the password
     * @return the boolean: false se l'username dell'autore è già esistente, true se l'iscrizione è andata a buon fine
     */
    public boolean addNewAutore(String name, String surname, String username, String password) {
        for (Autore a : listinoIscritti.getListAutore()
        ) {
            if (a.getLogin().equals(username))
                return false;

        }
        Autore autore = new Autore(name, surname, username, password);
        addAutoreDB(name,surname,username,password);

        listinoIscritti.addListAutore(autore);
        listinoIscritti.addListUtente(autore);
        return true;
    }

    /**
     * Inserisce autore nel database
     *
     * @param name   the name autore: nome autore
     * @param surname the surname autore: cognome autore
     * @param username      the username
     * @param password      the password
     */
    public void addAutoreDB(String name, String surname, String username, String password)
    {
        AutoreDAO ad = new ImplementazionePostgresAutoreDao();
        ad.inserisciAutore(name,surname, username, password);

    }

    /**
     * Add new utente :metodo che aggiunge un nuovo utente.
     *
     * @param name    the name: nome utente
     * @param surname the surname: cognome utente
     * @return the boolean: false se l'username dell'utente è già esistente, true se l'iscrizione è andata a buon fine
     */
    public boolean addNewUtente(String name, String surname) {
        for (Utente u : listinoIscritti.getListUtente()
        ) {
            if (u.getNome().equals(name) && u.getCognome().equals(surname))
                return false;

        }
        Utente utente = new Utente(name, surname);
        addUtente(name,surname);
        listinoIscritti.addListUtente(utente);

        return true;
    }

    /**
     * Inserisce utente nel database
     *
     * @param name    the name: nome utente
     * @param surname the surname: cognome utente
     */
    public void addUtente(String name, String surname)
    {
        UtenteDAO ud = new ImplementazionePostgresUtenteDao();
        ud.inserisciUtente(name,surname);
    }

    /**
     * Access autore int
     *
     * @param username the username.
     * @param password the password.
     * @return the int:1 se l'accesso è andato a buon fine, 2 se la password è sbagliata, 0 se non esiste autore con quall'username
     */
    public int accessAutore(String username, String password) {
        for (Autore a : listinoIscritti.getListAutore()) {
            if (a.getLogin().equals(username)) {
                if (Boolean.TRUE.equals(a.signIn(username, password))) {
                    return 1;
                } else {
                    return 2;
                }
            }
        }
        return 0;
    }


    /**
     * Access utente boolean.
     *
     * @param name    the name: nome utente
     * @param surname the surname: cognome utente
     * @return the boolean: true se esiste l'utente
     */
    public Boolean accessUtente(String name, String surname) {

        for (Utente utente : listinoIscritti.getListUtente()) {
            if (utente.getNome().equals(name) && utente.getCognome().equals(surname)) {
                return true;
            }

        }
        return false;

    }

    /**
     * Add page boolean.
     *
     * @param title          the title
     * @param usernameAutore the username autore
     * @return the boolean: false se già esiste una pagina con quel titolo
     */
    public Boolean addPage(String title, String usernameAutore) {
        Autore author = listinoIscritti.searchAutore(usernameAutore);
        for(Autore a:listinoIscritti.getListAutore() )
        {
            for (Pagina p : a.getListPagine()) {
                if (p.getTitolo().equals(title)) {
                    return false;
                }

            }

        }

        Pagina p = new Pagina(title, author);
        Date data = Date.valueOf(p.getData());
        Time ora = Time.valueOf(p.getOra());
        addPagina(title,data,ora,author.getLogin());
        author.addListPagine(p);
        return true;
    }

    /**
     * Add pagina: inserimento pagina nel database
     *
     * @param titlePagina    the title pagina
     * @param datePagina     the date pagina
     * @param timePagina     the time pagina
     * @param usernameAutore the username autore
     */
    public void addPagina(String titlePagina, Date datePagina, Time timePagina, String usernameAutore)
    {
        PaginaDAO pd = new ImplementazionePostgresPaginaDao();
        pd.inserisciPagine(titlePagina,datePagina,timePagina,usernameAutore);
    }

    /**
     * Gets page: prendo pagina con un determinato titolo (uso l'username per diminuire range di ricerca)
     *
     * @param title          the title
     * @param usernameAutore the username autore
     * @return the page
     */
    public Pagina getPage(String title, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> page = a.getListPagine();
        return page.stream().filter(paginaT -> paginaT.getTitolo().equals(title)).findFirst().orElse(null);
    }

    /**
     * Gets versione corrente: se la pagina esiste, ritorna la sua versione corrente
     *
     * @param title          the title
     * @param usernameAutore the username autore
     * @return the versione corrente
     */
    public VersioneCorrente getVersioneCorrente(String title, String usernameAutore)
    {
       Pagina p=getPage(title,usernameAutore);
       if(p!=null)
       {
           return p.getVersioneCorrente();
       }
       return null;
    }

    /**
     * Gestione testo page: inserisce frase nella versione corrente di una pagina appena creata( chiamata del metodo da CrazionePagina
     * dalla gui, una frase per volta). Questa frase la inserisco poi nel database
     *
     * @param newFrase       the new frase
     * @param usernameAutore the username autore
     * @param title          the title
     */
    public void gestioneTestoPage(String newFrase, String usernameAutore, String title) {
        VersioneCorrente versioneCorrente=getVersioneCorrente(title,usernameAutore);
        Frase f = new Frase(newFrase, versioneCorrente.getTesto());
        addFraseDB(newFrase,versioneCorrente.getTesto().getFrasi().size(),title);
        versioneCorrente.getTesto().addFrase(f);
    }

    /**
     * Add frase db.
     *
     * @param textFrase the text frase
     * @param order     the order
     * @param title     the title
     */
    public void addFraseDB(String textFrase, int order, String title)
    {
        FraseDAO fd = new ImplementazionePostgresFrasiDao();
        fd.inserisciFrase_DB(textFrase,order, title);

    }


    /**
     * Upload titles list.
     *
     * @param usernameAutore the username autore
     * @return the list
     */
    public List<String> uploadTitles(String usernameAutore) {

        Autore author = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> p = author.getListPagine();
        List<String> title = new ArrayList<>();
        for (Pagina pp : p
        ) {
            title.add(pp.getTitolo());
        }
        return title;
    }

    /**
     * Upload titles list.
     *
     * @return the list
     */
    public List<String> uploadTitles() {
        List<String> title = new ArrayList<>();
        for (Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                title.add((p.getTitolo()));
            }
        }

        return title;
    }

    /**
     * Gets testo page.
     *
     * @param titlePagina    the title pagina
     * @param usernameAutore the username autore
     * @return the testo page
     */
    public List<String> getTestoPage(String titlePagina, String usernameAutore) {

        VersioneCorrente versioneCorrente=getVersioneCorrente(titlePagina,usernameAutore);
        List<Frase> listFraseTesto;
        if(versioneCorrente!=null)
        {
            listFraseTesto = versioneCorrente.getTesto().getFrasi();
            if(listFraseTesto!=null) {
                List<String> testoPage = new ArrayList<>();
                for (Frase f : listFraseTesto) {
                    testoPage.add(f.getTesto());
                }

                return testoPage;
            }
        }

        return null;
    }


    /**
     * Modify testo.
     *
     * @param selectedPhrases the selected phrases
     * @param modifies        the modifies
     * @param title           the title
     * @param usernameAutore  the username autore
     */
    public void modifyTesto(List<Integer> selectedPhrases, List<String> modifies, String title, String usernameAutore) {

        Pagina pagina = getPage(title, usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(title,usernameAutore);
        VersionePrecedente versionePrecedente=new VersionePrecedente();

        versionePrecedente.setTesto(versioneCorrente.getTesto());
        pagina.addListVersione(versionePrecedente);
        Testo testoNew=new Testo(versioneCorrente);
        versioneCorrente.setTesto(testoNew);

        int ctr;
        for(int i=0;i<versionePrecedente.getTesto().getFrasi().size();i++)
        {
            ctr=-1;
            for (int index:selectedPhrases) {
                if(i==index)
                {
                    if(!(modifies.get(selectedPhrases.indexOf(index)).equals(" "))) {
                        Frase frase = new Frase(modifies.get(selectedPhrases.indexOf(index)), versioneCorrente.getTesto());
                        versioneCorrente.getTesto().addFrase(frase);
                    }
                    ctr=1;
                }
            }
            if(ctr==-1)
            {
                Frase frase=new Frase(versionePrecedente.getTesto().getFrasi().get(i).getTesto(),versioneCorrente.getTesto());
                versioneCorrente.getTesto().addFrase(frase);
            }
        }

    }

    /**
     * Save proposta utente.
     *
     * @param listPhrases   the list phrases
     * @param modifies      the modifies
     * @param title         the title
     * @param nameUtente    the name utente
     * @param surnameUtente the surname utente
     */
    public void savePropostaUtente(List<Integer> listPhrases, List<String> modifies, String title, String nameUtente, String surnameUtente)
    {
        List<Frase> selectedPhrases = new ArrayList<>();
        if(!listPhrases.isEmpty()) {
            Utente u = listinoIscritti.searchUtente(nameUtente, surnameUtente);
            for (Autore a : listinoIscritti.getListAutore()) {
                for (Pagina p : a.getListPagine()) {
                    if (p.getTitolo().equals(title)) {
                        createPropostaUtente(p,title, listPhrases,selectedPhrases,modifies,u,a);
                        return;

                    }
                }
            }
        }

    }

    /**
     * Create proposta utente.
     *
     * @param p               the p
     * @param title           the title
     * @param listFrasi       the list frasi
     * @param selectedPhrases the selected phrases
     * @param modifies        the modifies
     * @param u               the u
     * @param a               the a
     */
    public void createPropostaUtente(Pagina p, String title, List<Integer> listFrasi, List<Frase> selectedPhrases, List<String> modifies, Utente u, Autore a) {

             VersioneCorrente versioneCorrente = getVersioneCorrente(title, a.getLogin());

             for (Integer integer : listFrasi) {

                 selectedPhrases.add(versioneCorrente.getTesto().getFrasi().get(integer));
             }
             VersioneProposta proposta = new VersioneProposta(u, a, p, selectedPhrases, modifies);
             createTesto(modifies, p, listFrasi, proposta);

             if (proposta.isElaborato()) {
                 modifyTesto(listFrasi, modifies, title, a.getLogin());

             }

     }

    /**
     * Create testo testo.
     *
     * @param modifies       the modifies
     * @param p              the p
     * @param listFrasiIndex the list frasi index
     * @param proposta       proposta
     *
     */
    public void createTesto(List<String> modifies, Pagina p, List<Integer> listFrasiIndex, VersioneProposta proposta)
    {
        VersioneCorrente versioneCorrente=getVersioneCorrente(p.getTitolo(), p.getAutore().getLogin());
        proposta.setTesto(new Testo(proposta));

        for(int i=0;i<versioneCorrente.getTesto().getFrasi().size();i++)
        {
            int ctr=-1;
            int sent=-1;
            for(int j=0;j<listFrasiIndex.size();j++)
            {
                if(listFrasiIndex.get(j)==i)
                {
                    ctr=listFrasiIndex.get(j);
                    sent=j;
                }
            }
            if(ctr!=-1&&!modifies.get(sent).equals(" "))
            {
                Frase frase=new Frase(modifies.get(sent), proposta.getTesto());
                proposta.getTesto().addFrase(frase);
            }
            else if(ctr==-1)
            {
                Frase frase=new Frase(versioneCorrente.getTesto().getFrasi().get(i).getTesto(), proposta.getTesto());
                proposta.getTesto().addFrase(frase);
            }

        }
    }


    /**
     * Gets testo page.
     *
     * @param titlePagina the title pagina
     * @return the testo page
     */
    public List<String> getTestoPage(String titlePagina) {
        List<String> testoPage = new ArrayList<>();
        Autore a = null;
        for(int i=0;i<listinoIscritti.getListAutore().size();i++)
        {
            if(getPage(titlePagina,listinoIscritti.getListAutore().get(i).getLogin())!=null)
            {
                a=listinoIscritti.getListAutore().get(i);
            }
        }

       if(a!=null) {
           VersioneCorrente versioneCorrente = getVersioneCorrente(titlePagina, a.getLogin());
           if (versioneCorrente != null) {
               List<Frase> listFraseTesto = versioneCorrente.getTesto().getFrasi();
               for (Frase f : listFraseTesto) {
                   testoPage.add(f.getTesto());
               }
           }
       }
        
        return testoPage;
    }

    /**
     * Is proposta boolean.
     *
     * @param usernameAutore the username autore
     * @param title          the title
     * @return the boolean
     */
    public Boolean isProposta(String usernameAutore, String title) {
        Pagina p = getPage(title, usernameAutore);
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        for (VersioneProposta pr : a.getListPropostaGestite()
        ) {
            if (pr.getPagina()==p&&!pr.isElaborato())
                return true;

        }
        return false;
    }


    /**
     * Gets versione proposta first.
     *
     * @param pagina the pagina
     * @param autore the autore
     * @return the versione proposta first
     */
    public VersioneProposta getVersionePropostaFirst(Pagina pagina, Autore autore) {
        VersioneProposta proposta=null;
        for (VersioneProposta prop : autore.getListPropostaGestite()
        ) {
            if (prop.getPagina() == pagina && !prop.isElaborato()) {
                if (proposta == null)
                    proposta = prop;
                else if (proposta.getData().isAfter(prop.getData())) {
                    proposta = prop;

                } else if (proposta.getData().equals(prop.getData()) && (proposta.getOra().isAfter(prop.getOra())))
                        {proposta = prop;

                }
            }

        }
        return proposta;
    }

    /**
     * Gets text proposta.
     *
     * @param title          the title
     * @param usernameAutore the username autore
     * @return the text proposta
     */
    public List<String> getTextProposta(String title, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        Pagina p = getPage(title, usernameAutore);
        VersioneProposta proposta=getVersionePropostaFirst(p,a);


        List<String> textProposed = new ArrayList<>();

        if (proposta != null) {

            for (Frase fraseProposta : proposta.getTesto().getFrasi()) {
                textProposed.add(fraseProposta.getTesto());
            }
        }

        return textProposed;
    }

    /**
     * Leggi listino autore.
     */
    public void leggiListinoAutore()
    {
        AutoreDAO ad =  new ImplementazionePostgresAutoreDao();
        List<String> nomeAutore = new ArrayList<>();
        List<String> cognomeAutore = new ArrayList<>();
        List<String> login = new ArrayList<>();
        List<String> password = new ArrayList<>();
        ad.leggiListinoAutore(nomeAutore, cognomeAutore, login, password);
        for (int i = 0; i < nomeAutore.size(); i++) {
            Autore a = new Autore(nomeAutore.get(i), cognomeAutore.get(i), login.get(i), password.get(i));
            listinoIscritti.addListAutore(a);
            listinoIscritti.addListUtente(a);
        }

    }

    /**
     * Leggi listino utenti.
     */
    public void leggiListinoUtenti()
    {
        UtenteDAO ud = new ImplementazionePostgresUtenteDao();
        List<String> nomeUtente = new ArrayList<>();
        List<String> cognomeUtente = new ArrayList<>();
        ud.leggiListinoUtenti(nomeUtente, cognomeUtente);
        for (int i = 0; i < nomeUtente.size(); i++) {
            Utente u = new Utente(nomeUtente.get(i), cognomeUtente.get(i));
            listinoIscritti.addListUtente(u);
        }

    }

    /**
     * Leggi pagine autori.
     */
    public void leggiPagineAutori()
    {
        PaginaDAO pd = new ImplementazionePostgresPaginaDao();
        List<String> titoloPagina = new ArrayList<>();
        List<String> loginAutorePagina = new ArrayList<>();
        List<Date> dataPagina = new ArrayList<>();
        List<Time> oraPagina = new ArrayList<>();

        pd.leggiPagineAutori(titoloPagina,dataPagina ,oraPagina, loginAutorePagina);
        for(Autore a : listinoIscritti.getListAutore())
        {
            for(int i = 0; i<titoloPagina.size(); i++) {
                if (a.getLogin().equals(loginAutorePagina.get(i))) {
                    Pagina p = new Pagina(titoloPagina.get(i), dataPagina.get(i).toLocalDate(),oraPagina.get(i).toLocalTime(),a);
                    a.addListPagine(p);
                }
            }
        }

    }

    /**
     * Leggi frasi pagina.
     */
    public void leggiFrasiPagina()
    {
        FraseDAO fd = new ImplementazionePostgresFrasiDao();
        List<String> titoloPaginaFrase = new ArrayList<>();
        List<String> testoFrase = new ArrayList<>();
        List<Integer> ordineFrase = new ArrayList<>();
        fd.leggiFrasiPagina(testoFrase,titoloPaginaFrase,ordineFrase);
        for(Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                for (int i = 0; i < titoloPaginaFrase.size(); i++) {
                    if (p.getTitolo().equals(titoloPaginaFrase.get(i)))
                    {
                        Frase frase = new Frase(testoFrase.get(i),p.getVersioneCorrente().getTesto());
                        p.getVersioneCorrente().getTesto().addFrase(frase);
                    }
                }
            }
        }

    }

    /**
     * Inserisci versione precedente dba.
     *
     * @param titolo       the titolo
     * @param dataVersione the data versione
     * @param oraVersione  the ora versione
     */
    public void inserisciVersionePrecedenteDBA(String titolo, Date dataVersione, Time oraVersione)
    {
        VersionePrecedenteDAO vp = new ImplementazionePostgresVersionePrecedenteDAO();
        vp.InserisciVersionePrecedenteDBA(titolo,dataVersione,oraVersione);
    }


    /**
     * Accetta proposta.
     *
     * @param usernameAutore the username autore
     * @param titolo         the titolo
     */
    public void accettaProposta(String usernameAutore, String titolo) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        Pagina p=getPage(titolo,usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(titolo,usernameAutore);
        VersioneProposta versioneProposta=getVersionePropostaFirst(p, a);
        versioneProposta.setElaborato(true);
        versioneProposta.setStato(true);
        VersionePrecedente versionePrecedente=new VersionePrecedente();
        versionePrecedente.setTesto(versioneCorrente.getTesto());
        p.addListVersione(versionePrecedente);
        Testo testoNew=new Testo(versioneCorrente);
        versioneCorrente.setTesto(testoNew);
        for (Frase f:versioneProposta.getTesto().getFrasi()) {
            Frase frase=new Frase(f.getTesto(),versioneCorrente.getTesto());
            versioneCorrente.getTesto().addFrase(frase);

        }


        Date data = Date.valueOf(p.getData());
        Time ora = Time.valueOf(p.getOra());
        inserisciVersionePrecedenteDBA(p.getTitolo(),data,ora);


        versioneCorrente.setData(LocalDate.now());
        versioneCorrente.setOra(LocalTime.now());

        //aggiornaVersioneCorrenteDB(p.getTitolo(),data,ora); //aggiorno la versione corrente
    }


    /**
     * Rifiuta proposta.
     *
     * @param usernameAutore the username autore
     * @param titolo         the titolo
     */
    public void rifiutaProposta(String usernameAutore, String titolo) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        Pagina p=getPage(titolo,usernameAutore);
        VersioneProposta versioneProposta=getVersionePropostaFirst(p, a);
        versioneProposta.setElaborato(true);
        versioneProposta.setStato(false);
    }

    /**
     * Gets nome autore.
     *
     * @param usernameAutore the username autore
     * @return the nome autore
     */
    public String getNomeAutore(String usernameAutore) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        return a.getNome();
    }

    /**
     * Gets cognome autore.
     *
     * @param usernameAutore the username autore
     * @return the cognome autore
     */
    public String getCognomeAutore(String usernameAutore) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        return a.getCognome();
    }

    /**
     * Gets data versione.
     *
     * @param titolo         the titolo
     * @param usernameAutore the username autore
     * @return the data versione
     */
    public List<LocalDate> getDataVersione(String titolo, String usernameAutore) {
        Pagina pagina=getPage(titolo,usernameAutore);
        List<LocalDate> data=new ArrayList<>();
        for(int i=0;i<pagina.getVersionePrecedenteList().size();i++)
        {
            data.add(pagina.getVersionePrecedenteList().get(i).getData());
        }
        return data;

    }

    /**
     * Gets ora versione.
     *
     * @param titolo         the titolo
     * @param usernameAutore the username autore
     * @return the ora versione
     */
    public List<LocalTime> getOraVersione(String titolo, String usernameAutore) {
        Pagina pagina=getPage(titolo,usernameAutore);
        List<LocalTime> orario=new ArrayList<>();
        for(int i=0;i<pagina.getVersionePrecedenteList().size();i++)
        {
            orario.add(pagina.getVersionePrecedenteList().get(i).getOra());
        }
        return orario;

    }

    /**
     * Gets testo page versione.
     *
     * @param titolo          the titolo
     * @param dataSelezionata the data selezionata
     * @param oraSelezionata  the ora selezionata
     * @param usernameAutore  the username autore
     * @return the testo page versione
     */
    public List<String> getTestoPageVersione(String titolo, LocalDate dataSelezionata, LocalTime oraSelezionata, String usernameAutore) {
        Pagina pagina=getPage(titolo,usernameAutore);
        Testo testo = null;
        List<String> frasiTesto=new ArrayList<>();
        LocalTime oraNotNano = oraSelezionata.withNano(0);
        for(VersionePrecedente versionePrecedente: pagina.getVersionePrecedenteList())
        {

            LocalTime time = versionePrecedente.getOra();

            LocalTime timeNotNano = time.withNano(0);
            if(dataSelezionata.isEqual(versionePrecedente.getData())&&oraNotNano.equals(timeNotNano))
            {
                testo=versionePrecedente.getTesto();
            }
        }
        if(testo!=null)
        {
            for (Frase frase:testo.getFrasi()) {
                frasiTesto.add(frase.getTesto());
            }
            return frasiTesto;
        }
        return frasiTesto;
    }

    /**
     * Is versioni precedenti boolean.
     *
     * @param title          the title
     * @param usernameAutore the username autore
     * @return the boolean
     */
    public boolean isVersioniPrecedenti(String title, String usernameAutore) {
        Pagina pagina=getPage(title,usernameAutore);
        return !pagina.getVersionePrecedenteList().isEmpty();
    }

    /**
     * Add link boolean.
     *
     * @param title          the title
     * @param position       the position
     * @param selectTitle    the select title
     * @param usernameAutore the username autore
     * @return the boolean
     */
    public boolean addLink(String title, int position, String selectTitle, String usernameAutore) {
        Pagina page=getPage(title,usernameAutore);

        Pagina selectPage=getPagina(selectTitle);
        if(selectPage!=null &&page!=null) {
            Frase frase = page.getVersioneCorrente().getTesto().getFrasi().get(position);
            if(frase!=null) {
                Collegamento collegamento = new Collegamento(selectPage, frase);
                frase.setCollegamento(collegamento);
                return true;
            }
        }
        return false;
    }

    /**
     * Gets pagina.
     *
     * @param title the title
     * @return the pagina
     */
    public Pagina getPagina(String title)
    {
        for (Autore a: listinoIscritti.getListAutore()) {
            for (Pagina p: a.getListPagine()) {
                if(title.equals(p.getTitolo()))
                    return p;

            }

        }
        return null;
    }

    /**
     * Is collegamento boolean.
     *
     * @param title the title
     * @param index the index
     * @return the boolean
     */
    public boolean isCollegamento(String title, int index) {
        if(index!=-1) {
            Pagina pagina = getPagina(title);
            Collegamento collegamento = pagina.getVersioneCorrente().getTesto().getFrasi().get(index).getCollegamento();
            return collegamento != null;
        }
        return false;
    }

    /**
     * Page link string.
     *
     * @param title the title
     * @param index the index
     * @return the string
     */
    public String pageLink(String title, int index) {
        Pagina pagina=getPagina(title);
        return pagina.getVersioneCorrente().getTesto().getFrasi().get(index).getCollegamento().getPagina().getTitolo();
    }

    /**
     * Gets autore.
     *
     * @param titleLink the title link
     * @return the autore
     */
    public String getAutore(String titleLink) {
        for (Autore a:listinoIscritti.getListAutore()) {
            for (Pagina p:a.getListPagine()) {
                if(p.getTitolo().equals(titleLink))
                    return a.getLogin();
            }
        }
        return  null;
    }

    /**
     * Delete page boolean.
     *
     * @param title          the title
     * @param usernameAutore the username autore
     * @return the boolean
     */
    public boolean deletePage(String title, String usernameAutore) {
        Pagina pagina=getPage(title,usernameAutore);
        Autore author=listinoIscritti.searchAutore(usernameAutore);
        if(author!=null&&pagina!=null)
        {
            author.getListPagine().remove(pagina);
            return true;
        }

        return false;

    }

    /**
     * Is notify proposta boolean.
     *
     * @param usernameAutore the username autore
     * @return the boolean
     */
    public boolean isNotifyProposta(String usernameAutore) {
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        if(autore!=null) {
            for (VersioneProposta versioneProposta : autore.getListPropostaGestite()) {
                if (!versioneProposta.isElaborato())
                    return true;
            }
        }
        return false;
    }
    public List<String > getTitlesProposed(String usernameAutore)
    {
        List<String> listTitle=new ArrayList<>();
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        for (VersioneProposta version:autore.getListProposteRichieste()) {
            listTitle.add(version.getPagina().getTitolo());
        }
        return listTitle;
    }

    public List<LocalDate> getDateProposed(String usernameAutore)
    {
        List<LocalDate> listDate=new ArrayList<>();
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        for (VersioneProposta version:autore.getListProposteRichieste()) {
            listDate.add(version.getData());
        }
        return listDate;
    }

    public List<LocalTime> getTimeProposed(String usernameAutore)
    {
        List<LocalTime> listTime=new ArrayList<>();
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        for (VersioneProposta version:autore.getListProposteRichieste()) {
            listTime.add(version.getOra());
        }
        return listTime;
    }

    public boolean isProposedAutore(String usernameAutore) {
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        return !autore.getListProposteRichieste().isEmpty();
    }


    public String getUsernameByTitle(String title) {
        Pagina pagina=getPagina(title);
        return pagina.getAutore().getLogin();
    }
    public List<String> getTestoPageVersioneProposta(String titolo, LocalDate dataSelezionata, LocalTime oraSelezionata, String usernameAutorePage, String usernameAutore) {
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        Testo testo = null;
        List<String> frasiTesto=new ArrayList<>();
        LocalTime oraNotNano = oraSelezionata.withNano(0);
        for(VersioneProposta versioneProposta: autore.getListProposteRichieste())
        {

            LocalTime time = versioneProposta.getOra();

            LocalTime timeNotNano = time.withNano(0);
            if(dataSelezionata.isEqual(versioneProposta.getData())&&oraNotNano.equals(timeNotNano)&&versioneProposta.getPagina().getTitolo().equals(titolo))
            {
                testo=versioneProposta.getTesto();
            }
        }
        if(testo!=null)
        {
            for (Frase frase:testo.getFrasi()) {
                frasiTesto.add(frase.getTesto());
            }
            return frasiTesto;
        }
        return frasiTesto;
    }
}

