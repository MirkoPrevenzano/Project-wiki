package DAO;

import java.sql.Time;
import java.sql.Date;
import java.util.List;

/**
 * The interface Pagina dao.
 */
public interface PaginaDAO {
    /**
     * Leggi pagine autori.
     *
     * @param TitoloPagina the titolo pagina
     * @param DataPagina   the data pagina
     * @param oraPagina    the ora pagina
     * @param loginAutore  the login autore
     */
    void leggiPagineAutori(List<String> TitoloPagina, List<Date> DataPagina, List<Time> oraPagina, List<String> loginAutore);

    /**
     * Inserisci pagine.
     *
     * @param TitoloPagina   the titolo pagina
     * @param dataPagina     the data pagina
     * @param oraPagina      the ora pagina
     * @param usernameAutore the username autore
     */
    void inserisciPagine(String TitoloPagina, Date dataPagina, Time oraPagina, String usernameAutore);
}
