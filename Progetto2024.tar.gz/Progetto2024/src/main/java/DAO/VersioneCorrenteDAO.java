package DAO;

import java.sql.Date;
import java.sql.Time;

/**
 * The interface Versione corrente dao.
 */
public interface VersioneCorrenteDAO {
    /**
     * Aggiorna versione corrente db.
     *
     * @param titolo       the titolo
     * @param dataVersione the data versione
     * @param oraVersione  the ora versione
     */
    void aggiornaVersioneCorrenteDB(String titolo, Date dataVersione, Time oraVersione);
}
