package DAO;

import java.sql.Date;
import java.sql.Time;

public interface VersioneCorrenteDAO {
    void aggiornaVersioneCorrenteDB(String titolo, Date dataVersione, Time oraVersione);
}
