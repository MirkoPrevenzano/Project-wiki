package DAO;

import java.util.List;

public interface AutoreDAO {
    void leggiListinoAutore(List<String> nomeAutore, List<String> cognomeAutore, List<String> login, List<String> password);
}
