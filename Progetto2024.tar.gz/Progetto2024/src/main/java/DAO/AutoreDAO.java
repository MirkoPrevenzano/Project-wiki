package DAO;

import java.util.List;

/**
 * The interface Autore dao.
 */
public interface AutoreDAO {
    /**
     * Leggi listino autore.
     *
     * @param nomeAutore    the nome autore
     * @param cognomeAutore the cognome autore
     * @param login         the login
     * @param password      the password
     */
    void leggiListinoAutore(List<String> nomeAutore, List<String> cognomeAutore, List<String> login, List<String> password);

    /**
     * Inserisci autore.
     *
     * @param nomeAutore    the nome autore
     * @param cognomeAutore the cognome autore
     * @param username      the username
     * @param password      the password
     */
    void inserisciAutore(String nomeAutore, String cognomeAutore, String username, String password);
}
