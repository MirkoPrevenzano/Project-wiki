package DAO;

import java.util.List;

public interface FraseDAO {
    void leggiFrasiPagina(List<String> TestoFrase, List<String> TitoloPagina, List<Integer> ordine);
}
