package DAO;

import java.sql.Date;
import java.sql.Time;

public interface VersionePrecedenteDAO {

    void InserisciVersionePrecedenteDBA(String titolo, Date dataVersione, Time oraVersione);
}
