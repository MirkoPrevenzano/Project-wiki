package DAO;

import java.sql.Date;
import java.sql.Time;

/**
 * The interface Versione precedente dao.
 */
public interface VersionePrecedenteDAO {

    /**
     * Inserisci versione precedente dba.
     *
     * @param titolo       the titolo
     * @param dataVersione the data versione
     * @param oraVersione  the ora versione
     */
    void InserisciVersionePrecedenteDBA(String titolo, Date dataVersione, Time oraVersione);
}
