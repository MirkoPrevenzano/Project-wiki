package ImplementazionePostgresDao;

import DAO.PaginaDAO;
import Database.ConnessioneDB;

import java.sql.*;
import java.sql.Date;
import java.util.List;

/**
 * The type Implementazione postgres pagina dao.
 */
public class ImplementazionePostgresPaginaDao implements PaginaDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres pagina dao.
     */
    public ImplementazionePostgresPaginaDao() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void leggiPagineAutori(List<String> titoloPagina, List<Date> dataPagina, List<Time> oraPagina, List<String> loginAutore) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM pagina");
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                titoloPagina.add((rs.getString("titolo")));
                loginAutore.add(rs.getString("username"));
                dataPagina.add(rs.getDate("data"));
                oraPagina.add(rs.getTime("ora"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }

    public void inserisciPagine(String titoloPagina, Date dataPagina, Time oraPagina, String usernameAutore) {
        try
        {
            PreparedStatement inserisciListinoPS = connection.prepareStatement(
                    "INSERT INTO pagina (titolo,data,ora,username) VALUES (?,?,?,?) ");
            inserisciListinoPS.setString(1,titoloPagina);
            inserisciListinoPS.setDate(2,dataPagina);
            inserisciListinoPS.setTime(3,oraPagina);
            inserisciListinoPS.setString(4,usernameAutore);

            inserisciListinoPS.executeUpdate();


            connection.close();
            inserisciListinoPS.close();


        }catch(Exception e)
        {
            System.out.println("Errore: " + e.getMessage());
        }
    }

}