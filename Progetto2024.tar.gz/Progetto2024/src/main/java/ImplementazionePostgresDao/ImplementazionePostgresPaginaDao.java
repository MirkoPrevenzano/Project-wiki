package ImplementazionePostgresDao;

import DAO.PaginaDAO;
import Database.ConnessioneDB;

import java.sql.*;
import java.sql.Date;
import java.util.List;

public class ImplementazionePostgresPaginaDao implements PaginaDAO {
    private Connection connection;

    public ImplementazionePostgresPaginaDao() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void leggiPagineAutori(List<String> TitoloPagina, List<Date> dataPagina, List<Time> oraPagina, List<String> loginAutore) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM pagina");
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                TitoloPagina.add((rs.getString("titolo")));
                loginAutore.add(rs.getString("username"));
                dataPagina.add(rs.getDate("data"));
                oraPagina.add(rs.getTime("ora"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }
}