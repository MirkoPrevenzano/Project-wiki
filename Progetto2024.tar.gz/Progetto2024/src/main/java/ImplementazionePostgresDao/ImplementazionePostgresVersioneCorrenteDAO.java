package ImplementazionePostgresDao;

import DAO.VersioneCorrenteDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;

/**
 * The type Implementazione postgres versione corrente dao.
 */
public class ImplementazionePostgresVersioneCorrenteDAO implements VersioneCorrenteDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres versione corrente dao.
     */
    public ImplementazionePostgresVersioneCorrenteDAO()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void aggiornaVersioneCorrenteDB(String titolo, Date dataVersione, Time oraVersione) //da completare dopo proposte
    {

    }
}
