package ImplementazionePostgresDao;

import DAO.AutoreDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ImplementazionePostgresAutoreDao implements AutoreDAO {
    private Connection connection;

    public ImplementazionePostgresAutoreDao()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void leggiListinoAutore(List<String> nomeAutore, List<String> cognomeAutore, List<String> login, List<String> password) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement(
                    "SELECT * FROM autore");
            ResultSet rs = leggiListinoPS.executeQuery();

            while (rs.next()) {
                nomeAutore.add(rs.getString("nome_a"));
                cognomeAutore.add(rs.getString("cognome"));
                login.add(rs.getString("username"));
                password.add(rs.getString("password"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }
}
