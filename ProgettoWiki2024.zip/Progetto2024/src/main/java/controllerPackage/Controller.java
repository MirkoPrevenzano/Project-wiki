package controllerPackage;


import DAO.*;
import ImplementazionePostgresDao.*;
import Model.*;
import Model.Pagina;
import org.jetbrains.annotations.NotNull;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

/**
 * The type Controller.
 */
public class Controller {
    private final ListinoIscritti listinoIscritti = new ListinoIscritti();


    /**
     * Add new autore : metodo che aggiunge un nuovo autore.
     *
     * @param name     the name: nome autore
     * @param surname  the surname: cognome autore
     * @param username the username
     * @param password the password
     * @return the boolean: false se l'username dell'autore è già esistente, true se l'iscrizione è andata a buon fine
     */
    public boolean addNewAutore(String name, String surname, String username, String password) {
        for (Autore a : listinoIscritti.getListAutore()
        ) {
            if (a.getLogin().equals(username))
                return false;

        }
        Autore autore = new Autore(name, surname, username, password);
        addAutoreDB(name,surname,username,password);

        listinoIscritti.addListAutore(autore);
        listinoIscritti.addListUtente(autore);
        return true;
    }



    /**
     * Add new utente :metodo che aggiunge un nuovo utente.
     *
     * @param name    the name: nome utente
     * @param surname the surname: cognome utente
     * @return the boolean: false se l'username dell'utente è già esistente, true se l'iscrizione è andata a buon fine
     */
    public boolean addNewUtente(String name, String surname) {
        for (Utente u : listinoIscritti.getListUtente()
        ) {
            if (u.getNome().equals(name) && u.getCognome().equals(surname))
                return false;

        }
        Utente utente = new Utente(name, surname);
        addUtente(name,surname);
        listinoIscritti.addListUtente(utente);

        return true;
    }



    /**
     * Access autore int
     *
     * @param username the username.
     * @param password the password.
     * @return the int:1 se l'accesso è andato a buon fine, 2 se la password è sbagliata, 0 se non esiste autore con quall'username
     */
    public int accessAutore(String username, String password) {
        for (Autore a : listinoIscritti.getListAutore()) {
            if (a.getLogin().equals(username)) {
                if (Boolean.TRUE.equals(a.signIn(username, password))) {
                    return 1;
                } else {
                    return 2;
                }
            }
        }
        return 0;
    }


    /**
     * Access utente boolean.
     *
     * @param name    the name: nome utente
     * @param surname the surname: cognome utente
     * @return the boolean: true se esiste l'utente
     */
    public Boolean accessUtente(String name, String surname) {

        for (Utente utente : listinoIscritti.getListUtente()) {
            if (utente.getNome().equals(name) && utente.getCognome().equals(surname)) {
                return true;
            }

        }
        return false;

    }

    /**
     * Aggiunge una pagina
     *
     * @param title          titolo pagina
     * @param usernameAutore autore pagina
     * @return the boolean: false se già esiste una pagina con quel titolo
     */
    public Boolean addPage(String title, String usernameAutore) {
        Autore author = listinoIscritti.searchAutore(usernameAutore);
        for(Autore a:listinoIscritti.getListAutore() )
        {
            for (Pagina p : a.getListPagine()) {
                if (p.getTitolo().equals(title)) {
                    return false;
                }

            }

        }

        Pagina p = new Pagina(title, author);
        Date data = Date.valueOf(p.getData());
        Time ora = Time.valueOf(p.getOra());
        addPagina(title,data,ora,author.getLogin());
        author.addListPagine(p);
        return true;
    }



    /**
     * Gets page: prendo pagina con un determinato titolo (uso l'username per diminuire range di ricerca)
     *
     * @param title          titolo pagina
     * @param usernameAutore autore pagina
     * @return the page
     */
    public Pagina getPage(String title, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> page = a.getListPagine();
        return page.stream().filter(paginaT -> paginaT.getTitolo().equals(title)).findFirst().orElse(null);
    }

    /**
     * Gets versione corrente: se la pagina esiste, ritorna la sua versione corrente
     *
     * @param title          titolo pagina
     * @param usernameAutore autore pagina
     * @return the versione corrente
     */
    public VersioneCorrente getVersioneCorrente(String title, String usernameAutore)
    {
       Pagina p=getPage(title,usernameAutore);
       if(p!=null)
       {
           return p.getVersioneCorrente();
       }
       return null;
    }

    /**
     * Gestione testo page: inserisce frase nella versione corrente di una pagina appena creata( chiamata del metodo da CrazionePagina
     * dalla gui, una frase per volta). Questa frase la inserisco poi nel database
     *
     * @param newFrase       nuova frase
     * @param usernameAutore autore pagina
     * @param title          titolo
     */
    public void gestioneTestoPage(String newFrase, String usernameAutore, String title) {
        VersioneCorrente versioneCorrente=getVersioneCorrente(title,usernameAutore);
        Frase f = new Frase(newFrase, versioneCorrente.getTesto());
        versioneCorrente.getTesto().addFrase(f);
        addFraseDB(newFrase,versioneCorrente.getTesto().getFrasi().size(),title);
    }




    /**
     * Metodo che dato un usernameAutore prende i titoli delle
     * pagine di cui è autore
     *
     * @param usernameAutore autore
     * @return lista di titoli di un determinato autore
     */
    public List<String> uploadTitles(String usernameAutore) {

        Autore author = listinoIscritti.searchAutore(usernameAutore);
        List<Pagina> p = author.getListPagine();
        List<String> title = new ArrayList<>();
        for (Pagina pp : p
        ) {
            title.add(pp.getTitolo());
        }
        return title;
    }

    /**
     * Metodo che ritorna la lista di tutti i
     * titoli di tutte le pagine
     *
     * @return lista di pagine
     */
    public List<String> uploadTitles() {
        List<String> title = new ArrayList<>();
        for (Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                title.add((p.getTitolo()));
            }
        }

        return title;
    }

    /**
     * Dato un titolo e un autore, prende le frasi presenti nella versione corrente
     * del titolo selezionato.
     *
     * @param titlePagina    titolo pagina
     * @param usernameAutore autore pagina
     * @return i contentuti delle frasi dal testo
     */
    public List<String> getTestoPage(String titlePagina, String usernameAutore) {

        VersioneCorrente versioneCorrente=getVersioneCorrente(titlePagina,usernameAutore);
        List<Frase> listFraseTesto;
        if(versioneCorrente!=null)
        {
            listFraseTesto = versioneCorrente.getTesto().getFrasi();
            if(listFraseTesto!=null) {
                List<String> testoPage = new ArrayList<>();
                for (Frase f : listFraseTesto) {
                    testoPage.add(f.getTesto());
                }

                return testoPage;
            }
        }

        return null;
    }


    /**
     * Data una pagina, una lista di frasi selezionate e una lista di modifiche associate
     * modifica la versione corrente con un nuovo testo  modificato dall'autore della pagina
     * e crea una versione precendente con il testo precedente.
     * Il for scorre tutte le frasi, se la frase è una selezionata e modificate, prende la corrispettiva
     * modifica.
     *
     * @param selectedPhrases indici frasi selezionate
     * @param modifies        frasi modificate
     * @param title           titolo
     * @param usernameAutore  autore pagina
     */
    public void modifyTesto(List<Integer> selectedPhrases, List<String> modifies, String title, String usernameAutore) {

        Pagina pagina = getPage(title, usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(title,usernameAutore);
        VersionePrecedente versionePrecedente=new VersionePrecedente();

        versionePrecedente.setTesto(versioneCorrente.getTesto());
        pagina.addListVersione(versionePrecedente);
        Testo testoNew=new Testo(versioneCorrente);
        versioneCorrente.setTesto(testoNew);

        int ctr;
        for(int i=0;i<versionePrecedente.getTesto().getFrasi().size();i++)
        {
            ctr=-1;
            for (int index:selectedPhrases) {
                if(i==index)
                {
                    if(!(modifies.get(selectedPhrases.indexOf(index)).equals(" "))) {
                        Frase frase = new Frase(modifies.get(selectedPhrases.indexOf(index)), versioneCorrente.getTesto());
                        versioneCorrente.getTesto().addFrase(frase);
                    }
                    ctr=1;
                }
            }
            if(ctr==-1)
            {
                Frase frase=new Frase(versionePrecedente.getTesto().getFrasi().get(i).getTesto(),versioneCorrente.getTesto());
                Collegamento collegamento=versionePrecedente.getTesto().getFrasi().get(i).getCollegamento();
                if(collegamento!=null)
                {
                    frase.setCollegamento(collegamento);
                    collegamento.setFrase(frase);
                }
                versioneCorrente.getTesto().addFrase(frase);
            }
        }

    }

    /**
     *  Metodo per salvare la proposta di un certo utente su una pagina cercata dato un titolo , chiamando il metodo
     *  createPropostaUtente che crea effettivamente l'oggetto versioneProposta
     *
     * @param listPhrases   indici frasi selezionate
     * @param modifies      modifiche frasi
     * @param title         titolo pagina
     * @param nameUtente    nome utente che propone
     * @param surnameUtente cognome utente che propone
     */
    public void savePropostaUtente(List<Integer> listPhrases, List<String> modifies, String title, String nameUtente, String surnameUtente)
    {
        List<Frase> selectedPhrases = new ArrayList<>();
        if(!listPhrases.isEmpty()) {
            Utente u = listinoIscritti.searchUtente(nameUtente, surnameUtente);
            for (Autore a : listinoIscritti.getListAutore()) {
                for (Pagina p : a.getListPagine()) {
                    if (p.getTitolo().equals(title)) {
                        createPropostaUtente(p,title, listPhrases,selectedPhrases,modifies,u,a);
                        return;

                    }
                }
            }
        }

    }

    /**
     * Crea la proposta utente. Scorre una lista di integer che corrispondono alla posizione della frase selezionata, prende l'oggetto frase.
     * Tale proposta poi è inserita anche nel database attraverso la funzione addProposta e le frasi del nuovo testo proposto
     * Se l'utente che propone la modifica è l'autore della pagina stessa chiama il metodo modifyTesto per aggiornare la versione corrente e
     * la modifica anche nel database
     *
     * @param page            pagina selezionata
     * @param title           titolo pagina
     * @param listFrasi       lista frasi selezionate
     * @param selectedPhrases indici frasi selezionate
     * @param modifies        frasi modificate
     * @param utente          utente che effettua modifica
     * @param autore          autore della pagina
     */
    public void createPropostaUtente(Pagina page, String title, List<Integer> listFrasi, List<Frase> selectedPhrases, List<String> modifies, Utente utente, Autore autore) {

             VersioneCorrente versioneCorrente = getVersioneCorrente(title, autore.getLogin());

             for (Integer integer : listFrasi) {

                 selectedPhrases.add(versioneCorrente.getTesto().getFrasi().get(integer));
             }
             VersioneProposta proposta = new VersioneProposta(utente, autore, page, selectedPhrases, modifies);
             createTesto(modifies, page, listFrasi, proposta);

             LocalDate localDate = LocalDate.now(); //db
             LocalTime localTime = LocalTime.now();

             Date data = Date.valueOf(localDate);
             Time ora = Time.valueOf(localTime);
             addPropostaDB(utente.getNome(),utente.getCognome(),title,data,ora,false,false);
             addFrasiSelezionate(listFrasi, title, data, ora);
             addFrasiModificate(listFrasi, title, data, ora, modifies);
             for(int i=0;i<proposta.getTesto().getFrasi().size();i++)
             {
                 ImplementazionePostgresFrasiDao vfd= new ImplementazionePostgresFrasiDao();
                 vfd.addFraseVersionePropostaDB(proposta.getTesto().getFrasi().get(i).getTesto(), i+1, title,data,ora);
             }

             if (proposta.isElaborato()) {
                 modifyTesto(listFrasi, modifies, title, autore.getLogin());
                 ImplementazionePostgresVersioneProposta vp=new ImplementazionePostgresVersioneProposta();
                 vp.updateProposte(title,data,ora, true, true);

             }

     }





    /**
     * Creo testo della nuova versione proposta
     *
     * @param modifies       modifche frasi
     * @param page           pagina da modificare
     * @param listFrasiIndex indice frasi selezionate
     * @param proposta       proposta
     *
     */
    public void createTesto(List<String> modifies, Pagina page, List<Integer> listFrasiIndex, VersioneProposta proposta)
    {
        VersioneCorrente versioneCorrente=getVersioneCorrente(page.getTitolo(), page.getAutore().getLogin());
        proposta.setTesto(new Testo(proposta));

        for(int i=0;i<versioneCorrente.getTesto().getFrasi().size();i++)
        {
            int ctr=-1;
            int sent=-1;
            for(int j=0;j<listFrasiIndex.size();j++)
            {
                if(listFrasiIndex.get(j)==i)
                {
                    ctr=listFrasiIndex.get(j);
                    sent=j;
                }
            }
            if(ctr!=-1&&!modifies.get(sent).equals(" "))
            {
                Frase frase=new Frase(modifies.get(sent), proposta.getTesto());
                proposta.getTesto().addFrase(frase);
            }
            else if(ctr==-1)
            {
                Frase frase=new Frase(versioneCorrente.getTesto().getFrasi().get(i).getTesto(), proposta.getTesto());
                Collegamento collegamento=versioneCorrente.getTesto().getFrasi().get(i).getCollegamento();
                if(collegamento!=null)
                {
                    frase.setCollegamento(collegamento);
                    collegamento.setFrase(frase);
                }
                proposta.getTesto().addFrase(frase);
            }

        }
    }


    /**
     * Metodo per prendere le frasi di un testo di una versione corrente dato un titolo di pagina.
     *
     * @param titlePagina titolo pagina
     * @return contenuto delle frasi di un testo
     */
    public List<String> getTestoPage(String titlePagina) {
        List<String> testoPage = new ArrayList<>();
        Autore a = null;
        for(int i=0;i<listinoIscritti.getListAutore().size();i++)
        {
            if(getPage(titlePagina,listinoIscritti.getListAutore().get(i).getLogin())!=null)
            {
                a=listinoIscritti.getListAutore().get(i);
            }
        }

       if(a!=null) {
           VersioneCorrente versioneCorrente = getVersioneCorrente(titlePagina, a.getLogin());
           if (versioneCorrente != null) {
               List<Frase> listFraseTesto = versioneCorrente.getTesto().getFrasi();
               for (Frase f : listFraseTesto) {
                   testoPage.add(f.getTesto());
               }
           }
       }
        
        return testoPage;
    }

    /**
     * controllo se dato un autore e una pagina c'è una proposta ancora non elaborata
     *
     * @param usernameAutore autore pagina
     * @param title          titolo pagina
     * @return true se esiste una proposta non elaborata
     */
    public Boolean isProposta(String usernameAutore, String title) {
        Pagina page = getPage(title, usernameAutore);
        Autore autore = listinoIscritti.searchAutore(usernameAutore);
        for (VersioneProposta pr : autore.getListPropostaGestite()
        ) {
            if (pr.getPagina()==page&&!pr.isElaborato())
                return true;

        }
        return false;
    }


    /**
     * Prende la versione in ordine della meno recente, data una pagina e un autore
     *
     * @param pagina oggetto pagina
     * @param autore oggetto autore riferito alla pagina
     * @return versione non elaborata meno recente
     */
    public VersioneProposta getVersionePropostaFirst(Pagina pagina, Autore autore) {
        VersioneProposta proposta=null;
        for (VersioneProposta prop : autore.getListPropostaGestite()
        ) {
            if (prop.getPagina() == pagina && !prop.isElaborato()) {
                if (proposta == null)
                    proposta = prop;
                else if (proposta.getData().isAfter(prop.getData())) {
                    proposta = prop;

                } else if (proposta.getData().equals(prop.getData()) && (proposta.getOra().isAfter(prop.getOra())))
                        {proposta = prop;

                }
            }

        }
        return proposta;
    }

    /**
     * Metodo che prende contenuto frasi di un testo di una versione proposta, ottenuta dal metodo getVersionePropostaFrist
     * dato un titolo e un autore
     *
     * @param title          titolo pagina
     * @param usernameAutore autore pagina
     * @return contenuto testo
     */
    public List<String> getTextProposta(String title, String usernameAutore) {
        Autore a = listinoIscritti.searchAutore(usernameAutore);
        Pagina p = getPage(title, usernameAutore);
        VersioneProposta proposta=getVersionePropostaFirst(p,a);


        List<String> textProposed = new ArrayList<>();

        if (proposta != null) {

            for (Frase fraseProposta : proposta.getTesto().getFrasi()) {
                textProposed.add(fraseProposta.getTesto());
            }
        }

        return textProposed;
    }







    /**
     *  metodo dove una proposta è accettata quindi viene aggiornata la versione corrente e creata una versione precedente
     *  tutte le modifiche vengono salvate nel database.
     * @param title titolo pagina da modificare
     * @param usernameAutore autore della pagina che ha accettato la proposta
     *
     */
    public void processedProposta(String usernameAutore, String title) {
        Autore autore =listinoIscritti.searchAutore(usernameAutore);
        Pagina pagina =getPage(title,usernameAutore);
        VersioneCorrente versioneCorrente=getVersioneCorrente(title,usernameAutore);
        VersioneProposta versioneProposta=getVersionePropostaFirst(pagina, autore);
        versioneProposta.setElaborato(true);
        versioneProposta.setStato(true);
        VersionePrecedente versionePrecedente=new VersionePrecedente();
        versionePrecedente.setTesto(versioneCorrente.getTesto());
        pagina.addListVersione(versionePrecedente);
        Testo testoNew=new Testo(versioneCorrente);
        versioneCorrente.setTesto(testoNew);

        for (Frase f:versioneProposta.getTesto().getFrasi()) {
            Frase frase=new Frase(f.getTesto(),versioneCorrente.getTesto());
            Collegamento collegamento=f.getCollegamento();
            if(collegamento!=null)
            {
                frase.setCollegamento(collegamento);
                collegamento.setFrase(frase);
            }
            versioneCorrente.getTesto().addFrase(frase);

        }
        versioneCorrente.setData(LocalDate.now());
        versioneCorrente.setOra(LocalTime.now());

        addVersionePrecedenteDB(pagina.getTitolo(),Date.valueOf(LocalDate.now()),Time.valueOf(LocalTime.now()));
        updateVersioneCorrenteDB(pagina.getTitolo(),Date.valueOf(LocalDate.now()),Time.valueOf(LocalTime.now()), versioneProposta.getTesto().getFrasi());
        updateProposteDB(pagina.getTitolo(),Date.valueOf(versioneProposta.getData()), Time.valueOf(versioneProposta.getOra()),true,true);
    }





    /**
     * Rifiuta proposta e aggiorna valori nel db dello stato della proposta con updateProposte
     *
     * @param usernameAutore autore pagina
     * @param title          titolo pagina
     */
    public void rifiuteProposta(String usernameAutore, String title) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        Pagina p=getPage(title,usernameAutore);
        VersioneProposta versioneProposta=getVersionePropostaFirst(p, a);
        versioneProposta.setElaborato(true);
        versioneProposta.setStato(false);

        updateProposteDB(p.getTitolo(),Date.valueOf(versioneProposta.getData()),Time.valueOf(versioneProposta.getOra()),false,true);
    }

    /**
     * Dato l'username ricava il nome dell'autore.
     *
     * @param usernameAutore username autore
     * @return nome autore
     */
    public String getNomeAutore(String usernameAutore) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        return a.getNome();
    }

    /**
     * Dato l'username ricava il cognome dell'autore.
     *
     * @param usernameAutore username autore
     * @return cognome autore
     */
    public String getCognomeAutore(String usernameAutore) {
        Autore a=listinoIscritti.searchAutore(usernameAutore);
        return a.getCognome();
    }

    /**
     * dato un titolo e un autore, ritorna una lista di date delle sue versioni precedenti
     *
     * @param title          titolo pagina
     * @param usernameAutore username autore
     * @return lista di date
     */
    public List<LocalDate> getDateVersione(String title, String usernameAutore) {
        Pagina pagina=getPage(title,usernameAutore);
        List<LocalDate> date=new ArrayList<>();
        for(int i=0;i<pagina.getVersionePrecedenteList().size();i++)
        {
            date.add(pagina.getVersionePrecedenteList().get(i).getData());
        }
        return date;

    }

    /**
     * dato un titolo e un autore, ritorna una lista di ore delle sue versioni precedenti
     *
     * @param title          titolo pagina
     * @param usernameAutore username autore
     * @return lista di orari
     */
    public List<LocalTime> getTimeVersione(String title, String usernameAutore) {
        Pagina pagina=getPage(title,usernameAutore);
        List<LocalTime> time=new ArrayList<>();
        for(int i=0;i<pagina.getVersionePrecedenteList().size();i++)
        {
            time.add(pagina.getVersionePrecedenteList().get(i).getOra());
        }
        return time;

    }

    /**
     * Metodo che prende il contenuto delle frasi di una data versione precedente dato un orario, titolo e data precisa
     *
     * @param title          titolo
     * @param date           data selezionata
     * @param time           ora selezionata
     * @param usernameAutore username autore
     * @return  contenuto frasi versione precedente
     */
    public List<String> getTestoPageVersione(String title, LocalDate date, @NotNull LocalTime time, String usernameAutore) {
        Pagina pagina=getPage(title,usernameAutore);
        Testo testo = null;
        List<String> frasiTesto=new ArrayList<>();
        LocalTime oraNotNano = time.withNano(0);
        for(VersionePrecedente versionePrecedente: pagina.getVersionePrecedenteList())
        {

            LocalTime timeVersion = versionePrecedente.getOra();

            LocalTime timeNotNano = timeVersion.withNano(0);
            if(date.isEqual(versionePrecedente.getData())&&oraNotNano.equals(timeNotNano))
            {
                testo=versionePrecedente.getTesto();
            }
        }
        if(testo!=null)
        {
            for (Frase frase:testo.getFrasi()) {
                frasiTesto.add(frase.getTesto());
            }
            return frasiTesto;
        }
        return frasiTesto;
    }

    /**
     * Controlla se una pagina, dato un titolo, ha versioni precedenti
     *
     * @param title          titolo
     * @param usernameAutore autore pagina
     * @return true se sono presenti versioni precedenti
     */
    public boolean isVersioniPrecedenti(String title, String usernameAutore) {
        Pagina pagina=getPage(title,usernameAutore);
        return !pagina.getVersionePrecedenteList().isEmpty();
    }

    /**
     * Metodo che inserisce un collegamento ad un oggetto frase che si riferisce ad una data pagina destinazione
     *
     * @param title          titolo pagina
     * @param position       indice frase selezionata
     * @param selectTitle    titolo pagina destinazione
     * @param usernameAutore autore pagina sorgente
     * @return true se l'inserimento di un collegamento è andato a buon fine
     */
    public boolean addLink(String title, int position, String selectTitle, String usernameAutore) {
        Pagina page=getPage(title,usernameAutore);

        Pagina selectPage=getPagina(selectTitle);
        if(selectPage!=null &&page!=null) {
            Frase frase = page.getVersioneCorrente().getTesto().getFrasi().get(position);
            if(frase!=null) {
                Collegamento collegamento = new Collegamento(selectPage, frase);
                frase.setCollegamento(collegamento);
                addCollegamentoDB(selectPage.getTitolo(),page.getTitolo(),position+1);
                return true;
            }
        }
        return false;
    }

    /**
     * Data un titolo ritorna l'oggetto pagina riferito
     *
     * @param title titolo
     * @return pagina
     */
    public Pagina getPagina(String title)
    {
        for (Autore autore: listinoIscritti.getListAutore()) {
            for (Pagina pagina : autore.getListPagine()) {
                if(title.equals(pagina.getTitolo()))
                    return pagina;

            }

        }
        return null;
    }

    /**
     * metodo che verifica se una frase possiede un collegamento
     *
     * @param title titolo pagina
     * @param index indice frase selezionata
     * @return true se esiste collegamento
     */
    public boolean isCollegamento(String title, int index) {
        if(index!=-1) {
            Pagina pagina = getPagina(title);
            Collegamento collegamento = pagina.getVersioneCorrente().getTesto().getFrasi().get(index).getCollegamento();
            return collegamento != null;
        }
        return false;
    }

    /**
     * Metodo che prende da un collegamento il titolo della pagina destinataria
     *
     * @param title titolo
     * @param index indice frase selezionata
     * @return titolo pagina destinataria
     */
    public String pageLink(String title, int index) {
        Pagina pagina=getPagina(title);
        return pagina.getVersioneCorrente().getTesto().getFrasi().get(index).getCollegamento().getPagina().getTitolo();
    }

    /**
     * Dato il titolo di una pagina, prendo il suo username
     *
     * @param title titolo pagina
     * @return the autore
     */
    public String getAutore(String title) {
        for (Autore a:listinoIscritti.getListAutore()) {
            for (Pagina p:a.getListPagine()) {
                if(p.getTitolo().equals(title))
                    return a.getLogin();
            }
        }
        return  null;
    }

    /**
     * metodo che cancella una pagina
     *
     * @param title          titolo pagina
     * @param usernameAutore username autore
     * @return true se operazione ben riuscita
     */
    public boolean deletePage(String title, String usernameAutore) {
        Pagina pagina=getPage(title,usernameAutore);
        Autore author=listinoIscritti.searchAutore(usernameAutore);
        if(author!=null&&pagina!=null)
        {
            author.getListPagine().remove(pagina);
            return true;
        }

        return false;

    }

    /**
     * metodo che controlla, dato un autore, se ha delle nuove proposte da analizzare
     *
     * @param usernameAutore  username autore
     * @return true se ci sono proposte ancora non elaborate da tale autore
     */
    public boolean isNotifyProposta(String usernameAutore) {
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        if(autore!=null) {
            for (VersioneProposta versioneProposta : autore.getListPropostaGestite()) {
                if (!versioneProposta.isElaborato())
                    return true;
            }
        }
        return false;
    }

    /**
     * metodo che prende la lista dei titoli delle proposte fatte da un dato usernameAutore
     *@param usernameAutore  username autore
     * @return lista di titoli
     */
    public List<String > getTitlesProposed(String usernameAutore)
    {
        List<String> listTitle=new ArrayList<>();
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        for (VersioneProposta version:autore.getListProposteRichieste()) {
            listTitle.add(version.getPagina().getTitolo());
        }
        return listTitle;
    }

    /**
     * metodo che prende la lista delle date delle proposte fatte da un dato usernameAutore
     * @param usernameAutore  username autore
     * @return lista di date
     */
    public List<LocalDate> getDateProposed(String usernameAutore)
    {
        List<LocalDate> listDate=new ArrayList<>();
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        for (VersioneProposta version:autore.getListProposteRichieste()) {
            listDate.add(version.getData());
        }
        return listDate;
    }

    /**
     * metodo che prende la lista di orari delle proposte fatte da un dato usernameAutore
     *@param usernameAutore  username autore
     * @return lista di orari
     */
    public List<LocalTime> getTimeProposed(String usernameAutore)
    {
        List<LocalTime> listTime=new ArrayList<>();
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        for (VersioneProposta version:autore.getListProposteRichieste()) {
            listTime.add(version.getOra());
        }
        return listTime;
    }
    /**
     * metodo che verifica se un dato usernameAutore ha fatto qualche proposta
     * @param usernameAutore  username autore
     * @return true se c'è qualche proposta
     */
    public boolean isProposedAutore(String usernameAutore) {
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        return !autore.getListProposteRichieste().isEmpty();
    }

    /**
     * metodo che prende l'username di un autore dato un titolo di una pagina
     *@param title titolo di una pagina
     * @return l'username dell'autore
     */
    public String getUsernameByTitle(String title) {
        Pagina pagina=getPagina(title);
        return pagina.getAutore().getLogin();
    }

    /**
     * metodo che prende la lista dei contenuti delle frasi di una versione proposta fatte da un dato usernameAutore
     * @param usernameAutore  username autore
     * @param date  data di versione proposta
     * @param time  orario di versione proposta
     * @param title titolo pagina
     * @return lista di contenuti delle frasi
     */
    public List<String> getTestoPageVersioneProposta(String title, LocalDate date, @NotNull LocalTime time, String usernameAutore) {
        Autore autore=listinoIscritti.searchAutore(usernameAutore);
        Testo testo = null;
        List<String> frasiTesto=new ArrayList<>();
        LocalTime oraNotNano = time.withNano(0);
        for(VersioneProposta versioneProposta: autore.getListProposteRichieste())
        {

            LocalTime timeVersion = versioneProposta.getOra();

            LocalTime timeNotNano = timeVersion.withNano(0);
            if(date.isEqual(versioneProposta.getData())&&oraNotNano.equals(timeNotNano)&&versioneProposta.getPagina().getTitolo().equals(title))
            {
                testo=versioneProposta.getTesto();
            }
        }
        if(testo!=null)
        {
            for (Frase frase:testo.getFrasi()) {
                frasiTesto.add(frase.getTesto());
            }
            return frasiTesto;
        }
        return frasiTesto;
    }

    /*METODI DATABASE*/

    /**
     * Inserisce autore nel database
     *
     * @param name   the name autore: nome autore
     * @param surname the surname autore: cognome autore
     * @param username      the username
     * @param password      the password
     */
    public void addAutoreDB(String name, String surname, String username, String password)
    {
        AutoreDAO ad = new ImplementazionePostgresAutoreDao();
        ad.addAutore(name,surname, username, password);

    }

    /**
     * Inserisce utente nel database
     *
     * @param name    the name: nome utente
     * @param surname the surname: cognome utente
     */
    public void addUtente(String name, String surname)
    {
        UtenteDAO ud = new ImplementazionePostgresUtenteDao();
        ud.addUtente(name,surname);
    }

    /**
     * Add pagina: inserimento pagina nel database
     *
     * @param titlePagina    titolo pagina
     * @param datePagina     data di creazione pagina
     * @param timePagina     ora di creazione pagina
     * @param usernameAutore autore pagina
     */
    public void addPagina(String titlePagina, Date datePagina, Time timePagina, String usernameAutore)
    {
        PaginaDAO pd = new ImplementazionePostgresPaginaDao();
        pd.addPagine(titlePagina,datePagina,timePagina,usernameAutore);
    }


    /**
     * Metodo che aggiunge una frase nel database
     *
     * @param textFrase contenuto frase
     * @param order     posizione
     * @param title     titolo pagina
     */
    public void addFraseDB(String textFrase, int order, String title)
    {
        FraseDAO fd = new ImplementazionePostgresFrasiDao();
        fd.addFraseDB(textFrase,order, title);

    }


    /**
     *  aggiungo nel database le modifiche frasi, attraverso data, ora e titolo ottengo
     *  poi la versione proposta corretta a cui associarle
     * @param listFrasi   indici frasi selezionate
     * @param title       titolo pagina
     * @param date        data proposta pubblicate
     * @param time        ora proposta pubblicata
     * @param modifies    modifiche frasi
     *
     */
    private void addFrasiModificate(List<Integer> listFrasi, String title, Date date, Time time, List<String> modifies) {

        for(int i=0;i<listFrasi.size();i++)
        {
            ImplementazionePostgresModificaDAO addModify=new ImplementazionePostgresModificaDAO();
            addModify.addModificaDAO(modifies.get(i), title, date,time, listFrasi.get(i));
        }
    }


    /**
     *  aggiungo nel database le frasi selezionate, attraverso data, ora e titolo ottengo
     *  poi la versione proposta corretta a cui associarle
     * @param listFrasi   indici frasi selezionate
     * @param title       titolo pagina
     * @param date        data proposta pubblicate
     * @param time        ora proposta pubblicata
     *
     */
    private void addFrasiSelezionate(List<Integer> listFrasi, String title, Date date, Time time) {
        for(int order:listFrasi)
        {
            ImplementazionePostgresSelezionaDAO addSelect=new ImplementazionePostgresSelezionaDAO();
            addSelect.addSelezioneDAO(title,date,time,order);
        }
    }


    /**
     * prende dal database autori iscritti
     */
    public void readAutoreDB()
    {
        AutoreDAO autoreDB=  new ImplementazionePostgresAutoreDao();
        List<String> nomeAutore = new ArrayList<>();
        List<String> cognomeAutore = new ArrayList<>();
        List<String> login = new ArrayList<>();
        List<String> password = new ArrayList<>();
        autoreDB.readListinoAutore(nomeAutore, cognomeAutore, login, password);
        for (int i = 0; i < nomeAutore.size(); i++) {
            Autore a = new Autore(nomeAutore.get(i), cognomeAutore.get(i), login.get(i), password.get(i));
            listinoIscritti.addListAutore(a);
            listinoIscritti.addListUtente(a);
        }

    }

    /**
     * Carica dal database gli utenti iscritti
     */
    public void readUtenteDB()
    {
        UtenteDAO utenteDB = new ImplementazionePostgresUtenteDao();
        List<String> nomeUtente = new ArrayList<>();
        List<String> cognomeUtente = new ArrayList<>();
        utenteDB.readListinoUtenti(nomeUtente, cognomeUtente);
        for (int i = 0; i < nomeUtente.size(); i++) {
            Utente u = new Utente(nomeUtente.get(i), cognomeUtente.get(i));
            listinoIscritti.addListUtente(u);
        }

    }

    /**
     * Carica per ogni autore tutte le sue pagine
     */
    public void readPaginaDB()
    {
        PaginaDAO paginaDB = new ImplementazionePostgresPaginaDao();
        List<String> titoloPagina = new ArrayList<>();
        List<String> loginAutorePagina = new ArrayList<>();
        List<Date> dataPagina = new ArrayList<>();
        List<Time> oraPagina = new ArrayList<>();

        paginaDB.readPagineAutori(titoloPagina,dataPagina ,oraPagina, loginAutorePagina);
        for(Autore a : listinoIscritti.getListAutore())
        {
            for(int i = 0; i<titoloPagina.size(); i++) {
                if (a.getLogin().equals(loginAutorePagina.get(i))) {
                    Pagina pagina = new Pagina(titoloPagina.get(i), dataPagina.get(i).toLocalDate(),oraPagina.get(i).toLocalTime(),a);
                    a.addListPagine(pagina);
                }
            }
        }

    }

    /**
     * Carica le frasi per ogni pagina di ogni autore dal database
     */
    public void readFrasePaginaDB()
    {
        FraseDAO fraseDB = new ImplementazionePostgresFrasiDao();
        List<String> titoloPaginaFrase = new ArrayList<>();
        List<String> testoFrase = new ArrayList<>();
        List<Integer> ordineFrase = new ArrayList<>();
        fraseDB.readFrasiPagina(testoFrase,titoloPaginaFrase,ordineFrase);
        for(Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                for (int i = 0; i < titoloPaginaFrase.size(); i++) {
                    if (p.getTitolo().equals(titoloPaginaFrase.get(i)))
                    {
                        Frase frase = new Frase(testoFrase.get(i),p.getVersioneCorrente().getTesto());
                        p.getVersioneCorrente().getTesto().addFrase(frase);
                    }
                }
            }
        }

    }

    /**
     * Carica le versione precedenti per ogni pagina di ogni autore, dal database
     */
    public void readVersionePrecedenteDB()
    {
        VersionePrecedenteDAO versionePrecedenteDB = new ImplementazionePostgresVersionePrecedenteDAO();
        List<String> titoloPagina = new ArrayList<>();
        List<Date> dataVersione = new ArrayList<>();
        List<Time> oraVersione = new ArrayList<>();
        List<String> testoFrase = new ArrayList<>();
        versionePrecedenteDB.readVersionePrecedenteDB(titoloPagina, dataVersione, oraVersione);
        for(Autore a : listinoIscritti.getListAutore()) {
            for (Pagina p : a.getListPagine()) {
                for (int i = 0; i < titoloPagina.size(); i++) {
                    if (p.getTitolo().equals(titoloPagina.get(i))) {
                        VersionePrecedente versionePrecedente = new VersionePrecedente(dataVersione.get(i).toLocalDate(), oraVersione.get(i).toLocalTime());
                        p.addListVersione(versionePrecedente);
                        VersionePrecedenteDAO versionePrecedenteDAO = new ImplementazionePostgresVersionePrecedenteDAO();
                        versionePrecedenteDAO.readFrasiVersionePrecedenteDB(titoloPagina.get(i), dataVersione.get(i), oraVersione.get(i), testoFrase);
                        for (String s : testoFrase) {
                            Frase f = new Frase(s, versionePrecedente.getTesto());
                            versionePrecedente.getTesto().addFrase(f);

                        }
                        testoFrase.clear();
                    }
                }
            }
        }
    }

    /**
     * inserisce una versione precedente nel database
     *
     * @param title titolo pagina
     * @param date data creazione versione precedente
     * @param time orario creazione versione precedente
     */
    public void addVersionePrecedenteDB(String title, Date date, Time time)
    {
        VersionePrecedenteDAO versionePrecedenteDAO = new ImplementazionePostgresVersionePrecedenteDAO();
        versionePrecedenteDAO.addVersionePrecedenteDB(title,date,time);
    }

    /**
     * carica dal database le versioni proposte
     */
    public void readVersionePropostaDB()
    {
        VersionePropostaDAO versionePropostaDAO = new ImplementazionePostgresVersioneProposta();
        List<String> username = new ArrayList<>();
        List<String> nomeUtente = new ArrayList<>();
        List<String> cognomeUtente = new ArrayList<>();
        List<String> title = new ArrayList<>();
        List<Date> date = new ArrayList<>();
        List<Time> time = new ArrayList<>();
        List <Frase> selectPhrases = new ArrayList<>();
        List<String> modifies = new ArrayList<>();
        List<Integer> order = new ArrayList<>();
        List<Integer> idTesto = new ArrayList<>();
        List<Integer> idProposta = new ArrayList<>();
        List<Boolean> confirm=new ArrayList<>();
        List<Boolean> status =new ArrayList<>();
        versionePropostaDAO.readListinoProposta(username,nomeUtente,cognomeUtente, title, date, time, idTesto, idProposta, confirm, status);

        for(int i = 0; i< idProposta.size(); i++)
        {
            Pagina p = getPage(title.get(i),username.get(i));
            Autore a = listinoIscritti.searchAutore(username.get(i));
            Utente u = listinoIscritti.searchUtente(nomeUtente.get(i),cognomeUtente.get(i));

            SelezioneDAO selezioneDAO = new ImplementazionePostgresSelezionaDAO();
            selezioneDAO.readSelezionate(idProposta.get(i), order);

            order.replaceAll(integer -> integer - 1);

            for(Integer o : order)
            {
                selectPhrases.add(p.getVersioneCorrente().getTesto().getFrasi().get(o));
                ModificaDAO modificaDAO = new ImplementazionePostgresModificaDAO();
                modifies.add(modificaDAO.readModifiche(o+1, idProposta.get(i)));
            }



            VersioneProposta versioneproposta = new VersioneProposta(u,a,p, selectPhrases, modifies);
            versioneproposta.setOra(time.get(i).toLocalTime());
            versioneproposta.setData(date.get(i).toLocalDate());
            versioneproposta.setElaborato(confirm.get(i));
            versioneproposta.setStato(status.get(i));

            createTesto(modifies,p, order, versioneproposta);
            modifies.clear();
            selectPhrases.clear();
            order.clear();

        }

    }

    public void addPropostaDB(String nomeUtente, String cognomeUtente, String title, Date date, Time time, Boolean status, Boolean confirm)
    {
        String username=getUsernameByTitle(title);
        VersionePropostaDAO versionePropostaDAO = new ImplementazionePostgresVersioneProposta();
        versionePropostaDAO.addProposta(username,nomeUtente,cognomeUtente, title, date, time, status, confirm);
    }

    /**
     *  risultato della proposta elaborata
     * @param title titolo pagina di cui si propone la modifica
     * @param date data della proposta
     * @param time orario proposta
     * @param confirm informazione se elaborata la proposta dall'autore
     * @param status stato proposta
     */
    public  void updateProposteDB(String title, Date date, Time time, Boolean status, Boolean confirm)
    {
        VersionePropostaDAO versionePropostaDAO = new ImplementazionePostgresVersioneProposta();
        versionePropostaDAO.updateProposte(title, date, time, status, confirm);
    }


    /**
     *  carica collegamento nel database
     * @param title titolo pagina contenente il collegamento
     * @param destTitle titolo pagina destinazione
     * @param frasePosition posizione della frase che contiene il collegamento
     */
    public void addCollegamentoDB(String destTitle, String title , int frasePosition)
    {
        CollegamentoDAO collegamentoDAO = new ImplementazionePostgresCollegamentoDao();
        collegamentoDAO.addCollegamentoDB(destTitle, title, frasePosition);
    }


    /**
     *  metodo che aggiorna la versione corrente nel database
     * @param title      titolo pagina da aggiornare
     * @param date       data di aggiornamento versione corrente
     * @param listFrase  lista frasi della nuova versione
     * @param time       orario di aggiornamento versione corrente
     *
     */
    private void updateVersioneCorrenteDB(String title, Date date, Time time, @NotNull List<Frase> listFrase) {
        ImplementazionePostgresVersioneCorrenteDAO implementazionePostgresVersioneCorrenteDAO =new ImplementazionePostgresVersioneCorrenteDAO();
        implementazionePostgresVersioneCorrenteDAO.updateVersioneCorrenteDB(title, date, time);

        for(int i = 0; i< listFrase.size(); i++) {
            ImplementazionePostgresFrasiDao implementazionePostgresFrasiDao =new ImplementazionePostgresFrasiDao();

            implementazionePostgresFrasiDao.addFraseDB(listFrase.get(i).getTesto(), i + 1, title);
        }
    }



   public void readCollegamento() {
        CollegamentoDAO takeSourcePage = new ImplementazionePostgresCollegamentoDao();
        List<Integer> idTesto = new ArrayList<>();
        takeSourcePage.readCollegamento(idTesto);
       for (Integer integer : idTesto) {
           String sourcePage;
           List<Integer> positions = new ArrayList<>();
           List<String> destTitle = new ArrayList<>();
           VersioneCorrenteDAO searchPage = new ImplementazionePostgresVersioneCorrenteDAO();
           sourcePage = searchPage.takeTitle(integer);
           Pagina pagina = getPagina(sourcePage);
           CollegamentoDAO takeCollegamenti = new ImplementazionePostgresCollegamentoDao();
           takeCollegamenti.readSourceFrase(integer, positions, destTitle);
           for (int j = 0; j < positions.size(); j++) {
               Collegamento collegamento = new Collegamento(getPagina(destTitle.get(j)), pagina.getVersioneCorrente().getTesto().getFrasi().get(positions.get(j) - 1));
               pagina.getVersioneCorrente().getTesto().getFrasi().get(positions.get(j) - 1).setCollegamento(collegamento);

           }
       }
    }


    public void addInfoDB() {
       readAutoreDB();
       readUtenteDB();
       readPaginaDB();
       readFrasePaginaDB();
       readVersionePrecedenteDB();
       readVersionePropostaDB();
       readCollegamento();
    }
}

