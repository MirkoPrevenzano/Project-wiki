package gui;

import controllerPackage.Controller;
import javax.swing.*;
import java.util.List;

/**
 * The type View proposte: visualizza versione corrente e proposta. Permette di accettare o rifiutare una proposta ed, eventualmente, visualizzare la successiva
 */
public class ViewProposte {
    private JPanel panel1;
    private JButton returnButton;
    private JTextArea textOriginal;
    private JTextArea textPrevious;
    private JButton rifiuteButton;
    private JButton acceptButton;

    /**
     * The Frame.
     */
    public final JFrame frame;

    /**
     * Instantiates a new View proposte.
     *
     * @param controller      controller
     * @param framePrevious   frame precedente
     * @param usernameAutore  username autore
     * @param title           titolo pagina
     * @param phrases         frasi pagina
     * @param frameHomeAutore frame schermata autore
     */
    public ViewProposte(final Controller controller, final JFrame framePrevious, final String usernameAutore, final String title, final List<String> phrases, final JFrame frameHomeAutore) {
        this.frame = new JFrame("Proposta: "+title);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);

        textPrevious.setEditable(false);
        textOriginal.setEditable(false);

        appendText(textOriginal, phrases);
        List<String> textToPrevious = controller.getTextProposta(title, usernameAutore);
        appendText(textPrevious, textToPrevious);



        returnButton.addActionListener(e -> {
            frame.setVisible(false);
            frameHomeAutore.setVisible(true);
            frame.dispose();
        });


        acceptButton.addActionListener(e -> {
                controller.processedProposta(usernameAutore,title);
                returnButton.setVisible(false);

                if(Boolean.TRUE.equals(controller.isProposta(usernameAutore,title)))
                {
                    JOptionPane.showMessageDialog(frame,"Proposta accettata, aggiornamento effettuato!");

                    textPrevious.setText("");
                    List<String> textProposed = controller.getTextProposta(title, usernameAutore);
                    appendText(textPrevious,textProposed);


                    textOriginal.setText("");
                    List<String> phrasesOriginal=controller.getTestoPage(title);
                    appendText(textOriginal, phrasesOriginal);


                }
                else
                {
                    JOptionPane.showMessageDialog(frame,"Proposta accettata, aggiornamento effettuato! Hai elaborato tutte le proposte");

                    acceptButton.setVisible(false);
                    rifiuteButton.setVisible(false);
                    returnButton.setVisible(true);
                }
        });


        rifiuteButton.addActionListener(e -> {
            controller.rifiuteProposta(usernameAutore,title);
            returnButton.setVisible(false);

            if(Boolean.TRUE.equals(controller.isProposta(usernameAutore,title)))
            {
                JOptionPane.showMessageDialog(frame,"Proposta rifiutata");

                textPrevious.setText("");
                List<String> textProposed = controller.getTextProposta(title, usernameAutore);
                appendText(textPrevious,textProposed);

                List<String> phrasesOriginal=controller.getTestoPage(title);
                textOriginal.setText("");
                appendText(textOriginal,phrasesOriginal );


            }
            else
            {
                JOptionPane.showMessageDialog(frame,"Proposta rifiutata! Hai elaborato tutte le proposte");
                acceptButton.setVisible(false);
                rifiuteButton.setVisible(false);
                returnButton.setVisible(true);
            }
        });
    }

    /**
     * Riempie la JTextArea selezionata con le frasi passate
     *
     * @param text     JTextArea (proposta o corrente)
     * @param phrases  lista frasi da inserire
     */
    private void appendText(JTextArea text, List<String> phrases) {
        for (String phrase : phrases) {
            if (!phrase.endsWith("\n"))
                text.append(phrase + "\n");
            else
                text.append(phrase);
        }
    }


}
