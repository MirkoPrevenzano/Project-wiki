package gui;

import controllerPackage.Controller;

import javax.swing.*;

/**
 * The type Home.
 */
public class Home {
    private final Controller controller;
    private static JFrame frame;
    private JButton autoreAccessButton;
    private JButton utenteAccessButton;
    private JButton registration;
    private JPanel panel1;

    /**
     * Schermata principale con la quale puoi accedere alla schermata di iscrizione,
     * oppure alla schermata per accedere, come utente o autore
     * Al momento dell'avvio dell'applicazione, dal database vengono caricate tutte le info
     */
    public Home() {
        controller = new Controller();
        controller.addInfoDB();

        autoreAccessButton.addActionListener(e -> {
            AccessoAutore accessoAutore = new AccessoAutore(controller, frame);
            accessoAutore.frame.setVisible(true);
            frame.setVisible(false);
        });


        registration.addActionListener(e -> {
            Iscrizione iscrizione = new Iscrizione(controller, frame);
            iscrizione.frame.setVisible(true);
            frame.setVisible(false);

        });


        utenteAccessButton.addActionListener(e -> {
            AccessoUtente accessoUtente = new AccessoUtente(controller, frame);
            accessoUtente.frame.setVisible(true);
            frame.setVisible(false);
        });
    }

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        frame = new JFrame("Home");
        Home home = new Home();
        frame.setContentPane(home.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(420, 80);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);


    }

}
