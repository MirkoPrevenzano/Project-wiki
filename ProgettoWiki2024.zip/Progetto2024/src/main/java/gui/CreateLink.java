package gui;

import controllerPackage.Controller;
import javax.swing.*;
import java.util.List;

/**
 * The type Create link:creare un collegamento verso una pagina scelta tra gli item della comboBox
 */
public class CreateLink {
    private JComboBox <String> titleComboBox;
    private JButton addButton;
    private JPanel panel1;

    public  final JFrame frame;
    private Timer messageTimer;

    /**
     *
     * @param controller     controller
     * @param framePrevious  frame precedente
     * @param position       posizione frase
     * @param title          titolo pagina
     * @param usernameAutore username autore
     */
    public CreateLink(final Controller controller, final JFrame framePrevious, final int position,  final String title, final String usernameAutore )
    {
        this.frame = new JFrame("");
        this.frame.setContentPane(this.panel1);
        frame.setSize(300, 100);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);

        List<String> titles=controller.uploadTitles();
        titles.remove(title);


        titleComboBox.addItem("");
        for (String title1 : titles) {
            titleComboBox.addItem(title1);
        }


        addButton.addActionListener(e -> {
            String selectTitle= (String) titleComboBox.getSelectedItem();
            if(selectTitle!=null) {

                if (controller.addLink(title, position, selectTitle, usernameAutore)) {
                    JOptionPane.showMessageDialog(frame, "Collegamento aggiunto");
                    frame.setVisible(false);
                }
                else {
                    showMessage("Errore nell'inserimento!");
                }
            }
            else
            {
                showMessage("Seleziona una frase");
            }

        });
    }

    /**
     * Metodo che dato un messaggio, fa comparire una finestra dialogo per 1 secondo
     * @param message messaggio informativo
     */
    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }
}
