package gui;

import javax.swing.*;
import java.util.List;

/**
 * The type Only view page:Schermata che mostra il contenuto di una pagina, di sola lettura. Nessun azione possibile
 */
public class OnlyViewPage {

    /**
     * The Frame.
     */
    public final JFrame frame;
    private JPanel panel1;
    private JTextArea textVersion;
    private JButton returnButton;

    /**
     * Schermata che mostra il contenuto di una pagina, di sola lettura. Nessun azione possibile
     *
     * @param framePrevious  frame precedente
     * @param listPhrases    frasi pagina
     * @param title          titolo
     * @param usernameAutore username autore
     */
    public OnlyViewPage( JFrame framePrevious, List<String> listPhrases, String title, String usernameAutore) {
        this.frame = new JFrame(title+ "("+usernameAutore+")");
        this.frame.setContentPane(panel1);
        this.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);

        textVersion.setEditable(false);

        if (listPhrases != null) {
            for (String listPhrase : listPhrases) {
                if (!listPhrase.endsWith("\n"))
                    textVersion.append(listPhrase + "\n");
                else
                    textVersion.append(listPhrase);
            }
        }


        returnButton.addActionListener(e -> {
            frame.setVisible(false);
            frame.dispose();
            framePrevious.setVisible(true);
        });
    }
}
