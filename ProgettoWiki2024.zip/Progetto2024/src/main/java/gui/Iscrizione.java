package gui;

import controllerPackage.Controller;

import javax.swing.*;

/**
 * The type Iscrizione: permette l'iscrizione nel sistema, di un utente o di un autore
 */
public class Iscrizione {
    public final JFrame frame;
    private JLabel username;
    private JLabel password;
    private JTextField textSurname;
    private JTextField textUsername;
    private JTextField textPassword;
    private JTextField textName;
    private JPanel panel1;
    private JButton returnButton;
    private JButton registrationButton;
    private JRadioButton buttonAutore;
    private Timer messageTimer;

    /**
     * Schermata per l'iscrizione
     *
     * @param controller    the controller
     * @param framePrevious frame Home
     */
    public Iscrizione(final Controller controller, final JFrame framePrevious) {
        frame = new JFrame("Registrazione");
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setResizable(false);
        frame.setLocationRelativeTo(framePrevious);

        setComponent(false);

        returnButton.addActionListener(e -> {
            frame.setVisible(false);
            framePrevious.setVisible(true);
            frame.dispose();

        });


        registrationButton.addActionListener(e -> {
            if (buttonAutore.isSelected()) {

                if (textName.getText().isBlank() || textSurname.getText().isBlank() || textUsername.getText().isBlank() || textPassword.getText().isBlank()) {
                    showMessage("Compila tutti i campi");
                }
                else {

                    boolean ctr = controller.addNewAutore(textName.getText(), textSurname.getText(), textUsername.getText(), textPassword.getText());
                    registrationMethod( framePrevious, ctr,"Autore");

                }

            }
            else {

                if (textName.getText().isBlank() || textSurname.getText().isBlank()) {
                    showMessage( "Compila tutti i campi");
                }
                else {
                    boolean ctr = controller.addNewUtente(Iscrizione.this.textName.getText(), Iscrizione.this.textSurname.getText());
                    registrationMethod( framePrevious, ctr,"Utente");

                }

            }


        });


        buttonAutore.addActionListener(e -> setComponent(buttonAutore.isSelected()));
    }

    /**
     * Verifica se l'utente/autore è già iscritto
     * @param framePrevious frame Home
     * @param ctr           valore true se utente/autore non iscritto
     * @param type          indica il tipo utente
     */
    private void registrationMethod(JFrame framePrevious, boolean ctr, String type) {

        if (ctr) {
            completeRegistration(framePrevious);


        } else
            showMessage(type+ "già iscritto");

    }

    /**
     * Registrazione completata, riapre schermata Home
     * @param framePrevious frame Home
     */
    private void completeRegistration(JFrame framePrevious) {
        JOptionPane.showMessageDialog(frame, "Iscrizione completata con successo");
        frame.setVisible(false);
        framePrevious.setVisible(true);
        frame.dispose();
    }


    /**
     * Setta i componenti a value
     * @param value
     */
    private void setComponent(Boolean value)
    {
        textUsername.setVisible(value);
        textPassword.setVisible(value);
        username.setVisible(value);
        password.setVisible(value);
    }


    /**
     * Metodo che dato un messaggio, fa comparire una finestra dialogo per 1 secondo
     * @param message messaggio informativo
     */
    private void showMessage(String message) {
        JOptionPane optionPane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);
    }
}
