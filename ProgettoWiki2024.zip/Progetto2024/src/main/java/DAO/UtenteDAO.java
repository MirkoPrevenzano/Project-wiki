package DAO;

import java.util.List;

/**
 * The interface Utente dao.
 */
public interface UtenteDAO {
    /**
     * Leggi listino utenti.
     *
     * @param nomeUtente    nome utente
     * @param cognomeUtente cognome utente
     */
    void readListinoUtenti(List<String> nomeUtente, List<String> cognomeUtente);

    /**
     * Inserisci utente.
     *
     * @param nome    nome
     * @param cognome cognome
     */
    void addUtente(String nome, String cognome);
}
