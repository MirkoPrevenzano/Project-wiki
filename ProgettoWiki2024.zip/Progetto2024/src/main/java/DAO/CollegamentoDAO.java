package DAO;

import java.util.List;

public interface CollegamentoDAO {

    /**
     * @param idTesto idTesto
     */
    void readCollegamento(List<Integer> idTesto);

    /**
     *
     * @param idTesto      idTesto
     * @param positions    posizione frase
     * @param destPage     pagina collegamento
     */
    void readSourceFrase(int idTesto, List<Integer> positions, List<String> destPage);

    /**
     *
     * @param destinationTitle titolo della pagina di destinazione
     * @param sourceTitle      titolo della pagina sorgente
     * @param position         posizione frase in cui è presente il collegamento
     */
    void addCollegamentoDB(String destinationTitle, String sourceTitle ,int position);
}
