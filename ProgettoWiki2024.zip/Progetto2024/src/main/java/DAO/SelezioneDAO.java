package DAO;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

public interface SelezioneDAO {


    /**
     * Inserisci frase db.
     *@param title testo frase
     * @param date  data proposta
     * @param time  ora proposta
     * @param order posizione frase
     */
    void addSelezioneDAO(String title, Date date, Time time, int order);

    /**
     * Read selezionate.
     *
     * @param idProposta identificativo proposta nel db
     * @param order      posizione frase
     */
    void readSelezionate(Integer idProposta, List<Integer> order);

}
