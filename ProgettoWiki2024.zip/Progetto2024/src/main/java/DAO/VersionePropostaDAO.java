package DAO;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

/**
 * The interface Versione proposta dao.
 */
public interface VersionePropostaDAO {
    /**
     * Read listino proposta.
     *
     * @param username      username autore
     * @param nomeUtente    nome utente
     * @param cognomeUtente cognome utente
     * @param titles        lista titoli
     * @param date          lista date
     * @param time          lista orari
     * @param idTesto       identificativo testo nel db
     * @param idProposta    identificativo proposta nel db
     * @param processed     elaborato
     * @param status        stato proposta
     */
    void readListinoProposta(List<String> username, List<String> nomeUtente, List<String> cognomeUtente, List<String> titles, List<Date> date, List<Time> time, List<Integer> idTesto, List<Integer> idProposta, List<Boolean> processed, List<Boolean> status);





    /**
     * Add proposta.
     *
     * @param username      username autore pagina
     * @param nomeUtente    nome utente
     * @param cognomeUtente cognome utente
     * @param title         titolo pagina di cui si propone modifica
     * @param date          data proposta
     * @param time          orario proposta
     * @param status        stato proposta
     * @param processed     stato elaborazione
     */
    void addProposta(String username, String nomeUtente, String cognomeUtente, String title, Date date, Time time, Boolean status, Boolean processed);

    /**
     * Update proposte.
     *
     * @param title         titolo pagina di cui si propone modifica
     * @param date          data proposta
     * @param time          orario proposta
     * @param status        stato proposta
     * @param processed     stato elaborazione
     */
    void updateProposte(String title,Date date, Time time,Boolean status, Boolean processed);

    /**
     * Restituisce idProposta dato un titolo, la data e l'orario di creazione
     * @param date   data proposta
     * @param time   orario proposta
     * @param title  titolo pagina
     * @return idProposta
     */
    int takeIdProposta(Date date, Time time, String title);
}
