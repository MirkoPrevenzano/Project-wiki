package DAO;

import java.sql.Time;
import java.sql.Date;
import java.util.List;

/**
 * The interface Pagina dao.
 */
public interface PaginaDAO {
    /**
     * Leggi pagine autori.
     *
     * @param titlePagina titolo pagina
     * @param date        data pagina
     * @param time        ora pagina
     * @param loginAutore login autore
     */
    void readPagineAutori(List<String> titlePagina, List<Date> date, List<Time> time, List<String> loginAutore);

    /**
     * Inserisci pagine.
     *
     * @param titlePagine    titolo pagina
     * @param date           data pagina
     * @param time           ora pagina
     * @param usernameAutore username autore
     */
    void addPagine(String titlePagine, Date date, Time time, String usernameAutore);
}
