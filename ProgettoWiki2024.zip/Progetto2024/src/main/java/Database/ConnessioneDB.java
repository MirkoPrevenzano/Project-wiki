package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * The type Connessione db: classe che connette il sistema al database
 */
public class ConnessioneDB {
    private static ConnessioneDB instance;
    /**
     * The Connection.
     */
    public Connection connection = null;

    private ConnessioneDB() throws SQLException {
        try {
            String driver = "org.postgresql.Driver";
            Class.forName(driver);
            String nome = "postgres";
            String password = "07092021";
            String url = "jdbc:postgresql://localhost:5432/postgres";
            connection = DriverManager.getConnection(url, nome, password);

        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }

    }

    /**
     * Gets instance.
     *
     * @return the instance
     * @throws SQLException the sql exception
     */
    public static ConnessioneDB getInstance() throws SQLException {
        if (instance == null) {
            instance = new ConnessioneDB();
        } else if (instance.connection.isClosed()) {
            instance = new ConnessioneDB();
        }
        return instance;
    }
}


