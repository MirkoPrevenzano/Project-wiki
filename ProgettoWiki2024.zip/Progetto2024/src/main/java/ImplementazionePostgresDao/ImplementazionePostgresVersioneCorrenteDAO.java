package ImplementazionePostgresDao;

import DAO.VersioneCorrenteDAO;
import Database.ConnessioneDB;

import java.sql.*;

/**
 * The type Implementazione postgres versione corrente dao.
 */
public class ImplementazionePostgresVersioneCorrenteDAO implements VersioneCorrenteDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres versione corrente dao.
     */
    public ImplementazionePostgresVersioneCorrenteDAO()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /**
     * Aggiornamento di una versione corrente
     * @param title titolo
     * @param date  data versione
     * @param time  ora versione
     */
    public void updateVersioneCorrenteDB(String title, Date date, Time time)
    {

        ImplementazionePostgresTestoDao testo=new ImplementazionePostgresTestoDao();
        int idTestoMax=testo.takeMaxIdTesto();
        ImplementazionePostgresTestoDao testoNew=new ImplementazionePostgresTestoDao();
        testoNew.insertTesto(idTestoMax+1,title);


        try(PreparedStatement insertTestoPS = connection.prepareStatement("UPDATE versionecorrente SET id_testo=?, ora=?, data=? WHERE titolo=?\n")){
            insertTestoPS.setInt(1,idTestoMax+1);
            insertTestoPS.setTime(2, time);
            insertTestoPS.setDate(3, date);
            insertTestoPS.setString(4, title);
            insertTestoPS.executeUpdate();
        }catch (Exception e) {
           e.printStackTrace();
        }
    }

    /**
     * Dato un titolo, è letto il suo idTesto dalla versione corrente
     * @param title titolo pagina
     * @return idTesto
     */
    public int takeIdTesto(String title)
    {
        int idTesto=0;
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT id_testo " +
                            "FROM versionecorrente " +
                            "WHERE  titolo = ?"
            );


            statement.setString(1, title);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                idTesto = resultSet.getInt("id_testo");
            }

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return idTesto;
    }

    /**
     * Dato un titolo, restituisce idTesto di versione corrente
     * @param idTesto idTesto
     * @return
     */
    @Override
    public String takeTitle(int idTesto) {
        String title = null;
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT titolo " +
                            "FROM versionecorrente " +
                            "WHERE  id_testo = ?"
            );


            statement.setInt(1, idTesto);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                title = resultSet.getString("titolo");
            }

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return title;

    }
}
