package ImplementazionePostgresDao;

import DAO.VersionePropostaDAO;
import Database.ConnessioneDB;

import java.sql.*;
import java.util.List;

/**
 * The type Implementazione postgres versione proposta.
 */
public class ImplementazionePostgresVersioneProposta implements VersionePropostaDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres versione proposta.
     */
    public ImplementazionePostgresVersioneProposta() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Caricamento di tutte le versione proposte, dal database
     * @param username      username autore
     * @param nomeUtente    nome utente
     * @param cognomeUtente cognome utente
     * @param titles        lista titoli
     * @param date          lista date
     * @param time          lista orari
     * @param idTesto       identificativo testo nel db
     * @param idProposta    identificativo proposta nel db
     * @param processed     elaborato
     * @param status        stato proposta
     */
    public void readListinoProposta(List<String> username, List<String> nomeUtente, List<String> cognomeUtente, List<String> titles, List<Date> date, List<Time> time, List<Integer> idTesto, List<Integer> idProposta, List<Boolean> processed, List<Boolean> status) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM versioneproposta ");
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                username.add(rs.getString("username"));
                nomeUtente.add(rs.getString("Nome_U"));
                cognomeUtente.add(rs.getString("Cognome_U"));
                titles.add(rs.getString("titolo"));
                date.add(rs.getDate("data"));
                time.add(rs.getTime("ora"));
                idTesto.add(rs.getInt("id_testo"));
                idProposta.add(rs.getInt("id_proposta"));
                processed.add(rs.getBoolean("elaborato"));
                status.add(rs.getBoolean("stato"));

            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**Metodo chiamato al momento di creazione di una versione proposta
     * @param username      username autore pagina
     * @param nomeUtente    nome utente
     * @param cognomeUtente cognome utente
     * @param title         titolo pagina di cui si propone modifica
     * @param date          data proposta
     * @param time          orario proposta
     * @param status        stato proposta
     * @param processed     stato elaborazione
     */
    public void addProposta(String username, String nomeUtente, String cognomeUtente, String title, Date date, Time time, Boolean status, Boolean processed)
    {
        try {
            ImplementazionePostgresTestoDao testoDao=new ImplementazionePostgresTestoDao();
            int idTestoMax = testoDao.takeMaxIdTesto();
            ImplementazionePostgresTestoDao testoNew=new ImplementazionePostgresTestoDao();
            testoNew.insertTesto(idTestoMax+1,title);

            PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO versioneproposta (titolo, data, ora, username,nome_U,cognome_U,stato,elaborato, id_testo) VALUES (?, ?, ?,?,?,?,?,?,?)");

                    inserisciListinoPS.setString(1, title);
                    inserisciListinoPS.setDate(2, date);
                    inserisciListinoPS.setTime(3, time);
                    inserisciListinoPS.setString(4, username);
                    inserisciListinoPS.setString(5, nomeUtente);
                    inserisciListinoPS.setString(6, cognomeUtente);
                    inserisciListinoPS.setBoolean(7, status);
                    inserisciListinoPS.setBoolean(8, processed);
                    inserisciListinoPS.setInt(9,idTestoMax+1);
                    inserisciListinoPS.executeUpdate();



            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Chiamato nel momento di elaborazione di una proposta da parte dell'autore, modifica stato e elaborato
     * @param title         titolo pagina di cui si propone modifica
     * @param date          data proposta
     * @param time          orario proposta
     * @param status        stato proposta
     * @param processed     stato elaborazione
     */
    public void updateProposte(String title, Date date, Time time, Boolean status, Boolean processed) {
        try {
            PreparedStatement updatelistinoPS = connection.prepareStatement("UPDATE versioneproposta " +
                    "SET stato = ?, elaborato = ? WHERE titolo = ? AND data = ? AND ora = ?");
            updatelistinoPS.setBoolean(1, status);
            updatelistinoPS.setBoolean(2, processed);
            updatelistinoPS.setString(3, title);
            updatelistinoPS.setDate(4, date);
            updatelistinoPS.setTime(5, time);
            updatelistinoPS.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Dato un orario, una data e un titolo, restituisce l'idProposta
     * @param date   data proposta
     * @param time   orario proposta
     * @param title  titolo pagina
     * @return idProposta
     */
    public int takeIdProposta(Date date, Time time, String title)
    {
        int idProposta=0;
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT id_proposta " +
                            "FROM versioneproposta " +
                            "WHERE data = ? AND ora = ? AND titolo = ?"
            );


            statement.setDate(1, date);
            statement.setTime(2, time);
            statement.setString(3, title);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                idProposta = resultSet.getInt("id_proposta");
            }
            statement.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return idProposta;
    }

}
