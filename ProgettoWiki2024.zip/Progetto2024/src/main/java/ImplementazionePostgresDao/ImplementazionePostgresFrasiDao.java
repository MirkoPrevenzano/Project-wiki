package ImplementazionePostgresDao;

import DAO.FraseDAO;
import Database.ConnessioneDB;

import java.sql.*;
import java.util.List;

/**
 * Implementazione postgres frasi dao.
 */
public class ImplementazionePostgresFrasiDao implements FraseDAO {

    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres frasi dao.
     */
    public ImplementazionePostgresFrasiDao()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Lettura nel database di tutte le frasi
     * @param testoFrase  testo frase
     * @param titlePagina titolo pagina
     * @param order       ordine
     */
    public void readFrasiPagina(List<String> testoFrase, List<String> titlePagina, List<Integer> order)
    {
        try
        {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM (frase NATURAL INNER JOIN testo) NATURAL INNER JOIN versionecorrente ORDER BY  titolo, ordine ");
            ResultSet rs = leggiListinoPS.executeQuery();
            while(rs.next())
            {
                testoFrase.add(rs.getString("testo_effettivo"));
                titlePagina.add(rs.getString("titolo"));
                order.add(rs.getInt("ordine"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Inserimento di frasi nel database
     * @param testoFrase   testo frase
     * @param order        ordine
     * @param titoloPagina titolo
     */
    public void addFraseDB(String testoFrase, int order, String titoloPagina) {
        try {
            int test = -1;

            try (PreparedStatement getTesto = connection.prepareStatement("SELECT id_testo \n" +
                    "FROM pagina JOIN versionecorrente ON versionecorrente.titolo = pagina.titolo WHERE versionecorrente.titolo = ?")) {
                getTesto.setString(1, titoloPagina);
                ResultSet rs = getTesto.executeQuery();
                if (rs.next()) {
                    test = rs.getInt("id_testo");
                }
            }

            if (test != -1) {
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO frase (testo_effettivo, id_testo, ordine) VALUES (?, ?, ?)")) {
                    inserisciListinoPS.setString(1, testoFrase);
                    inserisciListinoPS.setInt(2, test);
                    inserisciListinoPS.setInt(3, order);
                    inserisciListinoPS.executeUpdate();
                }  // Chiusura automatica di PreparedStatement
            } else {
                System.out.println("ID_testo non trovato per il titolo della pagina: " + titoloPagina);
            }

            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }



    }


    /**
     * Inserimento di frasi in una versione proposta, nel databsee
     * @param frasiTesto   frase
     * @param order        ordine
     * @param titlePagina  titolo
     * @param date         data
     * @param time         orario
     */
    public void addFraseVersionePropostaDB(String frasiTesto, int order, String titlePagina, Date date, Time time) {
        try {
            int test = -1;

            try (PreparedStatement getTesto = connection.prepareStatement("SELECT id_testo \n" +
                    "FROM pagina JOIN versioneproposta ON versioneproposta.titolo = pagina.titolo WHERE versioneproposta.titolo = ? AND versioneproposta.data=? AND versioneproposta.ora=?")) {
                getTesto.setString(1, titlePagina);
                getTesto.setDate(2, date);
                getTesto.setTime(3, time);


                ResultSet rs = getTesto.executeQuery();
                if (rs.next()) {
                    test = rs.getInt("id_testo");

                }
            }

            if (test != -1) {
                try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO frase (testo_effettivo, id_testo, ordine) VALUES (?, ?, ?)")) {
                    inserisciListinoPS.setString(1, frasiTesto);
                    inserisciListinoPS.setInt(2, test);
                    inserisciListinoPS.setInt(3, order);
                    inserisciListinoPS.executeUpdate();
                }  // Chiusura automatica di PreparedStatement
            } else {
                System.out.println("ID_testo non trovato per il titolo della pagina: " + titlePagina);
            }

            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }



    }
}
