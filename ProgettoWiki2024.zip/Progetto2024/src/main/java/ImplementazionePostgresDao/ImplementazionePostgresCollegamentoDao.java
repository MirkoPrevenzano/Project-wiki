package ImplementazionePostgresDao;

import DAO.CollegamentoDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Implementazione postgres collegamento dao.
 */
public class ImplementazionePostgresCollegamentoDao implements CollegamentoDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres collegamento dao.
     */
    public ImplementazionePostgresCollegamentoDao() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo dove ricavo tutte le pagine che contengono collegamenti
     * @param idTesto        idTesto
     */
    public void readCollegamento(List<Integer> idTesto)
    {
        try {
            try (PreparedStatement getTesto = connection.prepareStatement("SELECT DISTINCT id_testo FROM collegamento")) {
                ResultSet rs = getTesto.executeQuery();
                while(rs.next()){
                    idTesto.add(rs.getInt("id_testo"));
                }
            }


            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Dato un idTesto che si riferisce alla pagina in cui è presente un collegamento, vengono lette le frasi e le pagine di destinazione.
     * In questo modo carica tutti i collegamenti dal database
     * @param idTesto   idTesto della pagina sorgente
     * @param positions posizioni delle frasi
     * @param destPage  pagine di destinazione
     */
    public void readSourceFrase(int idTesto, List<Integer> positions, List<String> destPage)
    {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM collegamento WHERE id_testo=?\n");
            leggiListinoPS.setInt(1, idTesto);
            ResultSet rs = leggiListinoPS.executeQuery();

            while (rs.next()) {
                positions.add(rs.getInt("ordine"));
                destPage.add(rs.getString("titolo"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Appena è creato un collegamento nel sistema, questo è caricato nel database
     * @param destinationTitle  pagina di destinazione
     * @param sourceTitle       pagina dov'è presente il collegamento
     * @param position          posizione frase
     */
    public void addCollegamentoDB(String destinationTitle, String sourceTitle , int position)
    {
        try {


            ImplementazionePostgresVersioneCorrenteDAO versioneCorrenteDAO=new ImplementazionePostgresVersioneCorrenteDAO();
            int idTesto=versioneCorrenteDAO.takeIdTesto(sourceTitle);

             PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO collegamento (titolo, id_testo, ordine) VALUES (?, ?, ?)");
                    inserisciListinoPS.setString(1, destinationTitle);
                    inserisciListinoPS.setInt(2, idTesto);
                    inserisciListinoPS.setInt(3, position);
                    inserisciListinoPS.executeUpdate();


            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}
