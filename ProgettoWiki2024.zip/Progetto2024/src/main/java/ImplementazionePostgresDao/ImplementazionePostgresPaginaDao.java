package ImplementazionePostgresDao;

import DAO.PaginaDAO;
import Database.ConnessioneDB;

import java.sql.*;
import java.sql.Date;
import java.util.List;

/**
 *  Implementazione postgres pagina dao.
 */
public class ImplementazionePostgresPaginaDao implements PaginaDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres pagina dao.
     */
    public ImplementazionePostgresPaginaDao() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Per ogni autore sono caricate dal database le pagine
     * @param titlePagine titolo pagina
     * @param date        data pagina
     * @param time        ora pagina
     * @param loginAutore login autore
     */
    public void readPagineAutori(List<String> titlePagine, List<Date> date, List<Time> time, List<String> loginAutore) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM pagina");
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                titlePagine.add((rs.getString("titolo")));
                loginAutore.add(rs.getString("username"));
                date.add(rs.getDate("data"));
                time.add(rs.getTime("ora"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Inserimento nel database di una pagina appena creata
     * @param titoloPagina    titolo pagina
     * @param date           data pagina
     * @param time           ora pagina
     * @param usernameAutore username autore
     */
    public void addPagine(String titoloPagina, Date date, Time time, String usernameAutore) {
        try
        {
            PreparedStatement inserisciListinoPS = connection.prepareStatement(
                    "INSERT INTO pagina (titolo,data,ora,username) VALUES (?,?,?,?) ");
            inserisciListinoPS.setString(1,titoloPagina);
            inserisciListinoPS.setDate(2, date);
            inserisciListinoPS.setTime(3, time);
            inserisciListinoPS.setString(4,usernameAutore);

            inserisciListinoPS.executeUpdate();


            connection.close();
            inserisciListinoPS.close();


        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}