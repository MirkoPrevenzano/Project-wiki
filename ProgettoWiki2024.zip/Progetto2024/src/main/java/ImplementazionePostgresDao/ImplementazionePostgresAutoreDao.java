package ImplementazionePostgresDao;

import DAO.AutoreDAO;
import Database.ConnessioneDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Implementazione postgres autore dao.
 */
public class ImplementazionePostgresAutoreDao implements AutoreDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres autore dao.
     */
    public ImplementazionePostgresAutoreDao()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Carico da database gli autori
     * @param nomeAutore     nome autore
     * @param cognomeAutore  cognome autore
     * @param login          login
     * @param password       password
     */
    public void readListinoAutore(List<String> nomeAutore, List<String> cognomeAutore, List<String> login, List<String> password) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement(
                    "SELECT * FROM autore");
            ResultSet rs = leggiListinoPS.executeQuery();

            while (rs.next()) {
                nomeAutore.add(rs.getString("nome_a"));
                cognomeAutore.add(rs.getString("cognome"));
                login.add(rs.getString("username"));
                password.add(rs.getString("password"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

        } catch (Exception e) {
           e.printStackTrace();
        }
    }

    /**
     * Al momento di iscrizione di un autore, questo viene caricato nel database
     * @param nomeAutore    nome autore
     * @param cognomeAutore cognome autore
     * @param username      username
     * @param password      password
     */
    public void addAutore(String nomeAutore, String cognomeAutore, String username, String password)
    {
        try
        {
            PreparedStatement inserisciListinoPS = connection.prepareStatement(
                    "INSERT INTO autore (nome_a,cognome,username,password) VALUES (?,?,?,?) ");
            inserisciListinoPS.setString(1,nomeAutore);
            inserisciListinoPS.setString(2,cognomeAutore);
            inserisciListinoPS.setString(3,username);
            inserisciListinoPS.setString(4,password);

            inserisciListinoPS.executeUpdate();


            connection.close();
            inserisciListinoPS.close();


        }catch(Exception e)
        {
            e.printStackTrace();
        }

    }
}
