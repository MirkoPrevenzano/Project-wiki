package ImplementazionePostgresDao;

import DAO.TestoDAO;
import Database.ConnessioneDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Implementazione postgres testo dao.
 */
public class ImplementazionePostgresTestoDao implements TestoDAO {
    private  Connection connection;

    /**
     * Instantiates a new Implementazione postgres testo dao.
     */
    public ImplementazionePostgresTestoDao()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Letto il valore più alto di idTesto dal database
     * @return idTesto massimo
     */
    @Override
    public int takeMaxIdTesto()
    {
        int idTestoMax=0;
        try (PreparedStatement maxTestoPS = connection.prepareStatement("SELECT MAX(id_testo) AS max_id_testo FROM testo")) {
            ResultSet rs = maxTestoPS.executeQuery();

            if (rs.next()) {
                idTestoMax = rs.getInt("max_id_testo");
            }

            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return idTestoMax;
    }

    /**
     * creazione di un nuovo testo, dato un titolo e un idTesto
     * @param idTesto idTesto
     * @param title   titolo pagina
     */
    @Override
    public void insertTesto(int idTesto, String title)
    {
        try(PreparedStatement insertTestoPS = connection.prepareStatement("INSERT INTO testo (id_testo, titolo) VALUES (?, ?);\n")){
            insertTestoPS.setInt(1,idTesto);
            insertTestoPS.setString(2, title);
            insertTestoPS.executeUpdate();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }


}
