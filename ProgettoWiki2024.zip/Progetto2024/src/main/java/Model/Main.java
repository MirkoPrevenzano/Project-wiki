package Model;

/**
 * The type Main.
 */
public class Main {
    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
String titolo =  "aaa  troia";
        titolo= String.valueOf(titolo.endsWith("  "));
        System.out.println(titolo);
    }
}