package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Listino iscritti.
 */
public class ListinoIscritti {
    private final List<Utente> listUtente=new ArrayList<>();
    private final List<Autore> listAutore=new ArrayList<>();

    /**
     * Gets list autore.
     *
     * @return the list autore
     */
    public List<Autore> getListAutore() {
        return listAutore;
    }

    /**
     * Gets list utente.
     *
     * @return the list utente
     */
    public List<Utente> getListUtente() {
        return listUtente;
    }

    /**
     * Add list autore.
     *
     * @param a the a:autore da aggiungere
     */
    public void addListAutore(Autore a) {
        this.listAutore.add(a);
    }

    /**
     * Add list utente.
     *
     * @param u the u:utente da aggiungere
     */
    public void addListUtente(Utente u) {
        this.listUtente.add(u);
    }

    /**
     * Search autore autore. Ricerca l'autore in base al suo username (login)
     *
     * @param username the username
     * @return the autore
     */
    public Autore searchAutore(String username){

        for (Autore p:listAutore
             ) {
            if(p.getLogin().equals(username))
                return p;
        }

        return null;
    }

    /**
     * Search utente utente. Ricerca utente in base al suo nome e cognome
     *
     * @param nome    the nome
     * @param cognome the cognome
     * @return the utente
     */
    public Utente searchUtente(String nome, String cognome){
        for (Utente p:listUtente
        ) {
            if(p.getNome().equals(nome)&& p.getCognome().equals(cognome))
                return p;
        }

        return null;
    }
}
