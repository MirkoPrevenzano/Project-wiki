package Model;


import java.util.ArrayList;
import java.util.List;

/**
 * The type Utente.
 */
public class Utente {
    /**
     * The Nome.
     */
    protected String nome;
    /**
     * The Cognome.
     */
    protected String cognome;
    /**
     * The List proposte richieste.
     */
    protected List<VersioneProposta> listProposteRichieste;

    /**
     * Instantiates a new Utente.
     *
     * @param nome    the nome
     * @param cognome the cognome
     */
    public Utente(String nome, String cognome) {
        this.nome = nome;
        this.cognome = cognome;
        listProposteRichieste = new ArrayList<>();
    }

    /**
     * Gets nome.
     *
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Gets cognome.
     *
     * @return the cognome
     */
    public String getCognome() {
        return cognome;
    }

    /**
     * Add proposta.
     *
     * @param p the p
     */
    public void addProposta(VersioneProposta p)
    {
        listProposteRichieste.add(p);
    }

    public List<VersioneProposta> getListProposteRichieste() {return listProposteRichieste;}
}
