package Model;


import java.util.ArrayList;
import java.util.List;

/**
 * The type Testo.
 */
public class Testo {
    private List<Frase> listFrasi;
    private Versione versione;

    /**
     * Instantiates a new Testo.
     */
    public Testo(Versione versione) {
       listFrasi = new ArrayList<>();
       this.versione=versione;
    }

    /**
     * Gets frasi.
     *
     * @return the frasi
     */
    public List<Frase> getFrasi() {return listFrasi;}

    /**
     * Add frase.
     *
     * @param f the f
     */
    public void addFrase(Frase f)
    {
        listFrasi.add(f);
    }

}
