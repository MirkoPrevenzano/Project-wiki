package gui;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * The type View proposte autore: visualizza proposte da parte di un autore. Selezionando un item della lista è possibile
 * scegliere cosa visualizzare
 */
public class ViewProposteAutore {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JList<String> listProposed;
    private JPanel panel1;
    private JButton returnButton;


    List<String> listTitle=new ArrayList<>();
    List<LocalDate> date = new ArrayList<>();
    List<LocalTime> time =new ArrayList<>();

    /**
     * Instantiates a new View proposte autore.
     *
     * @param framePrevious  frame precedente
     * @param controller     controller
     * @param usernameAutore sername autore
     */
    public ViewProposteAutore(final JFrame framePrevious, final Controller controller,final String usernameAutore) {
        frame = new JFrame(usernameAutore+" [Proposte effettuate]");
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);
        insertList(controller, usernameAutore);


        listProposed.addListSelectionListener(e -> {

        });
        returnButton.addActionListener(e -> {
            frame.setVisible(false);
            frame.dispose();
            framePrevious.setVisible(true);
        });
        listProposed.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    if (listProposed.getSelectedIndex() != -1 && listProposed.getModel().getElementAt(listProposed.getSelectedIndex()).isEmpty()) {

                        listProposed.clearSelection();
                    } else {

                        int index = listProposed.locationToIndex(e.getPoint());
                        String title=listTitle.get(listProposed.getSelectedIndex());

                        listProposed.setSelectedIndex(index);
                        JPopupMenu popupMenu = createPopupMenu(controller,title, usernameAutore );
                        popupMenu.show(listProposed, e.getX(), e.getY());

                    }

                }
            }
        });

    }


    /**
     * Crea un popupMenù con la possibilià di scegliere se visualizzare versione corrente, le versione precedenti o la versione proposta
     * @param controller      controller
     * @param title           titolo pagina
     * @param usernameAutore  username autore
     * @return menù scelte
     */
    private JPopupMenu createPopupMenu(Controller controller, String title, String usernameAutore) {
        JPopupMenu popupMenu = new JPopupMenu();

        JMenuItem showPreviousVersionsItem = new JMenuItem("Mostra versioni precedenti");
        showPreviousVersionsItem.addActionListener(e -> {
            String usernameAutorePage=controller.getUsernameByTitle(title);
            ViewVersioniPrecedenti viewVersioniPrecedenti=new ViewVersioniPrecedenti(controller,frame, title, usernameAutorePage);
            viewVersioniPrecedenti.frame.setVisible(true);
            frame.setVisible(false);
        });
        popupMenu.add(showPreviousVersionsItem);

        JMenuItem showProposedVersionItem = new JMenuItem("Mostra versione proposta");
        showProposedVersionItem.addActionListener(e -> {
            LocalTime timePage=time.get(listProposed.getSelectedIndex());
            LocalDate datePage=date.get(listProposed.getSelectedIndex());

            List<String> textVersion =controller.getTestoPageVersioneProposta(title,datePage,timePage, usernameAutore);
            OnlyViewPage onlyViewPage=new OnlyViewPage(frame,textVersion, title, "Proposta" );
            onlyViewPage.frame.setVisible(true);
            frame.setVisible(false);
        });
        popupMenu.add(showProposedVersionItem);

        JMenuItem showCurrentVersionItem = new JMenuItem("Mostra versione corrente");
        showCurrentVersionItem.addActionListener(e -> {
            List<String> textVersion =controller.getTestoPage(title);
            String surname=controller.getCognomeAutore(usernameAutore);
            String name=controller.getNomeAutore(usernameAutore);
            ViewPaginaUtente viewPaginaUtente=new ViewPaginaUtente(controller, frame,textVersion, title, name, surname );
            viewPaginaUtente.frame.setVisible(true);
            frame.setVisible(false);

        });
        popupMenu.add(showCurrentVersionItem);

        return popupMenu;
    }
    private void insertList(Controller controller, String usernameAutore) {
        listTitle=controller.getTitlesProposed(usernameAutore);
        date=controller.getDateProposed( usernameAutore);
        time=controller.getTimeProposed( usernameAutore);
        DefaultListModel<String> listModel=new DefaultListModel<>();
        listProposed.setModel(listModel);
        if (date != null && date.size() == time.size()&&time.size()==listTitle.size()) {
            for (int i = 0; i < date.size(); ++i) {
                listModel.addElement("Titolo: "+listTitle.get(i)+"   invio: "+date.get(i) + "  " +
                        String.format("%02d", time.get(i).getHour()) + ":" +
                        String.format("%02d", time.get(i).getMinute()) + ":" +
                        String.format("%02d", time.get(i).getSecond()));
            }
        }
    }

}
