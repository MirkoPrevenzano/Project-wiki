package Model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Pagina.
 */
public class Pagina {
    private String titolo;
    private  VersioneCorrente versioneCorrente;
    private final LocalDate data;
    private final LocalTime ora;
    private final List<VersionePrecedente> versionePrecedenteList;
    private final Autore autore;

    /**
     * Instantiates a new Pagina.
     *
     * @param titolo the titolo
     * @param autore the autore
     */
    public Pagina(String titolo, Autore autore)
    {
        this.titolo = titolo;
        versionePrecedenteList=new ArrayList<>();
        versioneCorrente=new VersioneCorrente(this);
        this.autore = autore;
        this.data = LocalDate.now();
        this.ora = LocalTime.now();

    }

    /**
     * Instantiates a new Pagina.
     *
     * @param titolo the titolo
     * @param data   the data
     * @param ora    the ora
     * @param autore the autore
     */
    public Pagina(String titolo, LocalDate data, LocalTime ora, Autore autore)
    {
        this.titolo = titolo;
        versionePrecedenteList=new ArrayList<>();
        this.autore = autore;
        versioneCorrente=new VersioneCorrente(this);
        this.data=data;
        this.ora=ora;
    }

    /**
     * Gets autore.
     *
     * @return the autore
     */
    public Autore getAutore() {
        return autore;
    }

    /**
     * Gets titolo.
     *
     * @return the titolo
     */
    public String getTitolo() {
        return titolo;
    }

    /**
     * Sets titolo.
     *
     * @param titolo the titolo
     */
    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    /**
     * Gets versione corrente.
     *
     * @return the versione corrente
     */
    public VersioneCorrente getVersioneCorrente() {
        return versioneCorrente;
    }

    /**
     * Gets versione precedente list.
     *
     * @return the versione precedente list
     */
    public List<VersionePrecedente> getVersionePrecedenteList() {
        return versionePrecedenteList;
    }

    /**
     * Add list versione.
     *
     * @param versionePrecedente the versione precedente:aggiungo versione precedente
     */
    public void addListVersione(VersionePrecedente versionePrecedente) {versionePrecedenteList.add(versionePrecedente);}

    /**
     * Gets data.
     *
     * @return the data
     */
    public LocalDate getData() {return data;}

    /**
     * Gets ora.
     *
     * @return the ora
     */
    public LocalTime getOra() {return ora;}
}
