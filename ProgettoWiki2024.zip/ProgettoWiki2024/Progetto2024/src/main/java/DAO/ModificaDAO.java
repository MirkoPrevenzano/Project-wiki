package DAO;

import java.sql.Date;
import java.sql.Time;

public interface ModificaDAO {
    /**
     * Inserisci frase modificata .
     *
     * @param date       data
     * @param order      ordine
     * @param title      titolo
     * @param modify     testo modifica
     * @param time       orario
     */
    void addModificaDAO(String modify, String title, Date date, Time time, Integer order);


    /**
     * Read modifiche string.
     *
     * @param idProposta identificativo proposta nel db
     * @param order      posizione frase
     * @return il contenuto della modifica proposta di una frase
     */
    String readModifiche(Integer order, Integer idProposta);
}
