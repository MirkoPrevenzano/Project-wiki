package DAO;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

/**
 * The interface Versione precedente dao.
 */
public interface VersionePrecedenteDAO {

    /**
     * carica versioni precedenti dal database
     *
     * @param titlePagina titolo pagina
     * @param date        data di creazione versione precedente
     * @param time        orario di creazione versione precedente
     */
    void readVersionePrecedenteDB(List<String> titlePagina, List<Date> date, List<Time> time);

    /**
     * carica frasi di una versione precedente dato il titolo, l'ora e la data dal database
     *
     * @param titlePagina titolo pagina
     * @param date        data di creazione versione precedente
     * @param time        orario di creazione versione precedente
     * @param testoFrasi  lista contenuto frasi
     */
    void readFrasiVersionePrecedenteDB(String titlePagina, Date date, Time time, List<String> testoFrasi);

    /**
     * Aggiunge una versione precedente di una data pagina, nel database
     *
     * @param title titolo pagina
     * @param date  data di creazione versione precedente
     * @param time  orario di creazione versione precedente
     */
    void addVersionePrecedenteDB(String title, Date date, Time time);
}
