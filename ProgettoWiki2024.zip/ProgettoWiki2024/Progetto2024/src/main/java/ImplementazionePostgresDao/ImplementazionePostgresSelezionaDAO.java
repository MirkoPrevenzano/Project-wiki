package ImplementazionePostgresDao;

import DAO.SelezioneDAO;

import java.sql.*;

import Database.ConnessioneDB;

import java.util.List;

/**
 * Implementazione postgres seleziona dao.
 */
public class ImplementazionePostgresSelezionaDAO implements SelezioneDAO {


    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres seleziona dao.
     */
    public ImplementazionePostgresSelezionaDAO()
    {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Aggiunta nel database di frasi selezionate, data una proposta
     * @param title testo frase
     * @param date  data proposta
     * @param time  ora proposta
     * @param order posizione frase
     */
    @Override
    public void addSelezioneDAO(String title, Date date, Time time, int order) {

        ImplementazionePostgresVersioneProposta versioneProposta =new ImplementazionePostgresVersioneProposta();
        int idProposta = versioneProposta.takeIdProposta(date, time, title);

        ImplementazionePostgresVersioneCorrenteDAO versioneCorrente =new ImplementazionePostgresVersioneCorrenteDAO();
        int idTesto= versioneCorrente.takeIdTesto(title);


        try
        {
            PreparedStatement inserisciListinoPS = connection.prepareStatement(
                    "INSERT INTO seleziona (id_testo,id_proposta,ordine) VALUES (?,?,?) ");
            inserisciListinoPS.setInt(1,idTesto);
            inserisciListinoPS.setInt(2,idProposta);
            inserisciListinoPS.setInt(3,order+1);
            inserisciListinoPS.executeUpdate();
            connection.close();
            inserisciListinoPS.close();


        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Data una proposta, caricate dal database le frasi selezionate
     * @param idProposta identificativo proposta nel db
     * @param order      posizione frase
     */
    @Override
    public void readSelezionate(Integer idProposta, List<Integer> order) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("Select ordine from seleziona\n" +
                    "WHERE id_proposta = ? ");

            leggiListinoPS.setInt(1, idProposta);
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                order.add(rs.getInt("ordine"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
