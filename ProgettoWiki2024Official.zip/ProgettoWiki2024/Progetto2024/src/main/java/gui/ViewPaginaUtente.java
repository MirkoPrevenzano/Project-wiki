package gui;

import controllerPackage.Controller;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * The type View pagina utente: Permette di visualizzare il contenuto di una pagina, di proporre una modifica.
 * Selezionado una frase, se esiste, è possibile accedere al collegamento
 */
public class ViewPaginaUtente {
    /**
     * The Frame.
     */
    public final JFrame frame;
    private JPanel panel1;
    private JList<String> listPhrase;
    private JButton modifyButton;
    private JButton returnButton;
    private Timer messageTimer;

    /**
     * Instantiates a new View pagina utente.
     *
     * @param controller    the controller
     * @param framePrevious the frame previous
     * @param phrases       the phrases
     * @param title         the title
     * @param nameUtente    the name utente
     * @param surnameUtente the surname utente
     */
    public ViewPaginaUtente(final Controller controller, final JFrame framePrevious, final List<String> phrases, String title, final String nameUtente, final String surnameUtente) {

        this.frame = new JFrame(title);
        this.frame.setContentPane(this.panel1);
        this.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(framePrevious);
        frame.setResizable(false);


        DefaultListModel<String> listModel=new DefaultListModel<>();
        this.listPhrase.setModel(listModel);

            for (String phrase : phrases) {

                listModel.addElement(phrase);

            }

            returnButton.addActionListener(e -> {
                frame.setVisible(false);
                frame.dispose();
                framePrevious.setVisible(true);
            });


        listPhrase.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    if ( !controller.isCollegamento(title, listPhrase.getSelectedIndex())) {

                        listPhrase.clearSelection();
                    } else {
                        int index=listPhrase.getSelectedIndex();
                        listPhrase.clearSelection();
                        JPopupMenu popupMenu = createPopupMenu( controller, title, index, nameUtente, surnameUtente);
                        popupMenu.show(listPhrase, e.getX(), e.getY());

                    }

                }
            }
        });


        modifyButton.addActionListener(e -> {
            CreazioneProposta creazioneProposta=new CreazioneProposta(controller,framePrevious,phrases,title,nameUtente,surnameUtente);
            creazioneProposta.frame.setVisible(true);
            frame.setVisible(false);
        });




    }

    /**
     * Metodo che mostra un messaggio d'errore, fa comparire una finestra dialogo per 1 secondo
     *
     */
    private void showMessage() {
        JOptionPane optionPane = new JOptionPane("Errore generico", JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(frame, "Messaggio");

        messageTimer = new Timer(1000, e -> {
            dialog.dispose();
            messageTimer.stop();
        });

        messageTimer.start();

        dialog.setVisible(true);


    }

    /**
     * Creazione di un popMenù per accedere al collegamento di una frase
     * @param controller controller
     * @param title      titolo pagina
     * @param selectedIndex  indice frase selezionata
     * @param nameUtente     Nome utente
     * @param surnameUtente  Cognome utente
     * @return  menù scelta
     */
    private JPopupMenu createPopupMenu(Controller controller, String title, int selectedIndex, String nameUtente, String surnameUtente ) {
        JPopupMenu popupMenu = new JPopupMenu();

        JMenuItem showLink = new JMenuItem("Vai al collegamento");
        showLink.addActionListener(e -> {
            String titleLink = controller.pageLink(title, selectedIndex);
            List<String> text = controller.getTestoPage(titleLink);
            String usernameAutore = controller.getAutore(titleLink);
            if (text != null && (usernameAutore != null)) {

                ViewPaginaUtente viewPaginaUtente = new ViewPaginaUtente(controller, frame, text, titleLink, nameUtente, surnameUtente);
                viewPaginaUtente.frame.setVisible(true);
                frame.setVisible(false);
                frame.dispose();
            } else {
                showMessage();
            }


        });
        popupMenu.add(showLink);

        return popupMenu;
    }
}

