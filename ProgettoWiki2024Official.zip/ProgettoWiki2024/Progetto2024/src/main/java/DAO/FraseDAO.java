package DAO;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

/**
 * The interface Frase dao.
 */
public interface FraseDAO {
    /**
     * Leggi frasi pagina.
     *
     * @param frasiTesto  the testo frase
     * @param titlePagine the titolo pagina
     * @param order       the ordine
     */
    void readFrasiPagina(List<String> frasiTesto, List<String> titlePagine, List<Integer> order);

    /**
     * Inserisci frase db.
     *
     * @param frasiTesto the testo frase
     * @param order      the ordine
     * @param title      the titolo
     */
    void addFraseDB(String frasiTesto, int order, String title);

    /**
     * Inserisci frase versione proposta.
     *
     * @param frasiTesto   testo frase
     * @param order        ordine
     * @param titlePagina  titolo
     * @param date         data
     * @param time         orario
     */
    void addFraseVersionePropostaDB(String frasiTesto, int order, String titlePagina, Date date, Time time);


    }
