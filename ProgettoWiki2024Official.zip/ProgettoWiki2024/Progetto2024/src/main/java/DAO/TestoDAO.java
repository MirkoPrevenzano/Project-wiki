package DAO;

public interface TestoDAO {
    /**
     *
     * @return idTesto più alto
     */
    int takeMaxIdTesto();

    /**
     * Inserisce istanza testo
     * @param idTesto idTesto
     * @param title   titolo pagina
     */
    void insertTesto(int idTesto, String title);
}
