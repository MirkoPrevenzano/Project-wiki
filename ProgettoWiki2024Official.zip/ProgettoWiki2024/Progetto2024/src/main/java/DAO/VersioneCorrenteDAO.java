package DAO;

import java.sql.Date;
import java.sql.Time;

/**
 * The interface Versione corrente dao.
 */
public interface VersioneCorrenteDAO {
    /**
     * Aggiorna versione corrente db.
     *
     * @param title titolo
     * @param date  data versione
     * @param time  ora versione
     */
    void updateVersioneCorrenteDB(String title, Date date, Time time);

    /**
     * Restituisce idTesto dato un titolo
     * @param title titolo pagina
     * @return idTesto
     */
    int takeIdTesto(String title);
    String takeTitle(int idTesto);
}
