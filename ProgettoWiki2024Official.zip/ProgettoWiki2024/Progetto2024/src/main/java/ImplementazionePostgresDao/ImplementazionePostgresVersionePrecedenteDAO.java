package ImplementazionePostgresDao;

import DAO.VersionePrecedenteDAO;
import Database.ConnessioneDB;

import java.sql.*;
import java.util.List;

/**
 * The type Implementazione postgres versione precedente dao.
 */
public class ImplementazionePostgresVersionePrecedenteDAO implements VersionePrecedenteDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres versione precedente dao.
     */
    public ImplementazionePostgresVersionePrecedenteDAO() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * versioni precedenti caricate dal databse
     * @param titlePagina titolo pagina
     * @param date        data di creazione versione precedente
     * @param time        orario di creazione versione precedente
     */
    @Override
    public void readVersionePrecedenteDB(List<String> titlePagina, List<Date> date, List<Time> time) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM versioneprecedente");
            ResultSet rs = leggiListinoPS.executeQuery();
            while (rs.next()) {
                titlePagina.add(rs.getString("titolo"));
                date.add(rs.getDate("data"));
                time.add(rs.getTime("ora"));
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Dato una data, un orario e un titolo, carica dal database le frasi che la compongono
     * @param titlePagina titolo pagina
     * @param date        data di creazione versione precedente
     * @param time        orario di creazione versione precedente
     * @param testoFrasi  lista contenuto frasi
     */
    public void readFrasiVersionePrecedenteDB(String titlePagina, Date date, Time time, List<String> testoFrasi) {
        try {

            try (PreparedStatement leggiListinoPS = connection.prepareStatement("SELECT * FROM frase " +
                    "JOIN versioneprecedente ON versioneprecedente.id_testo = frase.id_testo " +
                    "WHERE versioneprecedente.titolo = ? AND versioneprecedente.data = ? AND versioneprecedente.ora = ?")) {

                leggiListinoPS.setString(1, titlePagina);
                leggiListinoPS.setDate(2, date);
                leggiListinoPS.setTime(3, time);

                try (ResultSet rs = leggiListinoPS.executeQuery()) {
                    while (rs.next()) {
                        testoFrasi.add(rs.getString("testo_effettivo"));
                    }
                }
            }

        } catch (Exception e) {
           e.printStackTrace();
        }

    }

    /**
     * Metodo utilizzato al momento di creazione di una versione precedente, caricandola nel database
     * @param title titolo pagina
     * @param date  data di creazione versione precedente
     * @param time  orario di creazione versione precedente
     */
    public void addVersionePrecedenteDB(String title, Date date, Time time)
    {
        try {


            ImplementazionePostgresVersioneCorrenteDAO versioneCorrenteDAO=new ImplementazionePostgresVersioneCorrenteDAO();
            int idTesto =versioneCorrenteDAO.takeIdTesto(title);

            try (PreparedStatement inserisciListinoPS = connection.prepareStatement(
                        "INSERT INTO versioneprecedente (titolo, data, ora, id_testo) VALUES (?, ?, ?,?)")) {
                    inserisciListinoPS.setString(1, title);
                    inserisciListinoPS.setDate(2, date);
                    inserisciListinoPS.setTime(3, time);
                    inserisciListinoPS.setInt(4, idTesto);
                    inserisciListinoPS.executeUpdate();
            }


            connection.close();

        } catch (Exception e) {
           e.printStackTrace();
        }
    }
}
