package ImplementazionePostgresDao;

import DAO.ModificaDAO;
import Database.ConnessioneDB;

import java.sql.*;

/**
 *
 * Implementazione postgres modifica dao.
 */
public class ImplementazionePostgresModificaDAO implements ModificaDAO {
    private Connection connection;

    /**
     * Instantiates a new Implementazione postgres modifica dao.
     */
    public ImplementazionePostgresModificaDAO() {
        try {
            connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Inserimento nel database di frasi modificate in una versione proposta
     * @param modify     testo modifica
     * @param title      titolo
     * @param date       data
     * @param time       orario
     * @param order      ordine
     */
    @Override
    public void addModificaDAO(String modify, String title, Date date, Time time, Integer order) {
        int idProposta = 0;
        int idTesto = 0;
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT id_proposta " +
                            "FROM versioneproposta " +
                            "WHERE data = ? AND ora = ? AND titolo = ?"
            );


                statement.setDate(1, date);
                statement.setTime(2, time);
                statement.setString(3, title);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    idProposta = resultSet.getInt("id_proposta");
                }

                resultSet.close();
                statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT id_testo " +
                            "FROM versionecorrente " +
                            "WHERE  titolo = ?"
            );


                statement.setString(1, title);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    idTesto = resultSet.getInt("id_testo");
                }

                resultSet.close();

                statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        try {
            PreparedStatement inserisciListinoPS = connection.prepareStatement(
                    "INSERT INTO modifica (id_testo,id_proposta,ordine, testo_modifca) VALUES (?,?,?,?) ");
            inserisciListinoPS.setInt(1, idTesto);
            inserisciListinoPS.setInt(2, idProposta);
            inserisciListinoPS.setInt(3, order + 1);
            inserisciListinoPS.setString(4,  modify);
            inserisciListinoPS.executeUpdate();
            connection.close();
            inserisciListinoPS.close();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Tutte le modifiche sono caricate dal database
     * @param order      posizione frase
     * @param idProposta identificativo proposta nel db
     * @return
     */
    @Override
    public String readModifiche(Integer order, Integer idProposta) {
        try {
            PreparedStatement leggiListinoPS = connection.prepareStatement("Select testo_modifca from modifica\n" +
                    "WHERE id_proposta = ? AND ordine = ? ");

            leggiListinoPS.setInt(1, idProposta);
            leggiListinoPS.setInt(2, order);
            ResultSet rs = leggiListinoPS.executeQuery();

            String modifiche = null;
            while (rs.next()) {
                modifiche = rs.getString("testo_modifca");
            }
            connection.close();
            rs.close();
            leggiListinoPS.close();

            return modifiche;
        } catch (Exception e) {
           e.printStackTrace();
        }

        return null;
    }
}
